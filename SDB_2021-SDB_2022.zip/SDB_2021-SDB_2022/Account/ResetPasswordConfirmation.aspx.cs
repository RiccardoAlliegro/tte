﻿using System.Web.UI;

namespace SDB_2021.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}