﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class Contropartite
    {
        private readonly SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        public string RecuperaContropartita(string forn, string fam, string settore, string Naz, string art)
        {
            string cpart = "";
            try
            {
                // recupera contropartita estera da tabella CO_CONTROP_PAR
                string sql = "SELECT cod_cpartitaR FROM Contropartite WHERE Tipo_Fornitura='" + forn + "' AND Famiglia='" + fam + "' AND Nazione='" + Naz + "'";
                if (settore != "" & fam == "P")
                    sql += " AND Sottofamiglia='" + settore + "'";
                
                if(art.ToUpper().Trim() == "TRASPORTO" | art.ToUpper().Trim() == "CASSA")
                {
                    sql = "SELECT cod_cpartitaR FROM Contropartite WHERE Articolo = '" + art.ToUpper().Trim() + "'";
                }
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    cpart = (string)dt.Rows[0]["cod_cpartitaR"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }

            return cpart;
        }

    }
}