﻿namespace SDB_2021.Code
{
    public class MyKey
    {
        public string NewKey()
        {
            RandomKeyGenerator KeyGen = new RandomKeyGenerator();
            int NumKeys = 48;
            int i_Keys = 1;
            string RandomKey = "";

            KeyGen.KeyLetters = "abcdefghijklmnopqrstuvwxyz";
            KeyGen.KeyNumbers = "0123456789";
            KeyGen.KeyChars = 24;
            for (i_Keys = 1; i_Keys <= NumKeys; i_Keys++)
                RandomKey = KeyGen.Generate();

            return RandomKey;
        }

    }
}