﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class Nomenclatura
    {

        public string GetNomenclatura(string famiglia, string fornitura)
        {
            string codice = "";
            try
            {
                if (famiglia == "S")
                {
                    if (fornitura == "A")
                        codice = "84425000";
                    else
                        codice = "";
                }
                if (famiglia == "D")
                {
                    if (fornitura == "A")
                        codice = "84425000";
                    else
                        codice = "";
                }
                if (famiglia == "E")
                {
                    if (fornitura == "A")
                        codice = "84209180";
                    else
                        codice = "";
                }
                if (famiglia == "P")
                    codice = "84423000";
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return codice;
        }
        public string GetCodiceServizio(string famiglia, string fornitura)
        {
            string codice = "";
            try
            {
                if (famiglia == "S")
                {
                    if (fornitura == "A")
                        codice = "";
                    else
                        codice = "256220";
                }
                if (famiglia == "D")
                {
                    if (fornitura == "A")
                        codice = "";
                    else
                        codice = "256220";
                }
                if (famiglia == "E")
                {
                    if (fornitura == "A")
                        codice = "";
                    else
                        codice = "256220";
                }
                if (famiglia == "P")
                    codice = "";
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return codice;
        }
    }
}