﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class CodiceIva
    {
        private readonly SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["Order_SIM"].ConnectionString);
        public string RecuperaCodiceIva(string cliente, string articolo, string tipofornitura)
        {
            string codiva = "22";
            try
            {
                codiva = cercaCodIvaCliente(cliente);
                if (codiva != "A8C")
                {
                    string nazCliente = trovaNazioneCLiente(cliente);
                    switch (nazCliente)
                    {
                        case "1":
                            {
                                if (tipofornitura == "A")
                                    codiva = "A41";
                                else
                                    codiva = "SE8";
                                break;
                            }

                        case "2":
                            {
                                if (tipofornitura == "A")
                                    codiva = "A8A";
                                else
                                    codiva = "SE7";
                                break;
                            }

                        case "3":
                            {
                                if (tipofornitura == "A")
                                    codiva = "71C";
                                else
                                    codiva = "71S";
                                break;
                            }

                        default:
                            {
                                codiva = "22";
                                break;
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return codiva;
        }

        public string trovaNazioneCLiente(string cliente)
        {
            string ind_area_naz = "0";
            string codnaz = "0";
            try
            {
                string sql = "Select cod_naz FROM CA_ANAGRAFICHE WHERE cod_anagra='" + cliente + "'";
                SqlCommand cmd = new SqlCommand(sql, sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull((dt.Rows[0]["cod_naz"])))
                    {
                        codnaz = (string)dt.Rows[0]["cod_naz"];
                        sql = "Select ind_area_naz FROM CA_NAZIONI WHERE cod_naz='" + codnaz + "'";
                        cmd = new SqlCommand(sql, sqlconn);
                        da = new SqlDataAdapter(cmd);
                        dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            if (!Convert.IsDBNull((dt.Rows[0]["ind_area_naz"])))
                                ind_area_naz = (string)dt.Rows[0]["ind_area_naz"];
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return ind_area_naz;
        }
        public string cercaCodIvaCliente(string cliente)
        {
            string codiva = "22";
            try
            {
                string sql = "Select cod_iva FROM CO_CLIFOR WHERE cod_clifor='" + cliente + "'";
                SqlCommand cmd = new SqlCommand(sql, sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull((dt.Rows[0]["cod_iva"])))
                    {
                        if ((string)(dt.Rows[0]["cod_iva"]) == "A8C")
                            codiva = "A8C";
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return codiva;
        }
    }
}