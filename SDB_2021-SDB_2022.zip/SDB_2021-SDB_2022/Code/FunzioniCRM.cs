﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class FunzioniCRM
    {
        private readonly SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        private readonly SqlConnection ConnTSE = new SqlConnection(ConfigurationManager.ConnectionStrings["TSE"].ConnectionString);

        public string GetAzienda(string ut)
        {
            try
            {
                string sql = "SELECT Azienda FROM Aspnet_users WHERE UserName=@ute";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ut));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["Azienda"]))
                        ut = (string)dt.Rows[0]["Azienda"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return ut;
        }

        public string GetUserGroup(string utente)
        {
            string gr = "";
            try
            {
                string sql = "SELECT RoleName FROM vw_aspnet_UsersInRoles WHERE UserName='" + utente + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    gr = (string)dt.Rows[0]["RoleName"];
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return gr;
        }
        public void AggiornaSedeLegale(Int32 cliid, string nome)
        {
            try
            {
                string sql = "UPDATE OFF_DestinazioniClienti SET RagSoc=@RagSoc WHERE IdCliente=" + cliid + " AND Sede=1";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, nome, 100));
                ConnSDB.Open();
                cmd.ExecuteNonQuery();
                ConnSDB.Close();
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                ConnSDB.Close();
            }
        }

        public string VerificaBloccoAmministrativo(Int32 idcli)
        {
            string msg = "";
            try
            {
                bool BloccatoAmm = false;
                string sql = "SELECT BloccatoAmm FROM OFF_ClientiSDB WHERE IdCliente=" + idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["BloccatoAmm"] is int)
                    {
                        BloccatoAmm = System.Convert.ToBoolean(dt.Rows[0]["BloccatoAmm"]);
                        if (BloccatoAmm == true)
                            msg = "Customer locked! Please contact the Acc. Dept.";
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return msg;
        }

        public string BloccatoAmm(string Erpcode)
        {
            string msg = "Customer locked! Please contact the Acc. Dept.";
            return msg;
        }

        public string CaricaAgente(string erpcode)
        {
            string idag = "";
            try
            {
                string sql = "SELECT Cod_Agente FROM vw_Clifor WHERE CodCliente=" + Convert.ToInt32(erpcode);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["Cod_Agente"] is int)
                        idag = (string)dt.Rows[0]["Cod_Agente"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return idag;
        }

        public string ResponsabileClienteWebt(Int32 codCliente, string tipo = "C", string idCliente = "")
        {
            string resp = "";
            try
            {
                string sql = "SELECT Manager, Backoffice From OFF_ClientiSDB Where ";
                if (idCliente != "")
                    sql += "Id =" + idCliente;
                else
                    sql += "ERPCode ='" + codCliente + "'";
                var cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if ((dt.Rows.Count > 0))
                {
                    if (tipo == "C")
                    {
                        if (!Convert.IsDBNull(dt.Rows[0]["Manager"]))
                            resp = dt.Rows[0]["Manager"].ToString().Trim();
                    }
                    else if (!Convert.IsDBNull(dt.Rows[0]["Backoffice"]))
                        resp = dt.Rows[0]["Backoffice"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return resp;
        }
        public string BloccaSedi(string cli)
        {
            string msg = "";
            try
            {
                string sql = "SELECT * FROM OFF_DestinazioniClienti WHERE Sede=0 And Disable=0 And IdCliente = @IdCliente ORDER BY Id";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, cli));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (!Convert.IsDBNull(dt.Rows[i]["Tipo"]))
                    {
                        if (dt.Rows[i]["Tipo"].ToString().Trim() == "")
                            msg = "The PLANTS section must be updated before you can navigate the customer.";
                    }
                    else
                        msg = "The PLANTS section must be updated before you can navigate the customer.";
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return msg;
        }

        public double[] GetCommissione(string codag, string fam, string sett, string forn)
        {
            double[] com = new[] { 0.0, 0.0, 0.0 };
            try
            {
                string sql = "SELECT Commissione,ScontoLimite,DisavanzoSconto FROM OFF_Agenti WHERE Agente=@codag And Famiglia='" + fam + "' AND Settore='" + sett + "' And fornitura='" + forn + "'";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("codag", DbType.String, codag));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    com[0] = (double)dt.Rows[0]["Commissione"];
                    com[1] = (double)dt.Rows[0]["ScontoLimite"];
                    com[2] = (double)dt.Rows[0]["DisavanzoSconto"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return com;
        }

        public string GetCodAgente(string ut)
        {
            string cod = "";
            try
            {
                string sql = "SELECT DISTINCT CodAgenteERP FROM Aspnet_users WHERE UserName=@ute AND CodAgenteERP<>''";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ut));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    cod = (string)dt.Rows[0]["CodAgenteERP"];
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return cod;
        }

        public string ResponsabileInternoCliente(string codCliente, string back = "manager")
        {
            string resp = "";
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                string sql = "SELECT Nota From Caratteristiche_Clienti Where Nota<>'' AND CodCaratteristica=13220 AND CodCliente=" + codCliente;
                if (back == "bkoffice")
                    sql = "SELECT Nota From Caratteristiche_Clienti Where Nota<>'' AND CodCaratteristica=13221 AND CodCliente=" + codCliente;
                var cmd = new SqlCommand((sql), sqlconn);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    resp = (string)ds.Tables[0].Rows[0]["Nota"];
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return resp;
        }
        public int getCodiceClienteCRM(string codiceClienteEsa)
        {
            int cod = 0;
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                var cmd = new SqlCommand(("SELECT IDCliente From CLIENTI Where Codice='" + codiceClienteEsa + "'"), sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    cod = System.Convert.ToInt32(ds.Tables[0].Rows[0]["IDCliente"]);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return cod;
        }

        public DataTable GetUteControllati(string ute)
        {
            DataTable dt = new DataTable();
            try
            {
                string sql = "SELECT Controllato,NomeCompleto FROM vw_UtentiController WHERE Utente=@ute";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ute));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return dt;
        }
        public bool IsController(string ute)
        {
            bool contr = false;
            try
            {
                string sql = "SELECT Utente FROM Utenti_Controller WHERE Utente=@ute";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ute));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    contr = true;
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return contr;
        }

        public bool VerificaController(string ute, string controllato)
        {
            bool contr = false;
            try
            {
                string sql = "SELECT controllato FROM vw_UtentiController WHERE Utente=@ute AND controllato=@controllato";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ute));
                cmd.Parameters.Add(z.CreaSqlParameter("controllato", DbType.String, controllato));

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    contr = true;
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return contr;
        }

        public bool verificaExtraCee(string naz)
        {
            bool x = false;
            try
            {
                string sql = "SELECT ind_area_naz FROM Nazioni WHERE cod='" + naz + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (System.Convert.ToInt32(dt.Rows[0]["ind_area_naz"]) == 2)
                        x = true;
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return x;
        }
        public string VerificaAgente(string off, string rev)
        {
            string verif = "NO";
            try
            {
                string sql = "SELECT Id_Agente,Agente,CommissioneAgente FROM OfferteT Where Numero_Offerta='" + off + "' AND Numero_Revisione=" + System.Convert.ToString(rev);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["Agente"]))
                    {
                        if (Convert.ToString(dt.Rows[0]["Agente"]) == "NO AGENTE")
                            verif = "OK";
                        else if (dt.Rows[0]["CommissioneAgente"] is int)
                        {
                            if (Convert.ToInt16(dt.Rows[0]["CommissioneAgente"]) > 0)
                                verif = "OK";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return verif;
        }
        public bool VerificaCodificaCliente(string codCliente)
        {
            bool esito = false;
            if (codCliente != "0" & codCliente != "")
            {
                // verifica codifica completa del cliente in ESA
                try
                {
                    string sql = "SELECT ERPCODE FROM OFF_ClientiSDB where ERPCODE='" + codCliente + "'";
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                        esito = true;
                }
                catch (Exception ex)
                {
                    string err = ex.Message;
                }
            }
            return esito;
        }

        public Int32 GetNumeroCO(string Serie)
        {
            Int32 num = 1;
            try
            {
                string sql = "SELECT NumeroCO FROM OR_OrdineT WHERE SerieCO='" + Serie + "' AND Year(DataCO)=Year(GetDate())";
                sql += " ORDER BY NumeroCO DESC";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["NumeroCO"] is int)
                        num = Convert.ToInt32(dt.Rows[0]["NumeroCO"]) + 1;
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return num;
        }
        public string VerificaVatCode(string Piva)
        {
            string msg = "";
            if (Piva != "")
            {
                try
                {
                    Generic z = new Generic();
                    string sql = "SELECT PartitaIva From OFF_ClientiSDB WHERE PartitaIva=@Piva";
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(z.CreaSqlParameter("Piva", DbType.String, Piva));
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                        msg = "Customer is already in SIMEC database. For any information, please contact SIMEC.";
                    else
                    {
                        sql = "SELECT cod_piva FROM CA_ANAGRAFICHE WHERE cod_piva=@Piva";
                        cmd = new SqlCommand(sql, ConnTSE);
                        cmd.Parameters.Add(z.CreaSqlParameter("Piva", DbType.String, Piva));
                        da = new SqlDataAdapter(cmd);
                        dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                            msg = "Customer is already in SIMEC database. For any information, please contact SIMEC.";
                    }
                }
                catch (Exception ex)
                {
                    string err = ex.Message;
                }
            }
            return msg;
        }
        public string GetNomeCompleto(string ut)
        {
            try
            {
                string sql = "SELECT NomeCompleto FROM Aspnet_users WHERE UserName=@ute";
                Generic z = new Generic();
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ute", DbType.String, ut));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["NomeCompleto"]))
                        ut = (string)dt.Rows[0]["NomeCompleto"];
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return ut;
        }
        public string GetClienteById(int idcli)
        {
            string cli = "";
            try
            {
                string sql = "SELECT RagSoc FROM OFF_ClientiSDB WHERE id=" + idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    cli = (string)dt.Rows[0]["RagSoc"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return cli;
        }

        public string GetPagamentoCliente(string ErpCode, string IdCli = "")
        {
            string codpag = "";
            try
            {
                string sql = "SELECT cod_pag FROM CO_CLIFOR WHERE cod_clifor='" + ErpCode + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnTSE);
                if (IdCli != "")
                {
                    sql = "SELECT TipoPagamento as cod_pag From OFF_ClientiSDB WHERE Id=" + Convert.ToInt32(IdCli);
                    cmd = new SqlCommand(sql, ConnSDB);
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["cod_pag"]))
                        codpag = (string)dt.Rows[0]["cod_pag"];
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return codpag;
        }

        public string GetPortoCliente(string ErpCode, string IdCli = "")
        {
            string codporto = "";
            try
            {
                string sql = "SELECT  Rtrim(cod_porto) as cod_porto FROM CO_CLIFOR WHERE cod_clifor='" + ErpCode + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnTSE);
                if (IdCli != "")
                {
                    sql = "SELECT Porto as cod_porto From OFF_ClientiSDB WHERE Id=" + Convert.ToInt32(IdCli);
                    cmd = new SqlCommand(sql, ConnSDB);
                }
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["cod_porto"]))
                        codporto = (string)dt.Rows[0]["cod_porto"];
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return codporto;
        }

        public string caricaPagamentoCliente(string ErpCode)
        {
            string codpag = "";
            try
            {
                string sql = "SELECT * FROM CO_CLIFOR WHERE cod_clifor='" + ErpCode + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    codpag = (string)dt.Rows[0]["cod_pag"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return codpag;
        }
        public string getLingua(int IdCliente)
        {
            string lingua = "IT";
            try
            {
                string sql = "Select CodLingua,Nazione from OFF_ClientiSDB where Id=" + IdCliente;
                SqlCommand mycmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["CodLingua"]))
                    {
                        lingua = (string)dt.Rows[0]["CodLingua"];
                        lingua = impostaLingua(lingua);
                    }
                    else if (dt.Rows[0]["Nazione"].ToString().ToUpper().Trim() != "ITALIA")
                        lingua = "EN";
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return lingua;
        }

        public string impostaLingua(string lg)
        {
            switch (lg)
            {
                case "000":
                    {
                        lg = "IT";
                        break;
                    }

                case "001":
                    {
                        lg = "EN";
                        break;
                    }

                case "002":
                    {
                        lg = "FR";
                        break;
                    }

                case "003":
                    {
                        lg = "DE";
                        break;
                    }

                case "004":
                    {
                        lg = "ES";
                        break;
                    }

                case "IT":
                    {
                        lg = "000";
                        break;
                    }

                case "EN":
                    {
                        lg = "001";
                        break;
                    }

                case "FR":
                    {
                        lg = "002";
                        break;
                    }

                case "DE":
                    {
                        lg = "003";
                        break;
                    }

                case "ES":
                    {
                        lg = "004";
                        break;
                    }

                default:
                    {
                        lg = "EN";
                        break;
                    }
            }
            return lg;
        }
        public string RecuperaEmailCommerciale(string refcomm)
        {
            string Email = "";
            try
            {
                string sql = "SELECT Email FROM vw_aspnet_MembershipUsers Where NomeCompleto='" + refcomm + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[0]["Email"]))
                        Email = (string)ds.Tables[0].Rows[0]["Email"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return Email;
        }

        public string RecuperaTelCommerciale(string refcomm)
        {
            string Tel = "";
            try
            {
                string sql = "SELECT Email FROM vw_aspnet_MembershipUsers Where NomeCompleto='" + refcomm + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[0]["MobilePIN"]))
                        Tel = (string)ds.Tables[0].Rows[0]["MobilePIN"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return Tel;
        }

        public string VerificaManager(Int32 Idcli, string nome)
        {
            string ruolo = "";
            try
            {
                nome = GetNomeCompleto(nome);
                string sql = "SELECT Manager,BackOffice FROM OFF_ClientiSDB WHERE Id=" + Idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["Manager"]))
                    {
                        if (Convert.ToString(dt.Rows[0]["Manager"]) == nome)
                            ruolo = "Manager";
                    }
                    if (!Convert.IsDBNull(dt.Rows[0]["BackOffice"]))
                    {
                        if (Convert.ToString(dt.Rows[0]["BackOffice"]) == nome)
                            ruolo = "BackOffice";
                    }
                }

                sql = "SELECT ProductManager FROM OFF_SettoriClienti WHERE IdCliente=" + Idcli;
                cmd = new SqlCommand(sql, ConnSDB);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (!Convert.IsDBNull(dt.Rows[i]["ProductManager"]))
                    {
                        string x = (string)dt.Rows[i]["ProductManager"];
                        if (x == nome)
                        {
                            ruolo = "ProductManager";
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return ruolo;
        }
        public string GetNoteCliente(Int32 idcli)
        {
            string msg = "";
            try
            {
                string sql = "SELECT Nota FROM OFF_NoteCliente WHERE IdCliente=" + idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (!Convert.IsDBNull(dt.Rows[i]["Nota"]))
                        msg += dt.Rows[i]["Nota"].ToString().Trim() + " - ";
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return msg;
        }

    }
}