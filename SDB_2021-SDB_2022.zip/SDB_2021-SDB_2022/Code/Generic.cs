﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class Generic
    {
        private readonly SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        private readonly SqlConnection ConnTSE = new SqlConnection(ConfigurationManager.ConnectionStrings["TSE"].ConnectionString);

        public SqlParameter CreaSqlParameter(string nomeParametro, DbType dbType, object value, int limitParameter = 0)
        {
            SqlParameter par = new SqlParameter();
            par.ParameterName = nomeParametro;
            par.DbType = dbType;
            if (value != null)
            {
                par.IsNullable = true;
                par.Value = DBNull.Value;
            }
            else if (dbType == DbType.DateTime)
            {
                if (value is DateTime)
                    par.Value = (DateTime)value;
                else if ((value) is TimeSpan)
                    par.Value = value;
                else
                    par.Value = DBNull.Value;
            }
            else if (value is Int16 | value is Int32)
            {
                if ((dbType == DbType.Int16 | dbType == DbType.Int32))
                    par.Value = System.Convert.ToInt32(value);
                else if (dbType == DbType.Double)
                    par.Value = System.Convert.ToDouble(value);
                else if (dbType == DbType.Boolean)
                    par.Value = value;
                else
                    // è un numero ma lo salvo in un campo string
                    par.Value = value;
            }
            else if ((dbType == DbType.String & limitParameter != 0))
            {
                if (value.ToString().Length > limitParameter)
                    par.Value = value.ToString().Remove(limitParameter);
                else
                    par.Value = value;
            }
            else if ((dbType == DbType.Int16 | dbType == DbType.Int32 | dbType == DbType.Double))
                par.Value = 0;
            else
                par.Value = value;
            return par;
        }

        public string getBanca(string codcli, string val)
        {
            string ris = "";
            try
            {
                string sql1 = "SELECT * FROM CO_CLIFOR WHERE cod_clifor='" + codcli + "'";
                SqlCommand cmdPag = new SqlCommand(sql1, ConnTSE);
                DataSet dsPag = new DataSet();
                SqlDataAdapter daPag = new SqlDataAdapter(cmdPag);
                daPag.Fill(dsPag);


                if (dsPag.Tables[0].Rows.Count > 0)
                {
                    if (val == "BA")
                    {
                        if (!Convert.IsDBNull(dsPag.Tables[0].Rows[0]["Cod_Banca1"]))
                            ris = (string)dsPag.Tables[0].Rows[0]["Cod_Banca1"];
                    }
                    if (val == "AG")
                    {
                        if (!Convert.IsDBNull(dsPag.Tables[0].Rows[0]["Cod_Agenzia1"]))
                            ris = (string)dsPag.Tables[0].Rows[0]["Cod_Agenzia1"];
                    }
                    if (val == "AZ")
                    {
                        if (!Convert.IsDBNull(dsPag.Tables[0].Rows[0]["cod_agenzia_azi"]))
                            ris = (string)dsPag.Tables[0].Rows[0]["cod_agenzia_azi"];
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return ris;
        }

        public string getPianoConti(string codcli)
        {
            string cod = "";
            try
            {
                string sql_pc = "SELECT * FROM CO_CLIFOR_PIACONT WHERE cod_clifor='" + codcli + "'";
                SqlCommand cmd_pc = new SqlCommand(sql_pc, ConnTSE);
                SqlDataAdapter da_pc = new SqlDataAdapter(cmd_pc);
                DataTable ds_pc = new DataTable();
                da_pc.Fill(ds_pc);
                if (ds_pc.Rows.Count > 0)
                    cod = (string)ds_pc.Rows[0]["cod_piacont"];
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return cod;
        }
            public string getSedeDiv(string codcli, int idsede)
            {
                string cod = "0";
                try
                {
                    string sql = "select cdn_sede,RagSoc FROM OFF_DestinazioniClienti WHERE Id=" + System.Convert.ToString(idsede);
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        if (!Convert.IsDBNull(dt.Rows[0]["cdn_sede"]))
                            cod = (string)dt.Rows[0]["cdn_sede"];
                    }
                    
                }
                catch (Exception ex)
                {
                    string err = ex.Message;
                }
                return cod;
            }

            public string getCodIVA(string codcli)
            {
                string cod = "";
                try
                {
                    string sql_iva = "SELECT * FROM CO_CLIFOR WHERE cod_clifor='" + codcli + "'";
                    SqlCommand cmd_iva = new SqlCommand(sql_iva, ConnSDB);
                    SqlDataAdapter da_iva = new SqlDataAdapter(cmd_iva);
                    DataSet ds_iva = new DataSet();
                    da_iva.Fill(ds_iva);
                    string codiceIva = "";
                    if (ds_iva.Tables[0].Rows.Count > 0)
                    {
                        if (!Convert.IsDBNull((string)ds_iva.Tables[0].Rows[0]["Cod_Iva"]))
                            cod = (string)ds_iva.Tables[0].Rows[0]["Cod_Iva"];
                    }
                }
                catch (Exception ex)
                {
                string err = ex.Message;
            }
            return cod;
            }
        }

    }