﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace SDB_2021.Code
{
    public class Supporto
    {
        private readonly SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        private readonly SqlConnection ConnTSE = new SqlConnection(ConfigurationManager.ConnectionStrings["TSE"].ConnectionString);

        public DateTime Get_DataScadenza(DateTime data, string nazione = "")
        {
            int gg = 30;
            if (nazione.ToUpper() == "RUSSIA (FEDERAZIONE)" | nazione.ToUpper() == "BIELORUSSIA" | nazione.ToUpper() == "UCRAINA" | nazione.ToUpper() == "PAKISTAN")
                gg = 30;
            DateTime d = new DateTime();
            d= d.AddDays(gg);
            return d;
        }

        
        public string verifica_NumeroOfferta()
        {
            // Verifica che l'offerta corrente non sia già stata salvata
            string serie = "O" + Total.Right(Convert.ToString(DateTime.Now.Year), 2);
            string numOff = "1/" + serie;
            string sql = "Select Numero_Offerta,Num_Offerta FROM OfferteT where Serie_Offerta='" + serie + "' Order By Num_Offerta DESC";
            SqlCommand mycmd = new SqlCommand(sql, ConnTSE);
            SqlDataAdapter da = new SqlDataAdapter(mycmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                // l'offerta corrente è già stata salvata da un altro utente per cui la incremento di 1
                int i = System.Convert.ToInt32(ds.Tables[0].Rows[0]["Num_Offerta"]) + 1;
                numOff = i + "/" + serie;
            }
            return numOff;
        }

        public string verificaBloccoDocumentiCliente(string codClienteEsa)
        {
            string msg = "";
            try
            {
                string sql = "SELECT ind_fido_doc_evas From CO_CLIFOR where cod_clifor='" + codClienteEsa + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnTSE);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["ind_fido_doc_evas"] is int)
                    {
                        if ((int)dt.Rows[0]["ind_fido_doc_evas"] == 5)
                            msg = "CLIENTE BLOCCATO - Contattare amministrazione";
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return msg;
        }

        public string verificaPagamentoCliente(string matr)
        {
            string msg = "";
            try
            {
                SqlCommand command2 = new SqlCommand(("SELECT cod_pag FROM XMEL_IMPEGNI_MATR WHERE MATRICOLA='" + matr + "'"), ConnTSE);
                DataSet set4 = new DataSet();
                SqlDataAdapter sqlda2 = new SqlDataAdapter(command2);
                sqlda2.Fill(set4);
                string pagcli = "";
                if ((set4.Tables[0].Rows.Count > 0))
                {
                    if (!Convert.IsDBNull(set4.Tables[0].Rows[0]["cod_pag"]))
                        pagcli = (string)set4.Tables[0].Rows[0]["cod_pag"];
                }

                string sql = "SELECT ind_libero2 From CA_PAGAMT where cod_pag='" + pagcli + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnTSE);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["ind_libero2"]))
                    {
                        if ((string)dt.Rows[0]["ind_libero2"] == "M")
                            msg = "CLIENTE CON PAGAMENTO A MERCE PRONTA - Contattare amministrazione";
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return msg;
        }
        public string getLingua(int codClienteCRM)
        {
            string lingua = "IT";
            try
            {
                string sql = "Select CodLingua,Paese from Clienti where IDCliente=" + codClienteCRM;
                SqlCommand mycmd = new SqlCommand(sql, ConnTSE);
                SqlDataAdapter da = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["CodLingua"]))
                    {
                        lingua = (string)dt.Rows[0]["CodLingua"];
                        lingua = impostaLingua(lingua);
                    }
                    else if (dt.Rows[0]["Paese"].ToString().ToUpper().Trim() != "ITALIA")
                        lingua = "EN";
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }

            return lingua;
        }

        public string getDescrizioneFornitura(string forn)
        {
            string desc = "";
            switch (forn)
            {
                case "A":
                    {
                        desc = "A - F/C - COMPLETE SUPPLY";
                        break;
                    }

                case "C":
                    {
                        desc = "C - C/L NUOVO - REFURBISHMENT NEW";
                        break;
                    }

                case "D":
                    {
                        desc = "D - C/L RICAMBIO - REFURBISHMENT";
                        break;
                    }
            }

            return desc;
        }
        public string descrArticolo(string codArt, string lg)
        {
            string desc = "";
            try
            {
                // descrizione articolo
                string des_art = "";
                string xyz = codArt.Trim();
                xyz=
                xyz = Total.Right(xyz, xyz.Length - 1);
                if (xyz == "_LavAgg")
                {
                    if (lg == "IT")
                        des_art = "Lavorazioni aggiuntive";
                    else
                        des_art = "Additional workings";
                }
                else
                {
                    string sql_art = "Select * from Sottofamiglie_Prodotti WHERE Codice_Famiglia='" + Total.Left(codArt, 1) + "' AND Codice_Sottofamiglia='" + Total.Left(Total.Right(codArt, codArt.Length - 1), 2) + "'";
                    var cmd_art = new SqlCommand(sql_art, ConnSDB);

                    SqlDataAdapter da_art = new SqlDataAdapter(cmd_art);
                    DataSet ds_art = new DataSet();
                    da_art.Fill(ds_art);
                    if (ds_art.Tables[0].Rows.Count > 0)
                    {
                        if (lg == "IT")
                        {
                            if (!Convert.IsDBNull(ds_art.Tables[0].Rows[0]["Descrizione_Breve"].ToString()))
                                des_art = (string)ds_art.Tables[0].Rows[0]["Descrizione_Breve"];
                        }
                        else if (!Convert.IsDBNull(ds_art.Tables[0].Rows[0]["Descrizione_Breve_EN"].ToString()))
                            des_art = (string)ds_art.Tables[0].Rows[0]["Descrizione_Breve_EN"];
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return desc;
        }

        public string Insert_CodiceArticolo(string codArt, string fam, string stru, string forn, string disegno, string matricola, string descr, string descr_EN, double tavola, double diametro, string sotfam)
        {
            string ris = "OK";
            string sql = "";
            SqlConnection conn_USIM = new SqlConnection(ConfigurationManager.ConnectionStrings["Order_SIM"].ConnectionString);
            SqlCommand cmd;
            try
            {
                conn_USIM.Open();
                // Inserisce articolo in MG_ARTBASE

                string UM = "NR";
                // se l'articolo è a kg va inserito il KG come unità di misura
                if (sotfam.Trim() == "BC")
                    UM = "KG";

                sql = "INSERT INTO MG_ARTBASE (cod_art,ind_tiporiga,des_articolo,cod_um,cod_iva_ven,cod_iva_acq,cod_gruppostat,cod_nomen_comb,flg_stampa_invent,";
                sql = sql + "flg_stampa_schede, qta_massa_unit_kg, ind_tipoart, flg_gest_lotti, flg_gest_matr, qta_pes_lordo_kg, qta_pes_netto_kg, ";
                sql = sql + "qta_min_ordin, qta_max_ordin, qta_min_ord_for, des_campo_libero5, des_campo_libero22, val_campo_libero7, ";
                sql = sql + "val_campo_libero8, val_campo_libero9, val_campo_libero10, val_campo_libero11, ind_valoriz_fis, flg_prz_sca, flg_trasf, ";
                sql = sql + "qta_scorta_min, qta_scorta_max, qta_lotto_riord, cod_cpart_cos, cod_cpart_ric, val_costo_std, flg_vis_ecom, dim_volume_colli, ";
                sql = sql + "qta_punto_riord, cod_utente_cre, dat_utente_cre, cod_utente_mod, dat_utente_mod, flg_gen_mov_cos, flg_gen_mov_ric, ";
                sql = sql + "des_campo_libero19, des_campo_libero20, des_campo_libero21, ind_imp_comp_db, qta_contenitore, ind_categoria_art, flg_conf_articolo,";
                sql = sql + "flg_collezioni, ind_trasf_plu, ind_trasf_bilance, prc_ricar_ven, ind_art_st_var_mov, flg_exp_tutti_pv, ind_stato_trasf, ";
                sql = sql + "ind_valorizz_car, prc_ricarico_car, ind_tipo_car_val, flg_som_qta_multid, ind_acquisizione, flg_gest_commesse, flg_art_ritenute,";
                sql = sql + "flg_art_cassaprev, flg_bene_usato, flg_no_multidim, ind_new_art_diban, flg_sogg_revcha, flg_comm_gest_log, ";
                sql = sql + "flg_lotti_gest_log, flg_matr_gest_log,cod_gencod_matri,";
                sql = sql + "ind_stato_onoff, flg_inv_palmari,ind_produzione_art,cod_linea,cod_naz_origine,cod_servizio)";
                sql = sql + " values (@codArt,'A',@desc_art,'" + UM + "','22','22','V',@cod_nomen_comb,";
                sql = sql + "'1','1',0,'02','0','1',0,0,0,0,0,@disegno,@struttura,0,0,0,0,0,'A','0','0',0,0,0,@cod_cpart_cos,@cod_cpart_ric,0,'0',0,0,'adme',getdate(),";
                sql = sql + "'AAcquisti',getdate(),'0','0',@fornitura,@diametro,@tavola,'0',1,'N','0','0','S','S',0,'T',0,'R','B',0,'L','1','A','1','0','0','0','0','S',";
                sql = sql + "'0','1','0','0',@cod_gencod_matri,1,0,1,@cod_linea,@cod_naz_origine,@cod_servizio)";

                cmd = new SqlCommand(sql, conn_USIM);
                // cod_gencod_matri
                SqlParameter pMatri = new SqlParameter();
                pMatri.ParameterName = "@cod_gencod_matri";
                // pMatri.DbType = DbType.String
                pMatri.Direction = ParameterDirection.Input;
                string cod_matri = fam.Trim();
                string forni = Total.Left(forn.Trim(), 1);
                if (forni == "C")
                    forni = "D";
                switch (cod_matri)
                {
                    case "D":
                        {
                            pMatri.Value = "D" + forni + "MATR";
                            break;
                        }

                    case "S":
                        {
                            pMatri.Value = "S" + forni + "MATR";
                            break;
                        }

                    case "E":
                        {
                            pMatri.Value = "E" + forni + "MATR";
                            break;
                        }

                    default:
                        {
                            pMatri.Value = "MATRI";
                            break;
                        }
                }
                cmd.Parameters.Add(pMatri);

                string sql_cpart = "SELECT * FROM Contropartite where Tipo_Fornitura='" + forn.Trim() + "' AND famiglia='" + fam.Trim() + "'";
                if (fam.Trim() == "P")
                    sql_cpart = "SELECT * FROM Contropartite where Tipo_Fornitura='A' AND famiglia='" + fam.Trim() + "' AND sottofamiglia='" + sotfam.Trim() + "'";
                SqlCommand cmd_cpart = new SqlCommand(sql_cpart, ConnSDB);
                SqlDataAdapter da_cpart = new SqlDataAdapter(cmd_cpart);
                DataSet ds_cpart = new DataSet();
                da_cpart.Fill(ds_cpart);
                // contropartita ricavi
                SqlParameter p1lp = new SqlParameter();
                p1lp.ParameterName = "@cod_cpart_ric";
                p1lp.DbType = DbType.String;
                p1lp.Value = "";
                if (ds_cpart.Tables[0].Rows.Count > 0)
                    p1lp.Value = ds_cpart.Tables[0].Rows[0]["cod_cpartitaR"];
                cmd.Parameters.Add(p1lp);
                // contropartita costi
                SqlParameter p2lp = new SqlParameter();
                p2lp.ParameterName = "@cod_cpart_cos";
                p2lp.DbType = DbType.String;
                p2lp.Value = "";
                if (ds_cpart.Tables[0].Rows.Count > 0)
                    p2lp.Value = ds_cpart.Tables[0].Rows[0]["cod_cpartitaC"];
                cmd.Parameters.Add(p2lp);
                // codice articolo
                SqlParameter p1 = new SqlParameter();
                p1.ParameterName = "@codArt";
                p1.DbType = DbType.String;
                p1.Value = codArt.Replace("&amp;","&").Trim();
                cmd.Parameters.Add(p1);
                // descrizione
                SqlParameter p2 = new SqlParameter();
                p2.ParameterName = "@desc_art";
                p2.DbType = DbType.String;
                p2.Value = descr;
                cmd.Parameters.Add(p2);
                // INSERISCE IL CODICE NOMENCLATURA CORRETTO PER L'ARTICOLO
                // @cod_nomen_comb 
                SqlParameter p3 = new SqlParameter();
                p3.ParameterName = "@cod_nomen_comb";
                Nomenclatura pnom = new Nomenclatura();
                p3.Value = pnom.GetNomenclatura(fam.Trim(), forn.Trim());
                if ((string)p3.Value == "")
                    p3.Value = DBNull.Value;
                cmd.Parameters.Add(p3);
                // @disegno
                SqlParameter p4 = new SqlParameter();
                p4.ParameterName = "@disegno";
                p4.DbType = DbType.String;
                if (disegno == "")
                    p4.Value = DBNull.Value;
                else
                    p4.Value = disegno.Replace("&amp;", "&");
                cmd.Parameters.Add(p4);
                // @struttura
                SqlParameter p5 = new SqlParameter();
                p5.ParameterName = "@struttura";
                p5.Value = stru;
                if (fam.Trim() == "P")
                    p5.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p5.Value = DBNull.Value;
                cmd.Parameters.Add(p5);
                // @fornitura
                SqlParameter p6 = new SqlParameter();
                p6.ParameterName = "@fornitura";
                p6.Value = getDescrizioneFornitura(forn);
                if (fam.Trim() == "P")
                    p6.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p6.Value = DBNull.Value;
                cmd.Parameters.Add(p6);
                // @diametro
                SqlParameter p7 = new SqlParameter();
                p7.ParameterName = "@diametro";
                string diametroString = Convert.ToString(diametro);
                diametroString = diametroString.Replace(".",",");
                p7.Value = diametroString;
                if (fam.Trim() == "P")
                    p7.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p7.Value = DBNull.Value;
                cmd.Parameters.Add(p7);
                // @tavola
                SqlParameter p8 = new SqlParameter();
                p8.ParameterName = "@tavola";
                string tavolaString = Convert.ToString(tavola);
                tavola = Convert.ToDouble(Convert.ToString(tavola).Replace(".", ","));
                p8.Value = tavola;
                if (fam.Trim() == "P")
                    p8.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p8.Value = DBNull.Value;
                cmd.Parameters.Add(p8);

                SqlParameter p9 = new SqlParameter();
                p9.ParameterName = "@cod_linea";
                p9.Value = "RULLO";
                if (fam.Trim() == "P")
                    p9.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p9.Value = "LAV_AGG";
                cmd.Parameters.Add(p9);

                SqlParameter p10a = new SqlParameter();
                p10a.ParameterName = "@cod_naz_origine";
                p10a.Value = DBNull.Value;
                if (forn.Trim() == "A")
                    p10a.Value = "000";
                cmd.Parameters.Add(p10a);


                SqlParameter p10 = new SqlParameter();
                p10.ParameterName = "@cod_servizio";

                p10.Value = pnom.GetCodiceServizio(fam.Trim(), forn.Trim()).Trim();
                if ((string)p10.Value == "")
                    p10.Value = DBNull.Value;
                cmd.Parameters.Add(p10);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ris = ex.Message;
            }
            try
            {
                // Inserisce articolo in MG_ARTBASEUM
                string UM = "NR";
                // se l'articolo è a kg va inserito il KG come unità di misura
                if (sotfam != "&nbsp;")
                {
                    if (sotfam.Trim() == "BC")
                        UM = "KG";
                }
                sql = "INSERT INTO MG_ARTBASEUM (flg_principale, flg_produzione, mlt_unimis, mlt_unimis_div, cod_art, cod_um, cod_utente_cre, dat_utente_cre, cod_utente_mod, dat_utente_mod)";
                sql = sql + " values ('1', '0', 1, 1, @codart, '" + UM + "', 'adme', GETDATE() , 'adme', GETDATE())";

                cmd = new SqlCommand(sql, conn_USIM);
                // codice articolo
                SqlParameter p1 = new SqlParameter();
                p1.ParameterName = "@codArt";
                p1.DbType = DbType.String;
                p1.Direction = ParameterDirection.Input;
                p1.Value = codArt.Trim();
                cmd.Parameters.Add(p1);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ris = ex.Message;
            }
            try
            {
                // Inserisce articolo in MG_ARTICOLI
                sql = "INSERT INTO MG_ARTICOLI (des_articolo, des_campo_libero22,des_campo_libero19, des_campo_libero20, des_campo_libero21, dim_volume_colli, flg_trasf, num_liv_min_db, prc_ricar_ven, prc_ricarico_car, qta_contenitore, qta_lotto_riord, qta_max_ordin, qta_min_ord_for, qta_min_ordin, qta_pes_lordo_kg, qta_pes_netto_kg, qta_punto_riord, qta_scorta_max, qta_scorta_min, val_campo_libero10, val_campo_libero11, val_campo_libero7, val_campo_libero8, val_campo_libero9, val_costo_std, cod_art, prg_art, cod_utente_cre, dat_utente_cre, cod_utente_mod, dat_utente_mod)";
                sql = sql + "values (@desc_art, @struttura,@fornitura,@diametro,@tavola, 0, '0', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, @codArt, 1, 'adme', GETDATE() , 'adme', GETDATE())";
                cmd = new SqlCommand(sql, conn_USIM);
                // codice articolo
                SqlParameter p1 = new SqlParameter();
                p1.ParameterName = "@codArt";
                p1.DbType = DbType.String;
                p1.Direction = ParameterDirection.Input;
                p1.Value = codArt.Replace("&amp;", "&").Trim();
                cmd.Parameters.Add(p1);
                // descrizione
                SqlParameter p2 = new SqlParameter();
                p2.ParameterName = "@desc_art";
                p2.DbType = DbType.String;
                p2.Value = descr;
                cmd.Parameters.Add(p2);
                // @struttura
                SqlParameter p5 = new SqlParameter();
                p5.ParameterName = "@struttura";
                p5.DbType = DbType.String;
                p5.Value = stru;
                if (fam.Trim() == "P")
                    p5.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p5.Value = DBNull.Value;
                cmd.Parameters.Add(p5);
                // @fornitura
                SqlParameter p6 = new SqlParameter();
                p6.ParameterName = "@fornitura";
                p6.Value = forn;
                if (fam.Trim() == "P")
                    p6.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p6.Value = DBNull.Value;
                cmd.Parameters.Add(p6);
                // @diametro
                SqlParameter p7 = new SqlParameter();
                p7.ParameterName = "@diametro";
                p7.Value = diametro;
                if (fam.Trim() == "P")
                    p7.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p7.Value = DBNull.Value;
                cmd.Parameters.Add(p7);
                // @tavola
                SqlParameter p8 = new SqlParameter();
                p8.ParameterName = "@tavola";
                p8.Value = tavola;
                if (fam.Trim() == "P")
                    p8.Value = DBNull.Value;
                if (Total.Right(codArt.Trim(), 7) == "_LavAgg")
                    p8.Value = DBNull.Value;
                cmd.Parameters.Add(p8);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ris = ex.Message;
            }
            try
            {
                // Inserisce articolo in MG_ARTICOLILIN
                sql = "INSERT INTO MG_ARTICOLILIN (cod_lingua, cod_art, prg_art, des_articolo, cod_utente_cre,dat_utente_cre, cod_utente_mod,dat_utente_mod)";
                sql = sql + " values ('001', @codArt,1, @desc_EN, 'adme', getdate(), 'adme', getdate())";
                cmd = new SqlCommand(sql, conn_USIM);
                // codice articolo
                SqlParameter p1 = new SqlParameter();
                p1.ParameterName = "@codArt";
                p1.DbType = DbType.String;
                p1.Direction = ParameterDirection.Input;
                p1.Value = codArt.Trim();
                cmd.Parameters.Add(p1);
                // descrizione
                SqlParameter p2 = new SqlParameter();
                p2.ParameterName = "@desc_EN";
                p2.DbType = DbType.String;
                p2.Direction = ParameterDirection.Input;
                p2.Value = descr_EN;
                cmd.Parameters.Add(p2);
                cmd.ExecuteNonQuery();
                conn_USIM.Close();
            }
            catch (Exception ex)
            {
                ris = ex.Message;
            }
            return ris;
        }

        public string dataTrasformata(string dataOrig)
        {
            string s = "";
            System.DateTime dataRif;
            dataRif = Convert.ToDateTime(dataOrig);
            DateTime d = new DateTime();
            dataRif = Total.DateSerial(dataRif.Year, dataRif.Month, dataRif.Day);
            dataRif = Total.DateSerial(dataRif.Year - 1, dataRif.Month, dataRif.Day);
            s = dataRif.Year + "/" + dataRif.Month + "/" + dataRif.Day;
            // s = Day(dataRif) & "/" & Month(dataRif) & "/" & Year(dataRif)
            return s;
        }

        public string caricaContattiCRM(string cod_cliente_CRM, string codCli, string sede, string tipo, string cliente = "")
        {
            string s = "";
            try
            {
                // recupera sede cliente

                if (Total.Left(sede, 1) == "0" | sede == "")
                    sede = "SEDE Sede Anagrafica";

                string sql = "SELECT [Nome], [Cognome],Email1 FROM [vw_ContattiClienti] WHERE  Documento like '%" + tipo + "%' AND [IDCliente] =" + System.Convert.ToString(cod_cliente_CRM) + " AND SEDE like '%' + @sede + '%'";
                if (sede == "")
                    sql = "SELECT [Nome], [Cognome],Email1 FROM [vw_ContattiClienti] WHERE  AND Documento like '%" + tipo + "%' AND [IDCliente] =" + System.Convert.ToString(cod_cliente_CRM);

                SqlCommand mycmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@sede";
                par.DbType = DbType.String;
                par.Value = sede;
                mycmd.Parameters.Add(par);
                SqlDataAdapter da = new SqlDataAdapter(mycmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                for (var i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[i]["Nome"]))
                        s = s + ds.Tables[0].Rows[i]["Nome"];
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[i]["Cognome"]))
                        s = s + " " + ds.Tables[0].Rows[i]["Cognome"] + "\n";
                }
                s = s.Trim();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return s;
        }
        public string impostaLingua(string lg)
        {
            switch (lg)
            {
                case "000":
                    {
                        lg = "IT";
                        break;
                    }

                case "1":
                    {
                        lg = "EN";
                        break;
                    }

                case "2":
                    {
                        lg = "FR";
                        break;
                    }

                case "3":
                    {
                        lg = "DE";
                        break;
                    }

                case "4":
                    {
                        lg = "ES";
                        break;
                    }

                case "IT":
                    {
                        lg = "000";
                        break;
                    }

                case "EN":
                    {
                        lg = "001";
                        break;
                    }

                case "FR":
                    {
                        lg = "002";
                        break;
                    }

                case "DE":
                    {
                        lg = "003";
                        break;
                    }

                case "ES":
                    {
                        lg = "004";
                        break;
                    }

                default:
                    {
                        lg = "EN";
                        break;
                    }
            }
            return lg;
        }

        public string caricaContattiCRM(string cod_cliente_CRM, string sede, string tipo)
        {
            string s = "";
            try
            {
                // recupera sede cliente
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);

                string sql = "SELECT [Nome], [Cognome],Email1 FROM [XMEL_contatti_clienti],XMEL_caratt_13228_contatti_clienti WHERE CodContatto=IDContatto AND Nota like '%" + tipo + "%' AND [IDCliente] =" + System.Convert.ToString(cod_cliente_CRM) + " AND ((Left(SEDE,1)=@sede AND Left(SEDE,2)<10) OR (Left(SEDE,2)=@sede AND Left(SEDE,2)>=10))";
                if (sede == "")
                    sql = "SELECT [Nome], [Cognome],Email1 FROM [XMEL_contatti_clienti],XMEL_caratt_13228_contatti_clienti WHERE CodContatto=IDContatto AND Nota like '%" + tipo + "%' AND (SEDE is Null OR SEDE='') AND [IDCliente] =" + System.Convert.ToString(cod_cliente_CRM);

                SqlCommand mycmd = new SqlCommand(sql, sqlconn);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@sede";
                par.DbType = DbType.String;
                par.Value = sede;
                mycmd.Parameters.Add(par);
                SqlDataAdapter da = new SqlDataAdapter(mycmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                for (var i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[i]["Email1"]))
                        s = s + ds.Tables[0].Rows[i]["Email1"] + ",";
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return s;
        }

        public string inviaMail(string refCli, string comm, string testo, string oggetto, string EmailSupp = "", string isHtml = "", string allegato = "", string EmailCommCli = "", string myBcc = "", string logo = "")
        {
            string esito = "no";
            try
            {
                // momentaneamente manda la mail solo al commerciale SIMEC
                MailAddress From = new MailAddress("noreply@simecgroup.com", "Simec Group srl", System.Text.Encoding.UTF8);

                // escludo l'ultimo indirizzo se è vuoto
                if (refCli != "")
                {
                    if (Total.Right(refCli, 1) == ",")
                        refCli = Total.Left(refCli, refCli.Length - 1);
                }
                List<string> dest = new List<string>(
                    refCli.Split(new string[] { "," }, StringSplitOptions.None));
                int numcont = dest.Count();
                if (refCli == "")
                    numcont = 0;
                else if (EmailSupp == "")
                    EmailSupp = dest[0];
                if (comm == "")
                    comm = EmailSupp;
                MailAddress to = new MailAddress(comm);
                MailMessage mail = new MailMessage(From, to);
                if (numcont == 0)
                {
                    // non ci sono i contatti del cliente, invia mail solo al commerciale. Lo avvisa di compilare contatti del cliente???
                    to = new MailAddress(comm);
                    mail = new MailMessage(From, to);
                    testo = "ATTENZIONE QUESTO CLIENTE NON HA UN RIFERIMENTO PER INVIO DOCUMENTAZIONE IN OGGETTO" + "\n" + testo;
                }
                else
                {
                    // primo contatto del cliente
                    for (var k = 0; k <= numcont - 1; k++)
                        // secondo contatto del cliente
                        mail.To.Add(new MailAddress(dest[k].ToString()));
                    // commerciale simec
                    if (comm != "")
                    {
                        mail.To.Remove(new MailAddress(comm));
                        mail.CC.Add(comm);
                    }
                    if (EmailCommCli != "")
                        mail.CC.Add(EmailCommCli);
                }
                // supporto interno simec
                if (EmailSupp != "")
                    mail.CC.Add(EmailSupp);
                if (myBcc != "")
                    mail.Bcc.Add(myBcc);
                mail.Body = testo;
                if (isHtml == "")
                    mail.BodyEncoding = System.Text.Encoding.UTF8;
                else
                    mail.IsBodyHtml = true;
                mail.Subject = oggetto;
                mail.SubjectEncoding = System.Text.Encoding.UTF8;

                if (logo != "")
                {
                    Attachment attLogo = new Attachment(logo);
                    mail.Attachments.Add(attLogo);
                    mail.Attachments[0].ContentDisposition.Inline = true;
                    mail.Attachments[0].ContentId = "Logo.png";
                }

                if (allegato != "")
                {
                    Attachment att = new Attachment(allegato);
                    mail.Attachments.Add(att);
                }

                string host = "maildelivery.cloudifi.it";
                string username = "IT01400-ERP";
                string password = "xzSfbMV8ZpP7VUNv";
                SmtpClient SmtpClient = new SmtpClient(host)
                {
                    Port = 25,
                    Credentials = new System.Net.NetworkCredential(username, password)
                };
                SmtpClient.Send(mail);
                if (refCli != "")
                    esito = "ok";
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                esito = err;
            }
            return esito;
        }

        public string InviaMailMultiAllegato(string refCli, string comm, string testo, string oggetto, string[] allegato, string EmailSupp = "", string isHtml = "", string EmailCommCli = "", string myBcc = "", string logo = "")
        {
            string esito = "no";
            try
            {
                // momentaneamente manda la mail solo al commerciale SIMEC
                MailAddress From = new MailAddress("noreply@simecgroup.com", "Simec Group srl", System.Text.Encoding.UTF8);

                // escludo l'ultimo indirizzo se è vuoto
                if (refCli != "")
                {
                    if (Total.Right(refCli, 1) == ",")
                        refCli = Total.Left(refCli, refCli.Length - 1);
                }
                List<string> dest = new List<string>(
                    refCli.Split(new string[] {","},StringSplitOptions.None));
                int numcont = dest.Count();
                if (refCli == "")
                    numcont = 0;
                else if (EmailSupp == "")
                    EmailSupp = dest[0];
                if (comm == "")
                    comm = EmailSupp;
                MailAddress to = new MailAddress(comm);
                MailMessage mail = new MailMessage(From, to);
                if (numcont == 0)
                {
                    // non ci sono i contatti del cliente, invia mail solo al commerciale. 
                    to = new MailAddress(comm);
                    mail = new MailMessage(From, to);
                }
                else
                {
                    // primo contatto del cliente
                    for (var k = 0; k <= numcont - 1; k++)
                        // secondo contatto del cliente
                        mail.To.Add(new MailAddress(dest[k].ToString()));
                    // commerciale simec
                    if (comm != "")
                    {
                        mail.To.Remove(new MailAddress(comm));
                        mail.CC.Add(comm);
                    }
                }
                if (EmailCommCli != "")
                    mail.CC.Add(EmailCommCli);
                // supporto interno simec
                if (EmailSupp != "")
                    mail.CC.Add(EmailSupp);
                if (myBcc != "")
                    mail.Bcc.Add(myBcc);
                mail.Body = testo;
                if (isHtml == "")
                    mail.BodyEncoding = System.Text.Encoding.UTF8;
                else
                    mail.IsBodyHtml = true;
                mail.Subject = oggetto;
                mail.SubjectEncoding = System.Text.Encoding.UTF8;
                for (var i = 0; i <= allegato.Count() - 1; i++)
                {
                    if (allegato[i] != "")
                    {
                        Attachment att = new Attachment(allegato[i]);
                        mail.Attachments.Add(att);
                    }
                }

                if (logo != "")
                {
                    Attachment attLogo = new Attachment(logo);
                    mail.Attachments.Add(attLogo);
                    mail.Attachments[0].ContentDisposition.Inline = true;
                    mail.Attachments[0].ContentId = "Logo.png";
                }

                string host = "maildelivery.cloudifi.it";
                string username = "IT01400-ERP";
                string password = "xzSfbMV8ZpP7VUNv";
                SmtpClient SmtpClient = new SmtpClient(host)
                {
                    Port = 25,
                    Credentials = new System.Net.NetworkCredential(username, password)
                };
                SmtpClient.Send(mail);

                // Dim host As String = "192.168.109.102"
                // Dim username As String = "noreply@simecgroup.com"
                // Dim password As String = "17Smtpn0r3p"
                // Dim SmtpClient As SmtpClient = New SmtpClient(host)
                // SmtpClient.Port = 10025
                // SmtpClient.Credentials = New System.Net.NetworkCredential(username, password)
                // SmtpClient.Send(mail)

                if (refCli != "" | comm != "")
                    esito = "ok";
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                esito = err;
            }
            return esito;
        }

        public string RecuperaEmailCommerciale(string refcomm)
        {
            string Email = "";
            try
            {
                string sql = "SELECT Email FROM vw_aspnet_MembershipUsers Where NomeCompleto='" + refcomm + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[0]["Email"]))
                        Email = (string)ds.Tables[0].Rows[0]["Email"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return Email;
        }

        public string InviaMailSogliaMagazzino(string refCli, string comm, string testo, string oggetto, string suppInterno = "", int mag = 0, string comm2 = "", string comm3 = "")
        {
            string ris = "";
            try
            {
                MailAddress From = new MailAddress("noreply@simecgroup.com", "Simec Group srl", System.Text.Encoding.UTF8);

                List<string> dest = new List<string>(
                    refCli.Split(new string[] { "," }, StringSplitOptions.None));
                int numcont = dest.Count();
                if (refCli == "")
                {
                    refCli = comm;
                    comm = "";
                }
                MailAddress to = new MailAddress(refCli);
                MailMessage mail = new MailMessage(From, to);
                if (comm != "")
                {
                    if (mag == 1)
                        mail.CC.Add(new MailAddress(comm));
                    else
                        mail.To.Add(new MailAddress(comm));
                }
                if (comm2 != "")
                {
                    mail.To.Add(new MailAddress(comm2));
                    mail.To.Remove(new MailAddress(refCli)); // toglie dai destinatari il referente cliente per volere SIMEC
                }
                if (comm3 != "")
                    mail.To.Add(new MailAddress(comm3));
                if (suppInterno != "")
                    mail.CC.Add(new MailAddress(suppInterno));

                mail.Body = testo;
                mail.IsBodyHtml = true;
                mail.Subject = oggetto;
                mail.SubjectEncoding = System.Text.Encoding.UTF8;

                string host = "192.168.109.102";
                string username = "noreply@simecgroup.com";
                string password = "17Smtpn0r3p";
                SmtpClient SmtpClient = new SmtpClient(host);
                SmtpClient.Port = 10025;
                SmtpClient.Credentials = new System.Net.NetworkCredential(username, password);
                SmtpClient.Send(mail);
                ris = "OK";
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return ris;
        }

        public string RecuperaEmailFornitore(string cod_Fornitore)
        {
            string Email = "";
            try
            {
                string sql = "SELECT Email FROM Acq_Fornitori Where Fornitore='" + cod_Fornitore + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(ds.Tables[0].Rows[0]["Email"]))
                        Email = (string)ds.Tables[0].Rows[0]["Email"];
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return Email;
        }

        public string ResponsabileInternoCliente(string codCliente)
        {
            string resp = "";
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                var cmd = new SqlCommand(("SELECT Nota From Caratteristiche_Clienti Where Nota<>'' AND CodCaratteristica=13220 AND CodCliente=" + codCliente), sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    resp = (string)ds.Tables[0].Rows[0]["Nota"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return resp;
        }

        public bool AderitoTrasportoSDB(object IDCliente_CRM)
        {
            bool aderito = false;
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                var cmd = new SqlCommand(("SELECT Nota From Caratteristiche_Clienti Where Nota<>'' AND CodCaratteristica=78263 AND CodCliente=" + IDCliente_CRM), sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    aderito = System.Convert.ToBoolean(ds.Tables[0].Rows[0]["Nota"]);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return aderito;
        }
        public int GetCodiceClienteCRM(string codiceClienteEsa)
        {
            int cod = 0;
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                var cmd = new SqlCommand(("SELECT IDCliente From CLIENTI Where Codice='" + codiceClienteEsa + "'"), sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    cod = System.Convert.ToInt32(ds.Tables[0].Rows[0]["IDCliente"]);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }

            return cod;
        }

        public string GetCodiceClienteESA(string codiceClienteCRM)
        {
            string cod = "0";
            try
            {
                SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["CRM_Sim"].ConnectionString);
                var cmd = new SqlCommand(("SELECT Codice From CLIENTI Where IDCliente=" + System.Convert.ToString(codiceClienteCRM) + " ORDER BY IDCliente DESC"), sqlconn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    cod = (string)ds.Tables[0].Rows[0]["Codice"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }

            return cod;
        }
        public string GetCodiceFornitore(string fornitore)
        {
            string cod = "0";
            try
            {
                var cmd = new SqlCommand(("SELECT CodFornitore From Acq_Fornitori Where Fornitore='" + fornitore + "'"), ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if ((ds.Tables[0].Rows.Count > 0))
                    cod = (string)ds.Tables[0].Rows[0]["CodFornitore"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }

            return cod;
        }

    }
}