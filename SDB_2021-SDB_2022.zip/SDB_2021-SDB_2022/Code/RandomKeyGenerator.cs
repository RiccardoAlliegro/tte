﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SDB_2021.Code
{
    public class RandomKeyGenerator
    {
        private string Key_Letters;
        private string Key_Numbers;
        private int Key_Chars;
        private char[] LettersArray;
        private char[] NumbersArray;

        protected internal string KeyLetters
        {
            set
            {
                Key_Letters = value;
            }
        }

        protected internal string KeyNumbers
        {
            set
            {
                Key_Numbers = value;
            }
        }

        protected internal int KeyChars
        {
            set
            {
                Key_Chars = value;
            }
        }


        public string Generate()
        {
            int i_key;
            float Random1;
            Int16 arrIndex;
            StringBuilder sb = new StringBuilder();
            string RandomLetter;

            // CONVERT LettersArray & NumbersArray TO CHARACTR ARRAYS
            LettersArray = Key_Letters.ToCharArray();
            NumbersArray = Key_Numbers.ToCharArray();

            for (i_key = 1; i_key <= Key_Chars; i_key++)
            {
                VBMath.Randomize();
                Random1 = VBMath.Rnd();
                arrIndex = -1;
                // IF THE VALUE IS AN EVEN NUMBER WE GENERATE A LETTER,
                // OTHERWISE WE GENERATE A NUMBER  
                // THE NUMBER '111' WAS RANDOMLY CHOSEN. ANY NUMBER
                // WILL DO, WE JUST NEED TO BRING THE VALUE
                if ((System.Convert.ToInt32(Random1 * 111 + i_key + 2)) % 2 == 0)
                {
                    // GENERATE A RANDOM INDEX IN THE LETTERS
                    while (arrIndex < 0)
                        arrIndex = Convert.ToInt16(LettersArray.GetUpperBound(0)
                         * Random1);
                    RandomLetter = Convert.ToString(LettersArray[arrIndex]);
                    // CREATE ANOTHER RANDOM NUMBER. IF IT IS ODD,
                    // WE CAPITALIZE THE LETTER
                    // - LAITH - 27/07/2005 18:55:59 -
                    // If (CType(arrIndex * Random1 * 99, Integer)) Mod 2 <> 0 Then
                    if ((System.Convert.ToInt32(arrIndex * Random1 * 99 + i_key + 2)) % 2 != 0)
                    {
                        RandomLetter = LettersArray[arrIndex].ToString();
                        RandomLetter = RandomLetter.ToUpper();
                    }
                    sb.Append(RandomLetter);
                }
                else
                {
                    // GENERATE A RANDOM INDEX IN THE NUMBERS
                    while (arrIndex < 0)
                        arrIndex = Convert.ToInt16(NumbersArray.GetUpperBound(0)
                          * Random1);
                    sb.Append(NumbersArray[arrIndex]);
                }
            }
            return sb.ToString();
        }
    }
}