﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public static class Total
    {
        public static string Right(this string value, int length)
        {
            if (String.IsNullOrEmpty(value)) return string.Empty;

            return value.Length <= length ? value : value.Substring(value.Length - length);
        }

        public static string Left(this string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return value;
            maxLength = Math.Abs(maxLength);

            return (value.Length <= maxLength
                   ? value
                   : value.Substring(0, maxLength)
                   );
        }

        public static DateTime DateSerial(int year, int month, int day)
        {
            if (year < 0)
            {
                year = DateTime.Now.Year + year;
            }
            else if (year < 100)
            {
                year = 1930 + year;
            }
            DateTime dt = new DateTime(year, 1, 1);
            dt = dt.AddMonths(month - 1);
            dt = dt.AddDays(day - 1);

            return dt;
        }
    }
}