﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SDB_2021.Code
{
    public class FunzioniClienti
    {
        private readonly SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        private readonly SqlConnection ConnTSE = new SqlConnection(ConfigurationManager.ConnectionStrings["TSE"].ConnectionString);

        public Int32 ImportaAnagrafica(string cod)
        {
            Int32 newid = 0;
            string msg = "";
            string sql = "SELECT * FROM vw_CliFor WHERE CodCliente='" + cod + "'";
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                // controlla se non esiste in SDB
                sql = "SELECT ERPCode FROM OFF_ClientiSDB WHERE ERPCode='" + cod + "'";
                cmd = new SqlCommand(sql, ConnSDB);
                da = new SqlDataAdapter(cmd);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                if (dt1.Rows.Count == 0)
                {
                    if ((string)dt.Rows[0]["ind_bloccato"] == "NO")
                    {
                        // importa
                        sql = "INSERT INTO OFF_ClientiSDB (RagSoc,Indirizzo,Localita,Cap,Provincia,Nazione,Attivo,ERPCode,Telefono,PartitaIva,";
                        sql = sql + "CodLingua,TipoCliente,TipoPagamento,Porto,Vettore,IdAgente,Manager,Backoffice,Gruppo,DataMod,UtMod,Bloccato)";
                        sql = sql + " VALUES(@RagSoc,@Indirizzo,@Localita,@Cap,@Provincia,@Nazione,1,@ERPCode,@Telefono,@PartitaIva,";
                        sql = sql + "@CodLingua,@TipoCliente,@TipoPagamento,@Porto,@Vettore,@IdAgente,@Manager,@Backoffice,@Gruppo,GetDate(),@UtMod,@Bloccato);";
                        sql = sql + "SELECT SCOPE_IDENTITY()";
                        cmd = new SqlCommand(sql, ConnSDB);
                        Generic z = new Generic();
                        string ragsoc = (string)dt.Rows[0]["DescCliente"];
                        cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, ragsoc, 100));
                        string indir = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["Indirizzo"]))
                            indir = (string)dt.Rows[0]["Indirizzo"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Indirizzo", DbType.String, indir, 100));
                        if (!Convert.IsDBNull(dt.Rows[0]["Localita"]))
                            indir = (string)dt.Rows[0]["Localita"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Localita", DbType.String, indir, 150));
                        string cap = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["Cap"]))
                            cap = (string)dt.Rows[0]["Cap"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Cap", DbType.String, cap, 20));
                        string prov = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["Prov"]))
                            prov = (string)dt.Rows[0]["Prov"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Provincia", DbType.String, prov, 25));
                        string naz = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_naz"]))
                            naz = (string)dt.Rows[0]["cod_naz"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Nazione", DbType.String, naz, 50));
                        cmd.Parameters.Add(z.CreaSqlParameter("ERPCode", DbType.String, cod, 50));
                        string Telefono = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["sig_tel_fis"]))
                            Telefono = (string)dt.Rows[0]["sig_tel_fis"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Telefono", DbType.String, Telefono, 50));
                        string piva = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_piva"]))
                            piva = ((string)dt.Rows[0]["cod_piva"]).Trim();
                        cmd.Parameters.Add(z.CreaSqlParameter("PartitaIva", DbType.String, piva, 50));
                        string lingua = "001";
                        if (naz == "86")
                            lingua = "000";
                        cmd.Parameters.Add(z.CreaSqlParameter("CodLingua", DbType.String, lingua, 3));
                        string tipocli = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["TipoCLiente"]))
                            tipocli = (string)dt.Rows[0]["TipoCLiente"];
                        cmd.Parameters.Add(z.CreaSqlParameter("TipoCliente", DbType.String, tipocli, 50));
                        string tipopag = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_pag"]))
                            tipopag = (string)dt.Rows[0]["cod_pag"];

                        cmd.Parameters.Add(z.CreaSqlParameter("TipoPagamento", DbType.String, tipopag, 10));
                        string port = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_porto"]))
                            port = (string)dt.Rows[0]["cod_porto"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Porto", DbType.String, port, 10));
                        string Vett = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_vettore"]))
                            Vett = (string)dt.Rows[0]["cod_vettore"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Vettore", DbType.String, Vett, 10));
                        string age = "";
                        if (!Convert.IsDBNull(dt.Rows[0]["cod_vettore"]))
                            age = (string)dt.Rows[0]["cod_agente"];
                        cmd.Parameters.Add(z.CreaSqlParameter("IdAgente", DbType.Int32, age));
                        FunzioniCRM fzcrm = new FunzioniCRM();
                        string manag = "Non Attribuito";
                        if (!Convert.IsDBNull(dt.Rows[0]["resp_cliente"]))
                            manag = (string)dt.Rows[0]["resp_cliente"];
                        cmd.Parameters.Add(z.CreaSqlParameter("Manager", DbType.String, manag, 50));
                        string bkoff = "Manuela Palma";
                        cmd.Parameters.Add(z.CreaSqlParameter("Backoffice", DbType.String, bkoff, 50));
                        cmd.Parameters.Add(z.CreaSqlParameter("Gruppo", DbType.String, "", 50));
                        cmd.Parameters.Add(z.CreaSqlParameter("UtMod", DbType.String, HttpContext.Current.User.Identity.Name.ToString(), 50));
                        bool bloc = false;
                        if (!Convert.IsDBNull(dt.Rows[0]["ind_bloccato"]))
                        {
                            if (((string)dt.Rows[0]["ind_bloccato"]).Trim() == "SI")
                                bloc = true;
                        }
                        cmd.Parameters.Add(z.CreaSqlParameter("Bloccato", DbType.Boolean, bloc));
                        try
                        {
                            ConnSDB.Open();
                            newid = (int)cmd.ExecuteScalar();
                            ConnSDB.Close();
                            // aggiungi sede legale
                            AggiungePlantSede(newid, ragsoc, naz);
                            msg = "OK";
                        }
                        catch (Exception ex)
                        {
                            string errore = ex.Message;
                            ConnSDB.Close();
                            msg = ex.Message;
                        }
                    }
                    else
                    {
                        msg = "Customer administratively blocked!";
                        newid = -1;
                    }
                }
                else
                {
                    msg = "Customer already exist in SDB!";
                    newid = 0;
                }
            }
            else
            {
                msg = @"Customer don\'t exist in SIMEC ERP!";
                newid = -2;
            }
            return newid;
        }

        public void AggiungePlantSede(int idcli, string cli, string naz)
        {
            try
            {
                string sql = "SELECT id from OFF_DestinazioniClienti WHERE Sede=1 AND idCliente=" + idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    sql = "INSERT INTO OFF_DestinazioniClienti (IdCliente,Sede,RagSoc,Nazione,cdn_sede) VALUES(@IdCliente,1,@RagSoc,@Nazione,0)";
                    cmd = new SqlCommand(sql, ConnSDB);
                    Generic z = new Generic();
                    cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                    cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, cli));
                    cmd.Parameters.Add(z.CreaSqlParameter("Nazione", DbType.String, naz));
                    try
                    {
                        ConnSDB.Open();
                        cmd.ExecuteNonQuery();
                        ConnSDB.Close();
                    }
                    catch (Exception ex)
                    {
                        string errore = ex.Message;
                        ConnSDB.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        public string ImportaSedi(string cod, Int32 idcli, bool NoAgg = false)
        {
            string msg = "";
            try
            {
                Generic z = new Generic();
                string sql = "SELECT * FROM vw_ClientiSedi WHERE CodCliente='" + cod + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    Int16 CodiceSede = Convert.ToInt16(dt.Rows[i]["CodSede"]);
                    sql = "SELECT * FROM OFF_DestinazioniClienti WHERE IdCliente=" + idcli + " And cdn_sede = " + CodiceSede;
                    cmd = new SqlCommand(sql, ConnSDB);
                    da = new SqlDataAdapter(cmd);
                    DataTable dtv = new DataTable();
                    da.Fill(dtv);
                    if (dtv.Rows.Count == 0)
                    {
                        sql = "INSERT INTO OFF_DestinazioniClienti (IdCliente,RagSoc,Sede,Indirizzo,Localita,Cap,Provincia,Nazione,Tel,Tipo,Predefinita,";
                        sql = sql + "DataCrea,UtCrea,DataMod,UtMod,obsoleta,cdn_sede,EsisteERP)";
                        sql = sql + " VALUES(@IdCliente,@RagSoc,0,@Indirizzo,@Localita,@Cap,@Provincia,@Nazione,@Tel,@Tipo,@Predefinita,";
                        sql = sql + " GetDate(),@UtCrea,GetDate(),@UtMod,0,@cdn_sede,1)";
                    }
                    else if (NoAgg == false)
                    {
                        sql = "UPDATE OFF_DestinazioniClienti SET RagSoc=@RagSoc,Sede=@Sede,Indirizzo=@Indirizzo,Localita=@Localita,Cap=@Cap,Provincia=@Provincia,Nazione=@Nazione,";
                        sql = sql + "Tel=@Tel,Tipo=@Tipo,Predefinita=@Predefinita,GetDate(),UtMod,0,EsisteERP WHERE CodCliente='" + cod + "' AND cdn_sede=" + CodiceSede;
                    }
                    else
                        sql = "";
                    cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                    string rag = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["DescSede"]))
                        rag = (string)dt.Rows[i]["DescSede"];
                    cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, rag));
                    string indir = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Indirizzo"]))
                        indir = (string)dt.Rows[i]["Indirizzo"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Indirizzo", DbType.String, indir));
                    string loca = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Localita"]))
                        loca = (string)dt.Rows[i]["Localita"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Localita", DbType.String, loca));
                    string cap = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Cap"]))
                        cap = (string)dt.Rows[i]["Cap"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Cap", DbType.String, cap));
                    string Prov = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Prov"]))
                        Prov = (string)dt.Rows[i]["Prov"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Provincia", DbType.String, Prov));
                    string Naz = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["cod_naz"]))
                        Naz = (string)dt.Rows[i]["cod_naz"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Nazione", DbType.String, Naz));
                    string Tel = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["sig_tel"]))
                        Tel = (string)dt.Rows[i]["sig_tel"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Tel", DbType.String, Tel, 25));
                    cmd.Parameters.Add(z.CreaSqlParameter("Tipo", DbType.String, "", 50));
                    bool pred = false;
                    if (!Convert.IsDBNull(dt.Rows[i]["cod_dest_pred"]))
                    {
                        if (cod == (string)dt.Rows[i]["cod_dest_pred"])
                            pred = true;
                    }
                    cmd.Parameters.Add(z.CreaSqlParameter("Predefinita", DbType.Boolean, pred));
                    cmd.Parameters.Add(z.CreaSqlParameter("UtCrea", DbType.String, HttpContext.Current.User.Identity.Name.ToString()));
                    cmd.Parameters.Add(z.CreaSqlParameter("UtMod", DbType.String, HttpContext.Current.User.Identity.Name.ToString()));
                    cmd.Parameters.Add(z.CreaSqlParameter("cdn_sede", DbType.Int32, CodiceSede));
                    try
                    {
                        ConnSDB.Open();
                        cmd.ExecuteNonQuery();
                        ConnSDB.Close();
                        msg = "ok";
                    }
                    catch (Exception ex)
                    {
                        string errSede = ex.Message;
                        ConnSDB.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                msg = ex.Message;
            }
            return msg;
        }

        protected int GetIdAgente(object cod)
        {
            int idag = 0;
            try
            {
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return idag;
        }

        public string ImportaTools(string cod, int idcli)
        {
            string msg = "";
            try
            {
                Generic z = new Generic();
                string sql = "SELECT * FROM vw_CLIENTITools WHERE CodCliente='" + cod + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    sql = "INSERT INTO OFF_MacchineClienti (IdCliente,IdSede,Costruttore,Diametro,Tavola,Totale,DiametroInterno,Disegno,Commerciale,Obsoleta,Qta)";
                    sql = sql + " VALUES(@IdCliente,@IdSede,@Costruttore,@Diametro,@Tavola,@Totale,@DiametroInterno,@Disegno,0,0,1)";
                    cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                    cmd.Parameters.Add(z.CreaSqlParameter("IdSede", DbType.Int32, GetIdSede(idcli, (int)dt.Rows[i]["Cod_Dest"])));
                    string costr = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Costruttore"]))
                        costr = (string)dt.Rows[i]["Costruttore"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Costruttore", DbType.String, costr));
                    string dia = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["DIAMETRO"]))
                        dia = (string)dt.Rows[i]["DIAMETRO"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Diametro", DbType.String, dia));
                    string Tav = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["TAVOLA"]))
                        Tav = (string)dt.Rows[i]["TAVOLA"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Tavola", DbType.String, Tav));
                    string tot = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["lunghezza"]))
                        tot = (string)dt.Rows[i]["lunghezza"];
                    cmd.Parameters.Add(z.CreaSqlParameter("Totale", DbType.String, tot));
                    string diaint = "";
                    if (!Convert.IsDBNull(dt.Rows[i]["Diametro_interno"]))
                        diaint = (string)dt.Rows[i]["Diametro_interno"];
                    cmd.Parameters.Add(z.CreaSqlParameter("DiametroInterno", DbType.String, diaint));

                    cmd.Parameters.Add(z.CreaSqlParameter("Disegno", DbType.String, dt.Rows[i]["Disegno"]));

                    ConnSDB.Open();
                    cmd.ExecuteNonQuery();
                    msg = "OK";
                    ConnSDB.Close();
                    // inserisce anche in tool usage

                    InsertToolUsage(idcli, (string)dt.Rows[i]["Disegno"], 1);
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                ConnSDB.Close();
            }
            return msg;
        }
            public Int32 GetIdSede(Int32 idcli, int cdnsede)
            {
                Int32 id = 0;
                try
                {
                    string sql = "SELECT Id FROM OFF_DestinazioniClienti WHERE IdCliente=" + idcli + " AND cdn_sede=" + cdnsede;
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                        id = (int)dt.Rows[0]["Id"];
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                }

                return id;
            }
            public void InsertToolUsage(Int32 idcli, string dis, int qta)
            {
            }
        }

    }