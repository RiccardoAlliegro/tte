﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Microsoft.VisualBasic;
using System.Web.UI;

namespace SDB_2021.CRM
{
    public partial class CercaDisegni : System.Web.UI.Page
    {
        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                TabName.Value = Request.Form[TabName.UniqueID];
            }
        }
        public void ApriDisegno(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;
            string x = link.Text;
            // Verifica esistenza disegno
            string percorso = Server.MapPath("~/Disegni");
            string nomeFile = x;

            if (System.IO.File.Exists(percorso + "/" + nomeFile) == true)
                Response.Redirect("~/Disegni/" + x);
            else
                ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('Disegno richiesto non trovato.');</script>");
        }
        public void ApriScheda(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;
            string x = link.Text;
            // Verifica esistenza scheda
            string percorso = Server.MapPath("~/SchedeCI");
            string nomeFile = x;

            if (System.IO.File.Exists(percorso + "/" + nomeFile) == true)
                Response.Redirect("~/SchedeCI/" + x);
            else
                ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('Scheda controllo in ingresso richiesta non trovato.');</script>");
        }

        protected void Cerca_Click(object sender, EventArgs e)
        {
            try
            {
                string subFam = "";
                string costr = "";
                string codCostr = "";
                double dia = 0;
                double tav = 0;
                double lungh = 0;
                int x = 0;
                string filtro = "";

                if (this.Disegnox.Text != "")
                    filtro = "Codice_Simec='" + this.Disegnox.Text + "'";
                else
                {
                    if (Information.IsNumeric(this.Diametrox.Text))
                    {
                        dia = System.Convert.ToDouble(this.Diametrox.Text);
                        filtro = "Diametro>=" + (Convert.ToDouble(dia) - 1) + " AND Diametro<=" + System.Convert.ToDouble(dia) + 1;
                        filtro = filtro.Replace(",", ".");
                        x = 1;
                    }
                    if (Information.IsNumeric(this.Tavolax.Text))
                    {
                        tav = System.Convert.ToDouble(this.Tavolax.Text);
                        if (x == 0)
                            filtro = "Tavola>=" + (Convert.ToDouble(tav) - 10) + " AND Tavola<=" + System.Convert.ToDouble(tav) + 10;
                        else
                            filtro = filtro + " AND Tavola>=" + (Convert.ToDouble(tav) - 10) + " AND Tavola<=" + System.Convert.ToDouble(tav) + 10;
                        x = 1;
                    }
                    costr = this.Costruttorex.SelectedValue;
                    if (costr != "")
                    {
                        if (x == 0)
                            filtro = "Costruttore='" + costr.Trim() + "'";
                        else
                            filtro = filtro + " AND Costruttore='" + costr.Trim() + "'";
                        x = 1;
                    }
                    if (dia == 0 | tav == 0 | costr == "")
                    {
                        ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('COMPULSORY FIELDS: (Diameter and Face Length and Manufacturer) OR (SIMEC Dwg Code)');</script>");
                        this.Gv_Disegni.Visible = false;
                        return;
                    }
                    codCostr = this.CodCostruttore.Text;

                    if (Information.IsNumeric(this.Lunghezzax.Text))
                    {
                        lungh = Convert.ToDouble(this.Lunghezzax.Text);
                        if (x == 0)
                            filtro = "Lunghezza=" + lungh;
                        else
                            filtro = filtro + " AND Lunghezza=" + lungh;
                        x = 1;
                    }
                    if (codCostr != "")
                    {
                        if (x == 0)
                            filtro = "Codice_Costruttore like '%" + codCostr.Trim() + "%'";
                        else
                            filtro = filtro + " AND Codice_Costruttore like '%" + codCostr.Trim() + "%'";
                        x = 1;
                    }
                    subFam = this.Sottofamiglia.SelectedValue;
                    if (subFam != "")
                    {
                        if (x == 0)
                            filtro = "Sottofamiglia=" + subFam.Trim();
                        else
                            filtro = filtro + " AND Sottofamiglia='" + subFam.Trim() + "'";
                        x = 1;
                    }
                }

                string sql = "SELECT * FROM vw_ArchivioRulli WHERE " + filtro;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                this.Gv_Disegni.DataSource = ds;
                this.Gv_Disegni.DataBind();

                this.Gv_Disegni.Visible = true;
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void Famiglia_DataBound(object sender, System.EventArgs e)
        {
            RadComboBoxItem vuoto = new RadComboBoxItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Famiglia.Items.Insert(0, vuoto);
        }
        protected void Sottofamiglia_DataBound(object sender, System.EventArgs e)
        {
            RadComboBoxItem vuoto = new RadComboBoxItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Sottofamiglia.Items.Insert(0, vuoto);
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
            this.Famiglia.SelectedValue = "";
            this.Sottofamiglia.SelectedValue = "";
            this.Costruttorex.SelectedValue = "";
            this.CodCostruttore.Text = "";
            this.Diametro.Text = "";
            this.Tavola.Text = "";
            this.Lunghezzax.Text = "";
            this.Disegnox.Text = "";
            this.Gv_Disegni.Visible = false;
            this.Gv_maga.Visible = false;
        }
        protected void Gv_Disegni_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            GetDataTable();
        }

        protected void Gv_Disegni_ItemCommand(object sender, GridCommandEventArgs e)
        {
            if (e.CommandName == "Filter")
                GetDataTable();
        }

        protected void GetDataTable()
        {
            string filtro = "";
            try
            {
                string subFam = "";
                //string costr = "";
                double dia = 0;
                double tav = 0;
                double lungh = 0;
                int x = 0;

                if (Information.IsNumeric(this.Diametro.Text))
                {
                    dia = System.Convert.ToDouble(this.Diametro.Text);
                    filtro = "Diametro>=" + (Convert.ToDouble(dia) - 1) + " AND Diametro<=" + Convert.ToDouble(dia) + 1;
                    x = 1;
                }
                else if (Information.IsNumeric(this.Gv_Disegni.MasterTableView.Columns[6].CurrentFilterValue))
                {
                    dia = Convert.ToDouble(this.Gv_Disegni.MasterTableView.Columns[6].CurrentFilterValue);
                    filtro = "Diametro=" + dia;
                }
                if (Information.IsNumeric(this.Tavola.Text))
                {
                    tav = System.Convert.ToDouble(this.Tavola.Text);
                    if (x == 0)
                        filtro = "Tavola>=" + (Convert.ToDouble(tav) - 10) + " AND Tavola<=" + Convert.ToDouble(tav) + 10;
                    else
                        filtro = filtro + " AND Tavola>=" + (Convert.ToDouble(tav) - 10) + " AND Tavola<=" + Convert.ToDouble(tav) + 10;
                    x = 1;
                }
                else if (Information.IsNumeric(this.Gv_Disegni.MasterTableView.Columns[8].CurrentFilterValue))
                {
                    tav = Convert.ToDouble(this.Gv_Disegni.MasterTableView.Columns[8].CurrentFilterValue);
                    if (x == 0)
                        filtro = "Tavola=" + tav;
                    else
                        filtro = filtro + "AND Tavola=" + tav;
                    x = 1;
                }
                if (Information.IsNumeric(this.Lunghezzax.Text))
                {
                    lungh = Convert.ToDouble(this.Lunghezzax.Text);
                    if (x == 0)
                        filtro = "Lunghezza=" + lungh;
                    else
                        filtro = filtro + " AND Lunghezza=" + lungh;
                    x = 1;
                }
                else if (Information.IsNumeric(this.Gv_Disegni.MasterTableView.Columns[9].CurrentFilterValue))
                {
                    lungh = Convert.ToDouble(this.Gv_Disegni.MasterTableView.Columns[9].CurrentFilterValue);
                    if (x == 0)
                        filtro = "Lunghezza=" + lungh;
                    else
                        filtro = filtro + "AND Lunghezza=" + lungh;
                    x = 1;
                }
                subFam = this.Sottofamiglia.SelectedValue;
                if (subFam != "")
                {
                    if (x == 0)
                        filtro = "Sottofamiglia=" + Strings.Trim(subFam);
                    else
                        filtro = filtro + " AND Sottofamiglia='" + Strings.Trim(subFam) + "'";
                    x = 1;
                }
                else if (Information.IsNumeric(this.Gv_Disegni.MasterTableView.Columns[5].CurrentFilterValue))
                {
                    subFam = this.Gv_Disegni.MasterTableView.Columns[5].CurrentFilterValue;
                    if (x == 0)
                        filtro = "Sottofamiglia=" + subFam;
                    else
                        filtro = filtro + "AND Sottofamiglia=" + subFam;
                    x = 1;
                }
                if (dia == 0 & tav == 0)
                {
                    ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('Specificare Diametro e/o Tavola o Codice Disegno per eseguire la ricerca.');</script>");
                    this.Gv_Disegni.Visible = false;
                    return;
                }
                string sql = "SELECT * FROM Archivio_Rulli WHERE " + filtro;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                this.Gv_Disegni.DataSource = ds;
                this.Gv_Disegni.DataBind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void TipoApplicazione_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetModuloIncisioni(7);
            string sottofam = this.TipoApplicazione.SelectedValue;
            if (sottofam != "")
            {
                filtraCostruttori(sottofam);
                filtraModelli(sottofam);

                filtraInchiostri(sottofam);
                filtraCosa(sottofam);
                filtraSupporti(sottofam);
            }
            if (sottofam == "SL")
            {
                this.SupportoStampa.Visible = true;
                lblSupportoStampa.Visible = true;
            }
            else
            {
                this.SupportoStampa.Visible = false;
                lblSupportoStampa.Visible = false;
            }
        }

        public void filtraInchiostri(string sottofam)
        {
            // filtra i costruttori in base al tipo applicazione selezionata
            try
            {
                string sql = "SELECT Inchiostro,Inchiostro_EN FROM expo_Inchiostri where sottofamiglia=@subfam";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = sottofam;
                cmd.Parameters.Add(par);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Inchiostro.DataSource = ds;
                    this.Inchiostro.DataTextField = "Inchiostro_EN";
                    this.Inchiostro.DataValueField = "Inchiostro";
                    this.Inchiostro.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        public void filtraModelli(string sottofam)
        {
            // filtra i costruttori in base al tipo applicazione selezionata
            try
            {
                string sql = "SELECT DISTINCT Modello FROM expo_Modelli where sottofamiglia=@subfam AND Costruttore=@costr";
                if (this.Costruttore.SelectedValue == "")
                    sql = "SELECT DISTINCT Modello FROM expo_Modelli where sottofamiglia=@subfam";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = sottofam;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@costr";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Modello.DataSource = ds;
                    this.Modello.DataTextField = "Modello";
                    this.Modello.DataValueField = "Modello";
                    this.Modello.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        public void filtraCostruttori(string sottofam)
        {
            // filtra i costruttori in base al tipo applicazione selezionata
            try
            {
                string sql = "SELECT Costruttore FROM expo_Costruttori where sottofamiglia=@subfam";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = sottofam;
                cmd.Parameters.Add(par);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Costruttore.DataSource = ds;
                    this.Costruttore.DataTextField = "Costruttore";
                    this.Costruttore.DataValueField = "Costruttore";
                    this.Costruttore.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }


        protected void Modello_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            if (Modello.Items.Count > 0)
            {
                if (Modello.Items[0].Value != "")
                    this.Modello.Items.Insert(0, vuoto);
            }
        }
        protected void Inchiostro_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Inchiostro.Items.Insert(0, vuoto);
        }
        protected void Costruttore_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Costruttore.Items.Insert(0, vuoto);
        }
        protected void Diametro_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Diametro.Items.Insert(0, vuoto);
        }
        protected void Tavola_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Tavola.Items.Insert(0, vuoto);
        }

        protected void Costruttore_SelectedIndexChanged(object sender, EventArgs e)
        {
            // filtraDiametri(Me.TipoApplicazione.SelectedValue, Me.Costruttore.SelectedValue, Me.Modello.SelectedValue)

            ResetModuloIncisioni(5);
            try
            {
                // filtra i modelli in base al costruttore
                string sql = "SELECT Modello FROM expo_Modelli where sottofamiglia=@subfam AND COstruttore=@Costruttore";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                if (this.TipoApplicazione.SelectedValue == "SL")
                    par.Value = this.SupportoStampa.SelectedValue;
                else
                    par.Value = this.TipoApplicazione.SelectedValue;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Costruttore";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Modello.DataSource = ds;
                    this.Modello.DataTextField = "Modello";
                    this.Modello.DataValueField = "Modello";
                    this.Modello.DataBind();
                }
                else
                {
                    // se non ci sono modelli filtra la velocità in base al costruttore
                    sql = "SELECT DISTINCT Velocita FROM expo_SuggerimentiStampa WHERE sottofamiglia=@subfam AND COstruttore=@Costruttore";
                    cmd = new SqlCommand(sql, ConnSDB);
                    par = new SqlParameter();
                    par.ParameterName = "@subfam";
                    par.DbType = DbType.String;
                    if (this.TipoApplicazione.SelectedValue == "SL")
                        par.Value = this.SupportoStampa.SelectedValue;
                    else
                        par.Value = this.TipoApplicazione.SelectedValue;
                    cmd.Parameters.Add(par);
                    par1 = new SqlParameter();
                    par1.ParameterName = "@Costruttore";
                    par1.DbType = DbType.String;
                    par1.Value = this.Costruttore.SelectedValue;
                    cmd.Parameters.Add(par1);

                    da = new SqlDataAdapter(cmd);
                    ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        this.Velocit.DataSource = ds;
                        this.Velocit.DataTextField = "Velocita";
                        this.Velocit.DataValueField = "Velocita";
                        this.Velocit.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void Modello_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ResetModuloIncisioni(4);

                // filtraDiametri(Me.TipoApplicazione.SelectedValue, Me.Costruttore.SelectedValue, Me.Modello.SelectedValue)
                // filtra veocita
                // se non ci sono modelli filtra la velocità in base al costruttore
                string sql = "SELECT DISTINCT Velocita FROM expo_SuggerimentiStampa WHERE sottofamiglia=@subfam AND COstruttore=@Costruttore AND Modello=@Modello";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                if (this.TipoApplicazione.SelectedValue == "SL")
                    par.Value = this.SupportoStampa.SelectedValue;
                else
                    par.Value = this.TipoApplicazione.SelectedValue;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Costruttore";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlParameter par2 = new SqlParameter();
                par2.ParameterName = "@modello";
                par2.DbType = DbType.String;
                par2.Value = this.Modello.SelectedValue;
                cmd.Parameters.Add(par2);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Velocit.DataSource = ds;
                    this.Velocit.DataTextField = "Velocita";
                    this.Velocit.DataValueField = "Velocita";
                    this.Velocit.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void filtraDiametri(string sottofam, string Costr, string modell)
        {
            // filtra il diametro in base al tipo applicazione selezionata, al costruttore o al modello
            try
            {
                string sql = "SELECT DISTINCT Diametro FROM expo_SuggerimentiStampa where sottofamiglia=@subfam";
                int x = 0;
                if (this.Costruttore.SelectedValue != "")
                {
                    sql = sql + " AND (Costruttore=@Costruttore)";
                    x = 1;
                }
                if (this.Modello.SelectedValue != "")
                {
                    sql = sql + " AND (Modello=@Modello)";
                    x = 1;
                }
                if (x == 0)
                    return;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                if (this.SupportoStampa.Visible == true)
                    sottofam = this.SupportoStampa.SelectedValue;
                par.Value = sottofam;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Costruttore";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlParameter par2 = new SqlParameter();
                par2.ParameterName = "@Modello";
                par2.DbType = DbType.String;
                par2.Value = this.Modello.SelectedValue;
                cmd.Parameters.Add(par2);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Diametro.DataSource = ds;
                    this.Diametro.DataTextField = "Diametro";
                    this.Diametro.DataValueField = "Diametro";
                    this.Diametro.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void Diametro_SelectedIndexChanged(object sender, EventArgs e)
        {
            // filtra il diametro in base al tipo applicazione selezionata, al costruttore o al modello
            try
            {
                string sql = "SELECT DISTINCT Tavola FROM expo_SuggerimentiStampa where sottofamiglia=@subfam";
                if (Information.IsNumeric(this.Diametro.SelectedValue))
                    sql = "SELECT DISTINCT Tavola FROM expo_SuggerimentiStampa where sottofamiglia=@subfam";

                int x = 0;
                if (this.Costruttore.SelectedValue != "")
                {
                    sql = sql + " AND (Costruttore=@Costruttore)";
                    x = 1;
                }
                if (this.Modello.SelectedValue != "")
                {
                    sql = sql + " AND (Modello=@Modello)";
                    x = 1;
                }
                if (x == 0)
                    return;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = this.TipoApplicazione.SelectedValue;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Costruttore";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlParameter par2 = new SqlParameter();
                par2.ParameterName = "@Modello";
                par2.DbType = DbType.String;
                par2.Value = this.Modello.SelectedValue;
                cmd.Parameters.Add(par2);
                SqlParameter par3 = new SqlParameter();
                par3.ParameterName = "@diam";
                if (Information.IsNumeric(this.Diametro.SelectedValue))
                    par3.Value = System.Convert.ToDouble(this.Diametro.SelectedValue);
                else
                    par3.Value = this.Diametro.SelectedValue;
                cmd.Parameters.Add(par3);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Tavola.DataSource = ds;
                    this.Tavola.DataTextField = "Tavola";
                    this.Tavola.DataValueField = "Tavola";
                    this.Tavola.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void filtraVelocita(string sottofam, string Costr, string modell, string diam)
        {
            // filtra il diametro in base al tipo applicazione selezionata, al costruttore o al modello
            try
            {
                string sql = "SELECT DISTINCT Velocita FROM expo_SuggerimentiStampa where sottofamiglia=@subfam";
                int x = 0;
                if (this.Costruttore.SelectedValue != "")
                {
                    sql = sql + " AND (Costruttore=@Costruttore)";
                    x = 1;
                }
                if (this.Modello.SelectedValue != "")
                {
                    sql = sql + " AND (Modello=@Modello)";
                    x = 1;
                }
                if (x == 0)
                    return;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = sottofam;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Costruttore";
                par1.DbType = DbType.String;
                par1.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlParameter par2 = new SqlParameter();
                par2.ParameterName = "@Modello";
                par2.DbType = DbType.String;
                par2.Value = this.Modello.SelectedValue;
                cmd.Parameters.Add(par2);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Diametro.DataSource = ds;
                    this.Diametro.DataTextField = "Diametro";
                    this.Diametro.DataValueField = "Diametro";
                    this.Diametro.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void filtraSupporti(string sottofam)
        {
            // filtra il diametro in base al tipo applicazione selezionata, al costruttore o al modello
            try
            {
                string sql = "SELECT * FROM expo_Supporti where sottofamiglia=@subfam";
                //int x = 0;

                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;

                par.Value = sottofam;
                cmd.Parameters.Add(par);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Supporto.DataSource = ds;
                    this.Supporto.DataTextField = "Supporto_EN";
                    this.Supporto.DataValueField = "Supporto";
                    this.Supporto.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void filtraCosa(string sottofam)
        {
            // filtra il diametro in base al tipo applicazione selezionata, al costruttore o al modello
            try
            {
                string sql = "SELECT * FROM expo_CosaStampare where sottofamiglia=@subfam AND Supporto=@Supporto";

                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                par.Value = sottofam;
                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@Supporto";
                par1.DbType = DbType.String;
                par1.Value = this.Supporto.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.Cosa.DataSource = ds;
                    this.Cosa.DataTextField = "Cosa_EN";
                    this.Cosa.DataValueField = "Cosa";
                    this.Cosa.DataBind();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void SuggerisciIncisione_Click(object sender, EventArgs e)
        {
            try
            {
                string valido = validaForm();
                if (valido == "")
                {
                    GetdataSource();
                    this.gv_Incisioni.DataBind();
                }
                else
                    // parametri insufficienti
                    this.gv_Incisioni.Visible = false;
            }
            catch (Exception ex)
            {
                string errore1 = ex.Message;
            }
        }
        public string validaForm()
        {
            string errore = "";

            return errore;
        }

        protected void Cosa_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Cosa.Items.Insert(0, vuoto);
        }

        protected void Supporto_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            if (Supporto.Items.Count > 0)
            {
                if (Supporto.Items[0].Value != "")
                    this.Supporto.Items.Insert(0, vuoto);
            }
        }

        protected void Velocit_DataBound(object sender, EventArgs e)
        {
            ListItem vuoto = new ListItem();
            vuoto.Value = "";
            vuoto.Text = "----";
            this.Velocit.Items.Insert(0, vuoto);
        }

        protected void Supporto_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetModuloIncisioni(3);
            string sottofam = this.TipoApplicazione.SelectedValue;
            if (sottofam == "SL")
                sottofam = this.SupportoStampa.SelectedValue;
            filtraCosa(sottofam);
        }
        protected void Gv_Incisioni_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            GetdataSource();
        }

        protected void GetdataSource()
        {
            try
            {
                string sql = "SELECT DISTINCT Incisione,Linee,Volume,Volume_Min,Volume_Max FROM expo_SuggerimentiStampa WHERE Sottofamiglia=@subfam AND CosaStampare=@CosaStampare AND Supporto=@Supporto";

                // filtro sul costruttore
                if (this.Costruttore.SelectedValue != "")
                    sql = sql + " AND Costruttore=@costr";
                // filtro sul modello
                if (this.Modello.SelectedValue != "")
                    sql = sql + " AND Modello=@Modello";

                // filtro su RaclaGommato
                if (this.RaclaGommato.SelectedValue != "")
                    sql = sql + " AND RaclaGommato=@RaclaGommato";

                // filtro su RaclaGommato
                if (this.Inchiostro.SelectedValue != "")
                    sql = sql + " AND Inchiostro=@Inchiostro";

                // filtro su velocita
                if (this.Velocit.SelectedValue != "")
                    sql = sql + " AND Velocita=@Velocita";

                sql = sql + " ORDER BY Incisione DESC, Linee, Volume";

                SqlCommand cmd = new SqlCommand(sql, ConnSDB);

                SqlParameter par = new SqlParameter();
                par.ParameterName = "@subfam";
                par.DbType = DbType.String;
                if (this.TipoApplicazione.SelectedValue == "SL")
                    par.Value = this.SupportoStampa.SelectedValue;
                else
                    par.Value = this.TipoApplicazione.SelectedValue;

                cmd.Parameters.Add(par);
                SqlParameter par1 = new SqlParameter();
                par1.ParameterName = "@CosaStampare";
                par1.DbType = DbType.String;
                par1.Value = this.Cosa.SelectedValue;
                cmd.Parameters.Add(par1);
                SqlParameter par2 = new SqlParameter();
                par2.ParameterName = "@Supporto";
                par2.DbType = DbType.String;
                par2.Value = this.Supporto.SelectedValue;
                cmd.Parameters.Add(par2);

                SqlParameter par4 = new SqlParameter();
                par4.ParameterName = "@costr";
                par4.DbType = DbType.String;
                par4.Value = this.Costruttore.SelectedValue;
                cmd.Parameters.Add(par4);
                SqlParameter par5 = new SqlParameter();
                par5.ParameterName = "@Modello";
                par5.DbType = DbType.String;
                par5.Value = this.Modello.SelectedValue;
                cmd.Parameters.Add(par5);
                SqlParameter par7 = new SqlParameter();
                par7.ParameterName = "@RaclaGommato";
                par7.DbType = DbType.String;
                par7.Value = this.RaclaGommato.SelectedValue;
                cmd.Parameters.Add(par7);
                SqlParameter par8 = new SqlParameter();
                par8.ParameterName = "@Inchiostro";
                par8.DbType = DbType.String;
                par8.Value = this.Inchiostro.SelectedValue;
                cmd.Parameters.Add(par8);
                SqlParameter par6 = new SqlParameter();
                par6.ParameterName = "@Velocita";
                if (Information.IsNumeric(this.Velocit.SelectedValue))
                    par6.Value = System.Convert.ToInt32(this.Velocit.SelectedValue);
                else
                    par6.Value = DBNull.Value;
                cmd.Parameters.Add(par6);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    this.gv_Incisioni.DataSourceID = null;
                    this.gv_Incisioni.DataSource = ds;
                    this.gv_Incisioni.Visible = true;
                }
                else
                    this.gv_Incisioni.Visible = false;
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void SupportoStampa_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sottofam = this.SupportoStampa.SelectedValue;
            ResetModuloIncisioni(6);
            filtraModelli(sottofam);
            filtraCosa(sottofam);
            filtraSupporti(sottofam);
        }

        protected void ResetModuloIncisioni(int livello)
        {
            // reimposta i campi elenco del modulo a partire dal livello specificato
            try
            {
                // Livello 7: TIPO APPLICAZIONE
                if (livello > 0)
                {
                    this.TipoApplicazione.DataSource = null;
                    if (livello > 1)
                    {
                        // Livello 6: SUPPORTO
                        this.SupportoStampa.DataSource = null;
                        this.SupportoStampa.DataBind();
                        this.RaclaGommato.SelectedValue = "";
                        if (livello > 2)
                        {
                            // Livello 5: Costruttore
                            this.Costruttore.DataSource = null;
                            this.Costruttore.DataBind();
                            if (livello > 3)
                            {
                                // Livello 4: Modello
                                this.Modello.DataSource = null;
                                this.Modello.DataBind();
                                if (livello > 4)
                                {
                                    // Livello 3: Velocita
                                    this.Velocit.DataSource = null;
                                    this.Velocit.DataBind();
                                    if (livello > 5)
                                    {
                                        // Livello 2: Tipo Supporto
                                        this.Supporto.DataSource = null;
                                        this.Supporto.DataBind();
                                        // Livello 2: Inchiostro
                                        this.Inchiostro.DataSource = null;
                                        this.Inchiostro.DataBind();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
    }
}