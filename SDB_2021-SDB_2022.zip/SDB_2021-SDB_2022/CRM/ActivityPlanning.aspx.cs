﻿using SDB_2021.Code;
using Microsoft.VisualBasic;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI;
using Telerik.Web.UI;

namespace SDB_2021.CRM
{
    public partial class ActivityPlanning : System.Web.UI.Page
    {

        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

            FunzioniCRM z = new FunzioniCRM();
            if (!IsPostBack)
            {
                string nome = User.Identity.Name;
                Gv_Chiamate.DataBind();
                VisitsCalendar.DataBind();
                CallsCalendar.DataBind();
                // filtra elenco in base al magager
                Cliente.Text = "";

                string c = "";
                if (!Information.IsNothing(Request.QueryString["u"]))
                    c = Request.QueryString["u"];
                bool contr = z.VerificaController(User.Identity.Name.ToUpper(), c);
                if (contr == true)
                {
                    FiltraVisite(c);
                    this.Controllato.Text = c;
                    //this.New_Report.Disabled = true;
                }
                else
                {
                    FiltraVisite(User.Identity.Name);
                    this.Controllato.Text = "";
                    //this.New_Report.Disabled = false;
                }
            }

            FiltraVisite(User.Identity.Name);
            FiltraChiamate(User.Identity.Name);
            LimitaClienti(User.Identity.Name);
            if (!User.IsInRole("Amministratore"))
            {
                this.Gv_Chiamate.MasterTableView.CommandItemSettings.ShowExportToExcelButton = false;
                this.Gv_Visite.MasterTableView.CommandItemSettings.ShowExportToExcelButton = false;
            }
            this.SqlPlant.SelectCommand = "SELECT DISTINCT [RagSoc], [Indirizzo], [IdCliente] FROM [OFF_DestinazioniClienti] WHERE IdCliente = '" + ClienteIDPC.Text + "'";
        }

        //VISIT SCHEDULE
        protected void FiltraVisite(string ute)
        {
            FunzioniCRM p = new FunzioniCRM();
            string nome = p.GetNomeCompleto(ute);
            string sql = "Select * FROM [vw_VisiteCliente]  ORDER BY [Data_Visita] DESC";
            // If User.IsInRole("Agenti") Or User.IsInRole("Commerciale") Then
            // sql = "Select * FROM [vw_VisiteCliente]  WHERE Manager='" & nome & "' OR ProductManager='" & nome & "' ORDER BY [Data_Visita] DESC"

            // End If
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
                sql = @"SELECT DISTINCT 
                        dbo.VisiteCliente.Id, dbo.VisiteCliente.Data_Visita, dbo.VisiteCliente.IdClient, dbo.VisiteCliente.Cliente, dbo.VisiteCliente.TipoCliente, dbo.VisiteCliente.ResponsabileCliente, dbo.VisiteCliente.ParlatoCon, 
                        dbo.VisiteCliente.OraInizio, dbo.VisiteCliente.OraFine, dbo.VisiteCliente.Data_Inizio, dbo.VisiteCliente.Data_Fine, dbo.VisiteCliente.MotivoVisita, dbo.VisiteCliente.Intro, dbo.VisiteCliente.ChiusuraOrdine, 
                        dbo.VisiteCliente.VisitaGiro, dbo.VisiteCliente.RaccoltaDatiCampioni, dbo.VisiteCliente.Altro, dbo.VisiteCliente.dataMod, dbo.VisiteCliente.utMod, dbo.VisiteCliente.Manager, dbo.OFF_SettoriClienti.ProductManager, 
                        dbo.VisiteCliente.PartecipantiInterni, dbo.VisiteClienteAllegati.Allegato
                        FROM           
                        dbo.VisiteCliente INNER JOIN
                        dbo.OFF_ClientiSDB ON dbo.VisiteCliente.Manager = dbo.OFF_ClientiSDB.Manager AND dbo.VisiteCliente.IdClient = dbo.OFF_ClientiSDB.Id INNER JOIN
                        dbo.OFF_SettoriClienti ON dbo.VisiteCliente.IdClient = dbo.OFF_SettoriClienti.IdClient LEFT OUTER JOIN
                        dbo.VisiteClienteAllegati ON dbo.VisiteCliente.Id = dbo.VisiteClienteAllegati.IdVisita where dbo.OFF_SettoriClienti.ProductManager = '" + nome + "' or dbo.VisiteCliente.Manager='" + nome + "' order by [Data_VIsita] desc";
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            this.Gv_Visite.DataSourceID = null;
            this.Gv_Visite.DataSource = dt;
            dt.Columns.Add("PresenzaAllegati", System.Type.GetType("System.Boolean"));
            for (var i = 0; i <= dt.Rows.Count - 1; i++)
            {
                string id = (string)dt.Rows[i]["ID"].ToString();
                sql = "SELECT IdVisita FROM VisiteClienteAllegati WHERE IdVisita=" + id;
                cmd = new SqlCommand(sql, ConnSDB);
                da = new SqlDataAdapter(cmd);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                if (dt1.Rows.Count > 0)
                    dt.Rows[i]["PresenzaAllegati"] = true;
                else
                    dt.Rows[i]["PresenzaAllegati"] = false;
            }
        }
        protected void NewReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("VisitReport.aspx");
        }
        protected void EditReport_Click(object sender, EventArgs e)
        {
            if (Information.IsNumeric(this.Gv_Visite.SelectedValue))
                Response.Redirect("VisitReport.aspx?Id=" + this.Gv_Visite.SelectedValue);
            else
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('Select line to be edited!');</script>"));
        }
        private void Gv_Visite_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            if (this.Controllato.Text == "")
                FiltraVisite(User.Identity.Name);
            else
                FiltraVisite(this.Controllato.Text);
        }
        protected void Doc_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string pagina = Request.Url.AbsoluteUri;
                pagina = Code.Total.Right(pagina, pagina.Length - pagina.LastIndexOf("/") - 1);
                pagina = Code.Total.Left(pagina, pagina.Length - 5);
                string sql = "SELECT * FROM Documentazione WHERE Pagina='" + pagina + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(dt.Rows[0]["File_Istruzioni"]))
                    {
                        pagina = (string)dt.Rows[0]["File_Istruzioni"];
                        string nomeFile = Server.MapPath("~/Documentazione") + "/" + pagina + ".pdf";
                        if (System.IO.File.Exists(nomeFile) == true)
                            Response.Redirect("~/Documentazione" + "/" + pagina + ".pdf");
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                this.Doc.Visible = false;
            }
            string url = "https://www.google.it/maps";
            Response.Write("<script> window.open(" + url + ")','_blank'); </script>");
        }

        //new visit
        protected void LimitaClienti(string ute)
        {
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
            {
                FunzioniCRM p = new FunzioniCRM();
                string nome = p.GetNomeCompleto(ute);
                this.SqlClienti.SelectCommand = "Select Id, RagSoc FROM vw_OFF_ClientiSDB WHERE (Manager='" + nome + "' OR ProductManager='" + nome + "') and Bloccato=0";
            }
        }
        protected void CmSalva_Click(object sender, EventArgs e)
        {
            try
            {
                string x = ValidaScheda();
                Generic z = new Generic();
                FunzioniCRM cr = new FunzioniCRM();
                if (x == "")
                {
                    string modo = "New";
                    if (Information.IsNumeric(this.IdVisita.Text))
                    {
                        string sql = "SELECT * FROM VisiteCliente WHERE Id=" + System.Convert.ToString(this.IdVisita.Text);

                        SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                            modo = "Edit";
                    }

                    string sql1 = "";
                    if (modo == "Edit")
                    {
                        sql1 = "UPDATE VisiteCliente SET TipoCliente=@TipoCliente,ParlatoCon=@ParlatoCon,OraInizio=@OraInizio,OraFine=@OraFine,PartecipantiInterni=@PartecipantiInterni,";
                        sql1 = sql1 + "MotivoVisita=@MotivoVisita,Altro=@Altro,dataMod=GetDate(),utMod=@utMod WHERE Id=" + System.Convert.ToString(this.IdVisita.Text);
                    }
                    else
                    {
                        sql1 = "INSERT INTO VisiteCliente (Data_Visita,IdClient,Cliente,TipoCliente,ParlatoCon,OraInizio,OraFine,PartecipantiInterni,MotivoVisita,Altro,dataMod,utMod,Manager)";
                        sql1 = sql1 + " VALUES(@Data_Visita,@IdClient,@Cliente,@TipoCliente,@ParlatoCon,@OraInizio,@OraFine,@PartecipantiInterni,@MotivoVisita,@Altro,GetDate(),@utMod,@Manager);";
                        sql1 = sql1 + "SELECT SCOPE_IDENTITY()";
                    }
                    SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                    cmd1.Parameters.Add(z.CreaSqlParameter("Data_Visita", DbType.DateTime, this.DataVisita.SelectedDate));
                    cmd1.Parameters.Add(z.CreaSqlParameter("IdClient", DbType.Int32, this.ClientID.Text));
                    cmd1.Parameters.Add(z.CreaSqlParameter("Cliente", DbType.String, this.Cliente.Text));
                    cmd1.Parameters.Add(z.CreaSqlParameter("TipoCliente", DbType.String, this.TipoCliente.SelectedValue));
                    cmd1.Parameters.Add(z.CreaSqlParameter("ParlatoCon", DbType.String, this.ParlatoCon.Text));
                    string oi = this.OraInizio.Text;
                    if (Strings.Len(oi) == 2)
                        oi = oi + ":00";
                    string ofi = this.OraFine.Text;
                    if (Strings.Len(ofi) == 2)
                        ofi = ofi + ":00";
                    cmd1.Parameters.Add(z.CreaSqlParameter("OraInizio", DbType.String, oi));
                    cmd1.Parameters.Add(z.CreaSqlParameter("OraFine", DbType.String, ofi));
                    cmd1.Parameters.Add(z.CreaSqlParameter("PartecipantiInterni", DbType.String, this.PartecipantiInterni.Text));
                    cmd1.Parameters.Add(z.CreaSqlParameter("MotivoVisita", DbType.String, this.MotivoVisita.SelectedValue));
                    cmd1.Parameters.Add(z.CreaSqlParameter("Altro", DbType.String, this.Altro.Text));
                    cmd1.Parameters.Add(z.CreaSqlParameter("utMod", DbType.String, User.Identity.Name));
                    string manag = cr.GetNomeCompleto(User.Identity.Name.ToUpper());
                    cmd1.Parameters.Add(z.CreaSqlParameter("Manager", DbType.String, this.Manager.Text));

                    try
                    {
                        ConnSDB.Open();
                        int newid = Convert.ToInt16(cmd1.ExecuteScalar());
                        if (newid > 0)
                            this.IdVisita.Text = newid.ToString();
                        this.GvAllegati.Visible = true;
                        ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('Visit Details saved correctly');</script>");
                        ConnSDB.Close();
                    }
                    catch (Exception ex)
                    {
                        string errore1 = ex.Message;
                    }
                }
                else
                    ClientScript.RegisterStartupScript(GetType(), "", "<script LANGUAGE='JavaScript' >alert('" + x + "');</script>");
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected string ValidaScheda()
        {
            string msg = "";
            if (this.ClientID.Text == "")
                msg = " Customer - ";
            if (this.DataVisita.IsEmpty == true)
                msg = msg + " Visit Date -";
            if (this.ParlatoCon.Text == "")
                msg = msg + " Meeting with Mr/Mrs -";
            if (msg != "")
                msg = "Compulsory Fields: " + msg;
            if (this.rgfldvalidator.Text != "")
                msg = msg + " - Not valid Start time ";
            if (this.RegularExpressionValidator1.Text != "")
                msg = msg + " - Not valid End time ";
            return msg;
        }
        protected void SalvaCliente_Click(object sender, EventArgs e)
        {
            //SalvaDatiCliente();
        }
        protected void SalvaDatiCliente()
        {
            string msg;
            try
            {
                // salva profilo cliente

                string sql = "SELECT * From OFF_ClientiSDB WHERE ";
                if (this.IdClient.Text != "")
                    sql = sql + " Id=" + System.Convert.ToString(this.IdClient.Text);
                else
                {
                    FunzioniCRM p = new FunzioniCRM();
                    msg = p.VerificaVatCode(this.PartitaIva.Text);
                    if (msg != "")
                    {
                        ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                        return;
                    }
                    sql = sql + " RagSoc=@RagSoc";
                }
                msg = ValidaDatiCliente();
                if (msg == "OK")
                {
                    Generic z = new Generic();
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, this.RagSoc.Text));
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        // update
                        this.IdClient.Text = (string)dt.Rows[0]["Id"];
                        this.ClientID.Text = (string)dt.Rows[0]["Id"];
                        sql = "UPDATE OFF_ClientiSDB SET RagSoc=@RagSoc, Indirizzo=@Indirizzo, Localita=@Localita, Cap=@Cap, Nazione=@Nazione, Telefono=@Telefono,";
                        sql = sql + "PartitaIva=@PartitaIva, SitoWeb=@SitoWeb, DataMod=GetDate(), UtMod='" + User.Identity.Name + "'";
                        sql = sql + " WHERE Id=" + System.Convert.ToString(dt.Rows[0]["Id"]);
                    }
                    else
                    {
                        // insert
                        sql = "INSERT INTO OFF_ClientiSDB (RagSoc, Indirizzo, Localita, Cap, Nazione, Manager, Attivo, TipoPagamento, AderitoSDB, Telefono, PartitaIva, SitoWeb, DataMod, UtMod)";
                        sql = sql + " VALUES(@RagSoc, @Indirizzo, @Localita, @Cap, @Nazione, '', 0, '', 0, @Telefono, @PartitaIva, @SitoWeb, GetDate(), '" + User.Identity.Name + "');";
                        sql = sql + "SELECT SCOPE_IDENTITY()";
                    }
                    cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, this.RagSoc.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("Indirizzo", DbType.String, this.Indirizzo.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("Localita", DbType.String, this.Citta.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("Cap", DbType.String, this.Cap.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("Nazione", DbType.String, this.Nazione.SelectedValue));
                    cmd.Parameters.Add(z.CreaSqlParameter("Telefono", DbType.String, this.Telefono.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("PartitaIva", DbType.String, this.PartitaIva.Text));
                    cmd.Parameters.Add(z.CreaSqlParameter("SitoWeb", DbType.String, this.Website.Text));
                    try
                    {
                        ConnSDB.Open();
                        int newid = Convert.ToInt16(cmd.ExecuteScalar());
                        if (newid > 0)
                        {
                            this.IdClient.Text = newid.ToString();
                            this.ClientID.Text = newid.ToString();
                            this.Cliente.Text = this.RagSoc.Text;
                            ConnSDB.Close();
                            FunzioniClienti fc = new FunzioniClienti();
                            fc.AggiungePlantSede(newid, this.RagSoc.Text, this.Nazione.SelectedValue);
                        }
                        ConnSDB.Close();
                        msg = "Company Data correctly saved!";
                    }
                    catch (Exception ex)
                    {
                        string errore = ex.Message;
                        ConnSDB.Close();
                        msg = "Error saving company data!";
                    }
                }
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                msg = "Error saving company data!";
            }
        }
        protected string ValidaDatiCliente()
        {
            string msg = "";
            if (this.RagSoc.Text.Trim() == "")
                msg = " - COMPANY NAME";
            if (this.Indirizzo.Text.Trim() == "")
                msg = msg + " - ADDRESS";
            if (this.Citta.Text.Trim() == "")
                msg = msg + " - CITY, STATE";
            if (this.Nazione.SelectedValue.Trim() == "")
                msg = msg + " - COUNTRY";
            if (this.Telefono.Text.Trim() == "")
                msg = msg + " - PHONE";
            if (this.PartitaIva.Text.Trim() == "")
            {
                // verifica se extra cee
                FunzioniCRM z = new FunzioniCRM();
                bool extracee = z.verificaExtraCee(this.Nazione.SelectedValue);
                if (extracee == false)
                    msg = msg + " - VAT CODE";
            }

            if (msg != "")
                msg = "COMPULSORY FIELDS: " + msg;
            else
                msg = "OK";

            return msg;
        }
        protected void Cliente_Search(object sender, SearchBoxEventArgs e)
        {
            this.ClientID.Text = "";
            MyLoc.Text = "";
            MyNaz.Text = "";
            if (!Information.IsNothing(e.Value))
            {
                this.ClientID.Text = e.Value;
                this.ClientID.Visible = true;
                string sql = "SELECT * From OFF_ClientiSDB WHERE Id=" + System.Convert.ToString(this.ClientID.Text);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Information.IsDBNull(dt.Rows[0]["Localita"]))
                        this.MyLoc.Visible = true;
                    this.MyLoc.Text = (string)dt.Rows[0]["Localita"];
                    if (!Information.IsDBNull(dt.Rows[0]["Nazione"]))
                        this.MyNaz.Visible = true;
                    this.MyNaz.Text = (string)dt.Rows[0]["Nazione"];
                    if (!Information.IsDBNull(dt.Rows[0]["Manager"]))
                        this.Manager.Text = (string)dt.Rows[0]["Manager"];

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "OpenModal('#AddVisit');", true);
                }
                FunzioniCRM cr = new FunzioniCRM();
                string msg = cr.BloccaSedi(this.ClientID.Text);
                if (msg == "")
                    this.CmSalva.Disabled = false;
                else
                {
                    this.CmSalva.Disabled = true;
                    ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                }

                string sql1 = "Select * from vw_VisiteCliente  WHERE IdCliente = " + System.Convert.ToString(this.ClientID.Text);
                SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                string Tipo = "";
                if (dt1.Rows.Count > 0)
                    Tipo = (string)dt1.Rows[0]["TipoCliente"];
                if (Tipo == "UTILIZ")
                    TipoCliente.Items[1].Selected = true;
                else if (Tipo == "COSTRU")
                    TipoCliente.Items[2].Selected = true;
                else if (Tipo == "DISTSC")
                    TipoCliente.Items[3].Selected = true;
            }
        }
        private void GvAllegati_InsertCommand(object sender, GridCommandEventArgs e)
        {
            try
            {
                GridEditableItem item = (GridEditableItem)e.Item;
                this.SqlAllegati.InsertParameters.Add("IdVisita", this.IdVisita.Text);
                this.SqlAllegati.InsertParameters.Add("IdClient", this.IdClient.Text);
                RadAsyncUpload textLink1 = (RadAsyncUpload)item.FindControl("XlsxUploadIns");
                if (textLink1.UploadedFiles.Count <= 0)
                {
                    this.SqlAllegati.InsertParameters.Add("Allegato", "");
                    e.Canceled = true;
                }
                else
                    this.SqlAllegati.InsertParameters.Add("Allegato", textLink1.UploadedFiles[0].FileName);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void PartitaIva_TextChanged(object sender, EventArgs e)
        {
            string msg = "please insert VAT code without the acronym identifying the State, For ex. ESB5500667799 Or FR11223344550";
            ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
        }


        //PHONE CALLS
        protected void FiltraChiamate(string ute)
        {
            FunzioniCRM p = new FunzioniCRM();
            string nome = p.GetNomeCompleto(ute);
            string sql = "Select * FROM vw_PhoneCalls ORDER BY DataMod DESC";
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
                sql = "Select * FROM vw_PhoneCalls WHERE Manager='" + nome + "' OR ProductManager='" + nome + "' OR UtMod='" + ute + "' ORDER BY DataMod DESC";
            SqlCalls.SelectCommand = sql;
        }
        protected void ClientePC_Search(object sender, SearchBoxEventArgs e)
        {
            this.ClienteIDPC.Text = "";
            MyLocPC.Text = "";
            MyNazPC.Text = "";

            if (!Information.IsNothing(e.Value))
            {
                ClienteIDPC.Text = e.Value;
                try
                {
                    this.SqlPlant.SelectCommand = "SELECT DISTINCT [RagSoc], [Indirizzo], [IdCliente] FROM [OFF_DestinazioniClienti] WHERE IdCliente = '" + ClienteIDPC.Text + "'";
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                }
                string sql = "SELECT * From OFF_ClientiSDB WHERE Id=" + System.Convert.ToString(this.ClienteIDPC.Text);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Information.IsDBNull(dt.Rows[0]["Localita"]))
                        this.MyLocPC.Visible = true;
                    this.MyLocPC.Text = (string)dt.Rows[0]["Localita"];
                    if (!Information.IsDBNull(dt.Rows[0]["Nazione"]))
                        this.MyNazPC.Visible = true;
                    this.MyNazPC.Text = (string)dt.Rows[0]["Nazione"];

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "OpenModal('#AddCall');", true);
                }
            }
            //AddCall.Visible = true;
            Gv_Chiamate.Visible = false;
        }
        protected void AggiungePlantSede(int idcli, string cli)
        {
            try
            {
                string sql = "SELECT id from OFF_DestinazioniClienti WHERE Sede=1 AND idCliente=" + idcli;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    sql = "INSERT INTO OFF_DestinazioniClienti (IdCliente,Sede,RagSoc) VALUES(@IdCliente,1,@RagSoc)";
                    cmd = new SqlCommand(sql, ConnSDB);
                    Generic z = new Generic();
                    cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                    cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, cli));
                    try
                    {
                        ConnSDB.Open();
                        cmd.ExecuteNonQuery();
                        ConnSDB.Close();
                    }
                    catch (Exception ex)
                    {
                        string errore = ex.Message;
                        ConnSDB.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void SalvaPC_Click(object sender, EventArgs e)
        {
            if ((ResultPC.SelectedItem.Value == "Errore"))
            {
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('Compulsory Fied: Call Outcome');</script>"));
                return;
            }
            try
            {
                var sqlt = "INSERT INTO PhoneCalls ([IdCliente], [RagSoc], [NomeCliente], [Motivo], [Note], [Esito], [DataRicon], [DataMod], [UtMod], [Manager])";
                sqlt += "VALUES (@IdCliente, @RagSoc, @NomeCliente, @Motivo, @Note, @Esito, @DataRicon, @DataMod, @UtMod, @Manager)";

                Generic z = new Generic();
                FunzioniCRM x = new FunzioniCRM();
                var cmd = new SqlCommand(sqlt, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("IdCliente", DbType.Int32, System.Convert.ToInt32(ClienteIDPC.Text)));
                cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, this.ClientePC.Text));
                // cmd.Parameters.Add(z.CreaSqlParameter("Data", DbType.DateTime, Data.SelectedDate.Value))
                cmd.Parameters.Add(z.CreaSqlParameter("NomeCliente", DbType.String, NomeClientePC.Text));
                cmd.Parameters.Add(z.CreaSqlParameter("Esito", DbType.String, ResultPC.SelectedItem.Text));
                cmd.Parameters.Add(z.CreaSqlParameter("Motivo", DbType.String, MotivoPC.Text));
                cmd.Parameters.Add(z.CreaSqlParameter("Note", DbType.String, NotePC.Text));
                cmd.Parameters.Add(z.CreaSqlParameter("DataRicon", DbType.DateTime, CalendarioPC.SelectedDate));
                cmd.Parameters.Add(z.CreaSqlParameter("DataMod", DbType.DateTime, DateTime.Today));
                cmd.Parameters.Add(z.CreaSqlParameter("UtMod", DbType.String, User.Identity.Name));
                cmd.Parameters.Add(z.CreaSqlParameter("Manager", DbType.String, x.ResponsabileClienteWebt(Convert.ToInt32(ClienteIDPC.Text))));
                try
                {
                    ConnSDB.Open();
                    // Dim X As String = cmd.ExecuteNonQuery()
                    var v = cmd.ExecuteScalar();
                    Gv_Chiamate.Visible = true;
                    //AddCall.Visible = false;
                    //AddCall.InnerText = null;

                    ConnSDB.Close();
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                    ConnSDB.Close();
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            ClientePC.Text = "";

            // Dim sql As String = "Select * FROM [PhoneCalls]"
            // SqlCalls.SelectCommand = sql.ToString()
            // DIV_Chiamate.DataBind()
            if (IsPostBack)
            {
                // SqlCalls.SelectCommand = "Select * FROM [PhoneCalls] where utmod='" & User.Identity.Name & "'"
                Gv_Chiamate.DataBind();
            }

            string cl = ClientePC.Text;
        }
        protected void ResultPC_SelectedIndexChanged(object sender, DropDownListEventArgs e)
        {
            if ((ResultPC.SelectedItem.Value == "Ricontattare"))
            {
                CalendarioPC.Visible = true;
            }
            else if (ResultPC.SelectedItem.Value != "Ricontattare")
            {
                CalendarioPC.Visible = false;
            }
            //AddCall.Visible = true;
            Gv_Chiamate.Visible = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "OpenModal('#AddCall');", true);
        }
        protected void EditVisit_Click(object sender, EventArgs e)
        {
            if (Information.IsNumeric(Gv_Visite.SelectedValue))
            {
                Int32 id = (int)Gv_Visite.SelectedValue;
                CaricaDati_Visit(id);
            }
        }
        protected void CaricaDati_Visit(Int32 id)
        {
            string sql = "SELECT * FROM VisiteCliente WHERE Id=" + id;
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                if (Information.IsDate(dt.Rows[0]["Data_Visita"]))
                    this.DataVisita.SelectedDate = (DateTime)dt.Rows[0]["Data_Visita"];
                this.IdVisita.Text = Request.QueryString["Id"];
                this.ClientID.Text = Convert.ToString(dt.Rows[0]["IdCliente"]);
                this.Cliente.Text = (string)dt.Rows[0]["Cliente"];
                if (!Information.IsDBNull(dt.Rows[0]["TipoCliente"]))
                    this.TipoCliente.SelectedValue = (string)dt.Rows[0]["TipoCliente"];
                if (!Information.IsDBNull(dt.Rows[0]["ParlatoCon"]))
                    this.ParlatoCon.Text = (string)dt.Rows[0]["ParlatoCon"];
                if (!Information.IsDBNull(dt.Rows[0]["OraInizio"]))
                    this.OraInizio.Text = (string)dt.Rows[0]["OraInizio"];
                if (!Information.IsDBNull(dt.Rows[0]["OraFine"]))
                    this.OraFine.Text = (string)dt.Rows[0]["OraFine"];
                if (!Information.IsDBNull(dt.Rows[0]["MotivoVisita"]))
                    this.MotivoVisita.SelectedValue = (string)dt.Rows[0]["MotivoVisita"];
                if (!Information.IsDBNull(dt.Rows[0]["Altro"]))
                    this.Altro.Text = (string)dt.Rows[0]["Altro"];
                if (!Information.IsDBNull(dt.Rows[0]["PartecipantiInterni"]))
                    this.PartecipantiInterni.Text = (string)dt.Rows[0]["PartecipantiInterni"];
                this.GvAllegati.Visible = true;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "OpenModal('#AddVisit');", true);
            }

            sql = "SELECT * From OFF_ClientiSDB WHERE Id = " + this.ClientID.Text;
            cmd = new SqlCommand(sql, ConnSDB);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                this.Cliente.Text = (string)dt.Rows[0]["RagSoc"];
                this.ClientID.Visible = true;
                if (!Information.IsDBNull(dt.Rows[0]["Localita"]))
                    this.MyLoc.Visible = true;
                this.MyLoc.Text = (string)dt.Rows[0]["Localita"];
                if (!Information.IsDBNull(dt.Rows[0]["Nazione"]))
                    this.MyNaz.Visible = true;
                this.MyNaz.Text = (string)dt.Rows[0]["Nazione"];
                if (!Information.IsDBNull(dt.Rows[0]["Manager"]))
                    this.Manager.Text = (string)dt.Rows[0]["Manager"];
            }
        }
    }
}