﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.VisualBasic;
using SDB_2021.Code;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace SDB_2021.CRM
{
    public partial class QuotationsList : System.Web.UI.Page
    {
        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        SqlConnection ConnTSE = new SqlConnection(ConfigurationManager.ConnectionStrings["TSE"].ConnectionString);
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
                // filtra elenco in base al magager
                FiltraOfferte();
        }
        protected void FiltraOfferte()
        {
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
            {
                FunzioniCRM p = new FunzioniCRM();
                string nome = p.GetNomeCompleto(User.Identity.Name);
                string sql = "SELECT * FROM [VisiteCliente]  WHERE Manager='" + nome + "' ORDER BY [Data_Visita] DESC";
                sql = "SELECT [Numero_Offerta], [Numero_Revisione], [Data_Offeerta], [Data_Revisione], [Codice_Cliente], [RagSoc],Nazione, [Validita], [Stato], [Codice_Agente], [Prezzo_Vendita],Prezzo_Totale, [Note], [Ut_Mod], [Valuta], [Manager],DescrizioneStatoEn,Codice_Parlante As Articolo,Rag_Sociale_Dest as Destinazione, Note_Arrivo, Data_Arrivo_Presunta,MotivoNonAccettata,Trasporto_Risposta FROM [vw_OfferteT] WHERE Mod_Calcolo = 'PDF' AND Manager=@manager order by right(numero_offerta,2) desc, convert(int,left(numero_offerta,len(numero_offerta)-4)) desc, numero_revisione desc ";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("Manager", DbType.String, nome));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.ElencoOfferte.DataSourceID = null;
                this.ElencoOfferte.DataSource = dt;
                this.ElencoOfferte.MasterTableView.GetColumn("EliminaOfferta").Visible = false;
            }
        }
        protected string VerificaOffertaModificabile(string id)
        {
            string msg = "";
            try
            {
                string sql = "SELECT Mod_Calcolo FROM vw_Offerte WHERE Numero_Offerta='" + id + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string x = dt.Rows[0]["Mod_Calcolo"].ToString().Trim();
                    if (x != "PDF")
                        msg = "The Offert cannot be modified!";
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return msg;
        }

        protected void EditQuotation_ServerClick(object sender, EventArgs e)
        {  
            string msg = VerificaOffertaModificabile((string)this.ElencoOfferte.SelectedValue);
            if (msg == "")
                EditOff((string)this.ElencoOfferte.SelectedValue);
            else
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
        }
        protected void EditOff(string off_if)
        {
            if (!IsPostBack)
            {
                if (User.IsInRole("Agenti"))
                {
                    this.lblCommAgente.Visible = false;
                    this.CommissioneAgente.Visible = false;
                }
                if (User.IsInRole("Amministratore"))
                    this.Valuta.Visible = true;
                if (!Information.IsNothing(Request.QueryString["Id"]))
                {
                    this.Num_Offe.Text = Request.QueryString["Id"];
                    this.NuovaOff.Text = "Modifica";
                }
                else
                    this.NuovaOff.Text = "Nuova";
                string sql;
                string numOff;
                if (this.NuovaOff.Text == "Nuova")
                {
                    sql = "SELECT Num_Offerta as y FROM OfferteT where serie_offerta='" + "O" + Strings.Right(DateTime.Now.Year.ToString(), 2) + "' ORDER BY Convert(INT,Right(Numero_Offerta,2)) DESC, Convert(INT,Left(Numero_Offerta,Len(Numero_Offerta)-4)) DESC";
                    SqlCommand mycmd = new SqlCommand(sql, ConnSDB);
                    ConnSDB.Open();
                    int x = Convert.ToInt32(mycmd.ExecuteScalar()) + 1;
                    numOff = x.ToString();
                    ConnSDB.Close();
                    this.Num_Offe.Text = numOff.ToString() + "/O" + Strings.Right(DateTime.Now.Year.ToString(), 2);
                    this.Data_Offe.Text = DateTime.Now.ToShortDateString().ToString();
                    Supporto supp = new Supporto();
                    string y = String.Format((string)Data_Offe.Text, "dd/MM/yyyy");
                    DateTime z = DateTime.Parse(y);
                    this.Scadenza.Text = supp.Get_DataScadenza(z).ToString();
                    this.Stato_Off.SelectedValue = "1";
                    this.Data_Offe.Text = Strings.Format(DateTime.Today, "dd/MM/yyyy");
                    if (Information.IsNumeric(Request.QueryString["cli"]))
                        // arriva da company data, percui seleziona il cliente
                        CaricaDatiCliente(Request.QueryString["cli"]);
                }
                else
                {
                    sql = "SELECT * FROM OfferteT WHERE Numero_Offerta='" + this.Num_Offe.Text + "' AND Numero_Revisione=1";
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        // quotation
                        this.Data_Offe.Text = String.Format((String)dt.Rows[0]["Data_Offeerta"], "dd/MM/yyyy");
                        if (Information.IsDate(dt.Rows[0]["Validita"]))
                            this.Scadenza.Text = String.Format((String)dt.Rows[0]["Validita"], "dd/MM/yyyy");
                        else
                            this.Scadenza.Text = DateAndTime.DateAdd(DateInterval.Day, 30, DateTime.Parse((string)dt.Rows[0]["Data_Offeerta"])).ToString();
                        if (!Information.IsDBNull(dt.Rows[0]["Num_Ordine_Cliente"]))
                            this.num_ordcliente.Text = (string)dt.Rows[0]["Num_Ordine_Cliente"];
                        if (Information.IsDate(dt.Rows[0]["Data_Ordine_Cliente"]))
                            this.num_ordcliente.Text = String.Format((string)dt.Rows[0]["Data_Ordine_Cliente"], "dd/MM/yyyy").ToString();
                        if (!Information.IsDBNull(dt.Rows[0]["Serie_Ordine_Cliente"]))
                            this.num_ordcliente.Text = (string)dt.Rows[0]["Serie_Ordine_Cliente"];
                        this.Stato_Off.SelectedValue = (string)dt.Rows[0]["Stato"];
                        if (System.Convert.ToInt32(dt.Rows[0]["Stato"]) == 6 | System.Convert.ToInt32(dt.Rows[0]["Stato"]) == 7)
                            // non modificabile e non confermabile
                            DisattivaSALVACO(true);

                        this.Lingua.SelectedValue = (string)dt.Rows[0]["Lingua"];
                        CaricaPagamenti((string)dt.Rows[0]["Lingua"]);
                        CaricaPorto((string)dt.Rows[0]["Lingua"]);
                        // company data
                        string ErpCode = "";
                        string IdWebt = "";
                        if (!Information.IsDBNull(dt.Rows[0]["IdCliente"]))
                            IdWebt = (string)dt.Rows[0]["IdCliente"];
                        if (!Information.IsDBNull(dt.Rows[0]["Codice_Cliente"]))
                        {
                            ErpCode = (string)dt.Rows[0]["Codice_Cliente"];
                            FunzioniCRM kk = new FunzioniCRM();
                            string BloccAmm = kk.VerificaBloccoAmministrativo(Convert.ToInt16(IdWebt));
                            if (BloccAmm != "")
                            {
                                string verBlocAmm = kk.BloccatoAmm("");
                                this.Salva.Enabled = false;
                                this.SI_Conf.Enabled = false;
                                this.SI_Conf.ForeColor = System.Drawing.Color.Red;
                                this.Salva.ForeColor = System.Drawing.Color.Red;
                                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + verBlocAmm + "');</script>"));
                            }
                            else
                            {
                                this.Salva.Enabled = true;
                                this.Salva.ForeColor = System.Drawing.Color.Black;
                                this.SI_Conf.Enabled = true;
                                this.SI_Conf.ForeColor = System.Drawing.Color.Black;
                            }
                            if (IdWebt == "" & ErpCode != "")
                                IdWebt = GetNewId(ErpCode);
                        }
                        else if (!Convert.IsDBNull(dt.Rows[0]["Codice_Cliente_CRM"]))
                            IdWebt = (string)dt.Rows[0]["Codice_Cliente_CRM"];
                        this.cod_Cliente.Text = ErpCode;
                        this.IdClient.Text = IdWebt;
                        if (!Convert.IsDBNull(dt.Rows[0]["Ragione_Soc"]))
                            this.Cliente.Text = (string)dt.Rows[0]["Ragione_Soc"];

                        if (!Convert.IsDBNull(dt.Rows[0]["Serie_Ordine_Cliente"]))
                            this.num_ordcliente.Text = (string)dt.Rows[0]["Serie_Ordine_Cliente"];
                        if (!Convert.IsDBNull(dt.Rows[0]["Indirizzo"]))
                            this.Indirizzo.Text = (string)dt.Rows[0]["Indirizzo"];
                        if (!Convert.IsDBNull(dt.Rows[0]["Cap"]))
                            this.Cap.Text = (string)dt.Rows[0]["Cap"];
                        if (!Convert.IsDBNull(dt.Rows[0]["localita"]))
                            this.localita.Text = (string)dt.Rows[0]["localita"];
                        if (!Convert.IsDBNull(dt.Rows[0]["Nazione"]))
                            this.Nazione.Text = (string)dt.Rows[0]["Nazione"];
                        if (!Convert.IsDBNull(dt.Rows[0]["Manager"]))
                            this.Ref_Intern.Text = (string)dt.Rows[0]["Manager"];
                        // Delivery address
                        if (!Convert.IsDBNull(dt.Rows[0]["Rag_Sociale_Dest"]))
                        {
                            string sedeid = "";
                            if (!Convert.IsDBNull(dt.Rows[0]["IdSede"]))
                                sedeid = (string)dt.Rows[0]["IdSede"];
                            else
                                sedeid = GetIdSede((string)dt.Rows[0]["Rag_Sociale_Dest"]);

                            if (Information.IsNumeric(sedeid))
                            {
                                this.IdSede.Text = sedeid;
                                GetContatti();
                            }
                        }
                        if (Information.IsNumeric(dt.Rows[0]["Prezzo_Vendita"]))
                        {
                            if (System.Convert.ToDouble(dt.Rows[0]["Prezzo_Vendita"]) > 0)
                                this.TotaleOfferta.Text = String.Format(Convert.ToDouble((string)dt.Rows[0]["Prezzo_Vendita"]).ToString(), "n1");
                        }

                        try
                        {
                            // payment terms
                            if (!Information.IsDBNull(dt.Rows[0]["Tipo_Pagamento"]))
                            {
                                if (!Information.IsNothing(TipoPagamento.FindItemByValue((string)dt.Rows[0]["Tipo_Pagamento"])))
                                    this.TipoPagamento.SelectedValue = (string)dt.Rows[0]["Tipo_Pagamento"];
                            }
                            if (!Information.IsDBNull(dt.Rows[0]["Consegna_Libera"]))
                                this.ConsegnaLibera.Text = (string)dt.Rows[0]["Consegna_Libera"];
                            if (!Information.IsDBNull(dt.Rows[0]["Cambio"]))
                                this.CambioV.Text = (string)dt.Rows[0]["Cambio"];
                            if (!Information.IsDBNull(dt.Rows[0]["Valuta"]))
                                this.Valuta.SelectedValue = (string)dt.Rows[0]["Valuta"];
                            if (!Information.IsDBNull(dt.Rows[0]["Trasporto"]))
                                this.MagazzinoUscita.SelectedValue = (string)dt.Rows[0]["Trasporto"];
                            if (!Information.IsDBNull(dt.Rows[0]["Cod_Porto"]))
                                // If Not IsNothing(TipoPagamento.FindItemByValue(dt.Rows[0]["Cod_Porto"])) Then
                                this.Porto.SelectedValue = (string)dt.Rows[0]["Cod_Porto"];
                            if (!Information.IsDBNull(dt.Rows[0]["Costo_Trasporto"]))
                            {
                                if (System.Convert.ToDouble(dt.Rows[0]["Costo_Trasporto"]) > 0)
                                    this.CostoTrasporto.Text = (string)dt.Rows[0]["Costo_Trasporto"];
                            }
                            if (!Information.IsDBNull(dt.Rows[0]["CostoTrasportoInterno"]))
                            {
                                if (System.Convert.ToDouble(dt.Rows[0]["CostoTrasportoInterno"]) > 0)
                                    this.CostoTrasportoInterno.Text = (string)dt.Rows[0]["CostoTrasportoInterno"];
                            }
                            if (!Information.IsDBNull(dt.Rows[0]["Imballo"]))
                                this.Imballo.SelectedValue = (string)dt.Rows[0]["Imballo"];
                            if (!Information.IsDBNull(dt.Rows[0]["Note_Cliente"]))
                                this.NoteCliente.Text = (string)dt.Rows[0]["Note_Cliente"];
                            if (!Information.IsDBNull(dt.Rows[0]["Id_Agente"]))
                            {
                                if (!Information.IsNothing(TipoPagamento.FindItemByValue((string)dt.Rows[0]["Id_Agente"])))
                                    this.Agente.SelectedValue = (string)dt.Rows[0]["Id_Agente"];
                            }
                            if (Information.IsNumeric(dt.Rows[0]["CommissioneAgente"]))
                            {
                                if (System.Convert.ToDouble(dt.Rows[0]["CommissioneAgente"]) > 0)
                                    this.CommissioneAgente.Text = (string)dt.Rows[0]["CommissioneAgente"];
                            }
                            if (Information.IsDate(dt.Rows[0]["Consegna"]))
                                this.ConsegnaCO.Text = String.Format((string)dt.Rows[0]["Consegna"], "dd/MM/yyyy");

                            if (Information.IsDate(dt.Rows[0]["Consegna"]))
                                this.Consegn.Text = String.Format((string)dt.Rows[0]["Consegna"], "dd/MM/yyyy");
                        }
                        catch (Exception ex)
                        {
                            string erroreCaricamentoDati = ex.Message;
                        }
                        // Quotation details
                        sql = "SELECT * FROM Offerte_Righe WHERE Numero_Offerta='" + this.Num_Offe.Text + "' AND Numero_Revisione=1 Order By Numero_Riga";
                        cmd = new SqlCommand(sql, ConnSDB);
                        da = new SqlDataAdapter(cmd);
                        dt = new DataTable();
                        da.Fill(dt);
                        for (var i = 0; i <= dt.Rows.Count - 1; i++)
                        {
                            TextBox q = (TextBox)this.PanelR.FindControl("Qta" + i + 1);
                            RadComboBox incis = (RadComboBox)this.PanelR.FindControl("Inc" + i + 1);
                            RadComboBox incis2 = (RadComboBox)this.PanelR.FindControl("LinH" + i + 1);
                            TextBox ln = (TextBox)this.PanelR.FindControl("Linee" + i + 1);
                            TextBox an = (TextBox)this.PanelR.FindControl("Ang" + i + 1);
                            TextBox vl = (TextBox)this.PanelR.FindControl("Vol" + i + 1);
                            TextBox pu = (TextBox)this.PanelR.FindControl("PrezzoU" + i + 1);
                            TextBox sc = (TextBox)this.PanelR.FindControl("Sconto" + i + 1);
                            Label ps = (Label)this.PanelR.FindControl("PrezzoS" + i + 1);
                            Label pt = (Label)this.PanelR.FindControl("PrezzoTot" + i + 1);

                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Famiglia"]))
                            {
                                this.Famiglia.SelectedValue = dt.Rows[i]["Codice_Famiglia"].ToString().Trim();
                                AggiornaElencoDisegni(dt.Rows[i]["Codice_Famiglia"].ToString().Trim());
                            }
                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Sottofamiglia"]))
                                this.Sottofamiglia.Text = dt.Rows[i]["Codice_Sottofamiglia"].ToString().Trim();
                            if (!Information.IsDBNull(dt.Rows[i]["Disegno"]))
                            {
                                this.Disegno.SelectedValue = dt.Rows[i]["Disegno"].ToString().Trim();
                                AggiornaDisegno(dt.Rows[i]["Disegno"].ToString().Trim(), dt.Rows[i]["Codice_Famiglia"].ToString().Trim());
                            }
                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Parlante"]))
                                this.CodArticolo.Text = (string)dt.Rows[i]["Codice_Parlante"];
                            AggiornaIncisioni(dt.Rows[i]["Codice_Famiglia"].ToString().Trim(), dt.Rows[i]["Codice_Sottofamiglia"].ToString().Trim(), i + 1);
                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Struttura"]))
                                this.Struttura.Text = (string)dt.Rows[i]["Codice_Struttura"];
                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Modello"]))
                                this.Costruttore.Text = (string)dt.Rows[i]["Codice_Modello"];
                            if (!Information.IsDBNull(dt.Rows[i]["Costruzione"]))
                                this.Costruzione.SelectedValue = (string)dt.Rows[i]["Costruzione"];
                            if (!Information.IsDBNull(dt.Rows[i]["TipoRipristino"]))
                            {
                                if ((string)dt.Rows[i]["TipoRipristino"] != "")
                                {
                                    CaricaTipoRipristino(dt.Rows[i]["Disegno"].ToString().Trim(), (string)dt.Rows[i]["Costruzione"]);
                                    this.TipoRipristino.SelectedValue = (string)dt.Rows[i]["TipoRipristino"];
                                    this.TipoRipristino.Visible = true;
                                }
                            }
                            if (Information.IsNumeric(dt.Rows[i]["Diametro"]))
                                this.Diametro.Text = (string)dt.Rows[i]["Diametro"];
                            if (Information.IsNumeric(dt.Rows[i]["Diametro_Interno"]))
                            {
                                if (System.Convert.ToDouble(dt.Rows[i]["Diametro_Interno"]) > 0)
                                    this.DiamInterno.Text = (string)dt.Rows[i]["Diametro_Interno"];
                            }
                            if (Information.IsNumeric(dt.Rows[i]["Tavola"]))
                                this.Tavola.Text = (string)dt.Rows[i]["Tavola"];
                            if (Information.IsNumeric(dt.Rows[i]["Parte_Retinata"]))
                                this.TavolaIncisa.Text = (string)dt.Rows[i]["Parte_Retinata"];
                            if (Information.IsNumeric(dt.Rows[i]["Lunghezza"]))
                                this.Lunghezza.Text = (string)dt.Rows[i]["Lunghezza"];
                            if (!Information.IsDBNull(dt.Rows[i]["Codice_Fornitura"]))
                                this.Fornitura.SelectedValue = dt.Rows[i]["Codice_Fornitura"].ToString().Trim();
                            if (Information.IsNumeric(dt.Rows[i]["Peso"]))
                                this.PesoW.Text = (string)dt.Rows[i]["Peso"];

                            if (System.Convert.ToInt32(dt.Rows[i]["Quantita"]) > 0)
                            {
                                q.Text = (string)dt.Rows[i]["Quantita"];
                                if (!Information.IsDBNull(dt.Rows[i]["Codice_Incisione"]))
                                    incis.SelectedValue = dt.Rows[i]["Codice_Incisione"].ToString().Trim();
                                VisualizzaLinH(i + 1);
                                if (dt.Rows[i]["Codice_Incisione"].ToString().Trim() == "HPC" | dt.Rows[i]["Codice_Incisione"].ToString().Trim() == "HPF")
                                    incis2.SelectedValue = dt.Rows[i]["Codice_Lineatura"].ToString().Trim();
                                else
                                    ln.Text = (string)dt.Rows[i]["Num_Linee"];
                                if (!Information.IsDBNull(dt.Rows[i]["Angolo"]))
                                    an.Text = (string)dt.Rows[i]["Angolo"];
                                if (!Information.IsDBNull(dt.Rows[i]["Volume"]))
                                    vl.Text = (string)dt.Rows[i]["Volume"];
                                if (Information.IsNumeric(dt.Rows[i]["Prezzo_Totale"]))
                                    pu.Text = String.Format(Convert.ToDouble(dt.Rows[i]["Prezzo_Totale"]).ToString(), "n1");
                                if (Information.IsNumeric(dt.Rows[i]["Sconto"]))
                                {
                                    if (System.Convert.ToDouble(dt.Rows[i]["Sconto"]) != 0)
                                        sc.Text = String.Format(Convert.ToDouble(dt.Rows[i]["Sconto"]).ToString(), "n2");
                                }
                                if (Information.IsNumeric(dt.Rows[i]["Prezzo_Vendita"]))
                                {
                                    ps.Text = String.Format(Convert.ToDouble(dt.Rows[i]["Prezzo_Vendita"]).ToString(), "n1");
                                    double pven = Convert.ToDouble(dt.Rows[i]["Prezzo_Vendita"]);
                                    int qta = Convert.ToInt16(string.Format(dt.Rows[i]["Quantita"].ToString(), "n2"));
                                    pt.Text = (pven * qta).ToString();
                                }
                                if (!Information.IsDBNull(dt.Rows[0]["TipoScontoStampa"]))
                                    this.TipoScontoStampa.SelectedValue = (string)dt.Rows[0]["TipoScontoStampa"];
                            }
                        }
                    }
                }
            }
            LimitaClienti();
        }
        protected void DisattivaSALVACO(bool m)
        {
            if (m == true)
            {
                this.Salva.Enabled = false;
                this.Salva.ForeColor = System.Drawing.Color.Red;
                this.SI_Conf.Enabled = false;
                this.SI_Conf.ForeColor = System.Drawing.Color.Red;
            }
        }
        protected void LimitaClienti()
        {
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
            {
                FunzioniCRM p = new FunzioniCRM();
                string nome = p.GetNomeCompleto(User.Identity.Name);
                this.SqlClienti.SelectCommand = "Select Id, RagSoc FROM OFF_ClientiSDB WHERE Manager='" + nome + "' OR BackOffice='" + nome + "'";
            }
        }
        protected void GetContatti()
        {
            // verifica se la sede è collegata ad un altro ID
            string sql1 = "SELECT CollegatoAID FROM OFF_DestinazioniClienti WHERE Idcliente = " + Convert.ToInt32(this.IdClient.Text) + " AND Id=" + Convert.ToInt32(this.IdSede.Text);
            SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            Int32 IdColl = 0;
            if (dt1.Rows.Count > 0)
            {
                if (Information.IsNumeric(dt1.Rows[0]["CollegatoAId"]))
                    IdColl = Convert.ToInt32(dt1.Rows[0]["CollegatoAId"]);
            }
            string sql = "SELECT Id, [Nominativo], [Telefono], [Email], TipoContatto,Note,Disattivato FROM [OFF_ContattiClienti]";
            sql += " WHERE ([Idcliente] = @Idcliente) AND (IdSede=@IdSede  ";
            if (IdColl > 0)
                sql += " OR IdSede=" + IdColl;
            sql += ") ORDER BY [Nominativo]";
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            Generic z = new Generic();
            cmd.Parameters.Add(z.CreaSqlParameter("Idcliente", DbType.Int32, this.IdClient.Text));
            cmd.Parameters.Add(z.CreaSqlParameter("IdSede", DbType.Int32, this.IdSede.Text));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                string ampCont = "";
                string sacCont = "";
                string quaCont = "";
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    //if (!IsDBNull(dt.Rows[i]["TipoContatto"]))
                    //{
                    //}
                }
                this.contattoAMP.Text = ampCont;
                this.contattoCertificati.Text = quaCont;
                this.contattoStatoAvanzamento.Text = sacCont;
            }
            else
                ResetContattiDoc();
        }
        protected void ResetContattiDoc()
        {
            this.contattoAMP.Text = "";
            this.contattoCertificati.Text = "";
            this.contattoStatoAvanzamento.Text = "";
        }
        protected string GetIdSede(string sede)
        {
            string sedeId = "";
            try
            {
                string sql = "SELECT Id FROM OFF_DestinazioniClienti WHERE RagSoc=@RagSoc";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("RagSoc", DbType.String, sede));
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    sedeId = (string)dt.Rows[0]["Id"];
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return sedeId;
        }
        protected string GetNewId(string Codcli)
        {
            string newId = "";
            try
            {
                Generic z = new Generic();
                string sql = "SELECT Id FROM OFF_ClientiSDB WHERE ERPCode=@ERPCode";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("ERPCode", DbType.String, Codcli));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    newId = System.Convert.ToString(dt.Rows[0]["Id"]);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return newId;
        }
        protected void CaricaPorto(string lg)
        {
            try
            {
                string sql= "SELECT RTrim(cod_porto) as cod_porto, RTrim(des_porto) as des_porto,RTrim(des_poto_ing) as des_poto_ing  FROM BYT_PORTO";
                string campo = "des_porto";
                if (lg == "EN")
                    campo = "des_poto_ing";
                SqlCommand mycmd = new SqlCommand(sql, ConnTSE);
                SqlDataAdapter da = new SqlDataAdapter(mycmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow row;
                row = ds.Tables[0].NewRow();
                row["cod_porto"] = "";
                row[campo] = "----";
                ds.Tables[0].Rows.InsertAt(row, 0);
                this.Porto.DataSource = ds;
                this.Porto.DataTextField = campo;
                this.Porto.DataValueField = "cod_porto";
                this.Porto.DataBind();
            }
            catch (Exception ex)
            {
            }
        }
        public void CaricaPagamenti(string ling)
        {
            try
            {
                string str7 = "SELECT RTrim(cod_pag) as cod_pag,des_pag FROM BYT_COND_PAG";
                if (ling != "IT")
                    str7 = "SELECT RTrim(cod_pag) as cod_pag,des_pag_ing as des_pag FROM BYT_COND_PAG";
                SqlCommand command3 = new SqlCommand(str7, ConnTSE);
                DataSet set5 = new DataSet();
                SqlDataAdapter sqlda3 = new SqlDataAdapter(command3);
                sqlda3.Fill(set5);
                this.TipoPagamento.DataSourceID = null;
                this.TipoPagamento.DataSource = set5;
                this.TipoPagamento.DataTextField = "des_pag";
                this.TipoPagamento.DataValueField = "cod_pag";
                this.TipoPagamento.DataBind();
            }
            catch (Exception ex)
            {
                this.Errore.Text = ex.Message;
            }
        }
        protected void CaricaTipoRipristino(string dis, string costr)
        {
            try
            {
                string sql = "SELECT TipoRipristinoIT,TipoRipristinoEN FROM ListinoPDF WHERE Disegno='" + dis + "' AND Costruzione='" + costr + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                TipoRipristino.DataTextField = "TipoRipristinoEN";
                TipoRipristino.DataValueField = "TipoRipristinoIT";
                this.TipoRipristino.DataSource = dt;
                this.TipoRipristino.DataBind();
                if (dt.Rows.Count > 0)
                    TipoRipristino.Visible = true;
                else
                    TipoRipristino.Visible = false;
            }
            catch (Exception ex)
            {
            }
        }
        protected void CaricaDatiCliente(string cli)
        {
            try
            {
                FunzioniCRM z = new FunzioniCRM();
                string sql = "SELECT * FROM OFF_ClientiSDB WHERE  Id=" + System.Convert.ToString(cli);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    this.IdClient.Text = cli;
                    if (!Information.IsDBNull(dt.Rows[0]["RagSoc"]))
                        this.Cliente.Text = (string)dt.Rows[0]["RagSoc"];

                    CaricaPagamenti(this.Lingua.SelectedValue);
                    CaricaPorto(this.Lingua.SelectedValue);
                    if (!Information.IsDBNull(dt.Rows[0]["ERPCode"]))
                    {
                        this.cod_Cliente.Text = (string)dt.Rows[0]["ERPCode"];
                        if (System.Convert.ToBoolean(dt.Rows[0]["BloccatoAmm"]) == true)
                        {
                            FunzioniCRM kk = new FunzioniCRM();
                            string verBlocAmm = kk.BloccatoAmm((string)dt.Rows[0]["ERPCode"]);
                            this.Salva.Enabled = false;
                            this.SI_Conf.Enabled = false;
                            this.SI_Conf.ForeColor = System.Drawing.Color.Red;
                            this.Salva.ForeColor = System.Drawing.Color.Red;
                            ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + verBlocAmm + "');</script>"));
                        }
                        else
                        {
                            this.Salva.Enabled = true;
                            this.Salva.ForeColor = System.Drawing.Color.DarkGray;
                            this.SI_Conf.Enabled = true;
                            this.SI_Conf.ForeColor = System.Drawing.Color.DarkGray;
                        }
                        this.TipoPagamento.SelectedValue = z.GetPagamentoCliente((string)dt.Rows[0]["ERPCode"], cli);
                        this.Porto.SelectedValue = z.GetPortoCliente((string)dt.Rows[0]["ERPCode"], cli);
                        this.Agente.SelectedValue = z.CaricaAgente((string)dt.Rows[0]["ERPCode"]);
                    }
                    if (!Information.IsDBNull(dt.Rows[0]["Indirizzo"]))
                        this.Indirizzo.Text = (string)dt.Rows[0]["Indirizzo"];
                    if (!Information.IsDBNull(dt.Rows[0]["cap"]))
                        this.Cap.Text = (string)dt.Rows[0]["cap"];
                    if (!Information.IsDBNull(dt.Rows[0]["Localita"]))
                        this.localita.Text = (string)dt.Rows[0]["Localita"];
                    if (!Information.IsDBNull(dt.Rows[0]["AderitoSDB"]))
                        this.AderitoSDB.Checked = System.Convert.ToBoolean(dt.Rows[0]["AderitoSDB"]);
                    if (!Information.IsDBNull(dt.Rows[0]["Nazione"]))
                    {
                        if ((string)dt.Rows[0]["Nazione"] == "000")
                            this.Nazione.Text = "ITALIA";
                        else
                            this.Nazione.Text = GetNazione((string)dt.Rows[0]["Nazione"]);
                    }
                    if (!Information.IsDBNull(dt.Rows[0]["Manager"]))
                        this.Ref_Intern.Text = (string)dt.Rows[0]["Manager"];
                    else if (!Information.IsDBNull(dt.Rows[0]["Backoffice"]))
                        this.Ref_Intern.Text = (string)dt.Rows[0]["Backoffice"];
                    string lg = "EN";
                    if (this.Nazione.Text == "ITALIA")
                        lg = "IT";
                    this.Lingua.SelectedValue = lg;
                    CaricaPagamenti(lg);
                    CaricaPorto(lg);
                    CaricaTools(IdClient.Text, this.Famiglia.SelectedValue);
                    FunzioniCRM cr = new FunzioniCRM();
                    string msg = cr.BloccaSedi(System.Convert.ToInt32(IdClient.Text).ToString());
                    if (msg == "")
                    {
                        this.Salva.Enabled = true;
                        this.cod_Cliente.Enabled = true;
                        msg = z.GetNoteCliente(System.Convert.ToInt32(IdClient.Text));
                        if (msg != "")
                            ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                    }
                    else
                    {
                        this.Salva.Enabled = false;
                        this.cod_Cliente.Enabled = false;
                        ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected string GetNazione(string codnaz)
        {
            string naz = "";
            try
            {
                string sql = "Select Nazione FROM Nazioni WHERE Cod='" + codnaz + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Information.IsDBNull(Nazione))
                        naz = dt.Rows[0]["Nazione"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return naz;
        }
        protected void CaricaTools(string codcli, string fam)
        {
            try
            {
                string sql = "SELECT DISTINCT DISEGNO FROM vw_OFF_MacchineClienti WHERE IdCliente=" + System.Convert.ToString(codcli);
                if (fam != "")
                    sql += " AND Famiglia='" + fam + "'";
                if (User.IsInRole("Agenti"))
                    sql += " AND Sottofamiglia<>'CO'";

                sql += " ORDER BY DISEGNO";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.Disegno.DataSourceID = null;
                this.Disegno.DataSource = dt;
                this.Disegno.DataBind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void VisualizzaLinH(int r)
        {
            RadComboBox eng = (RadComboBox)PanelR.FindControl("inc" + r);

            TextBox l = (TextBox)PanelR.FindControl("Linee" + r);
            RadComboBox lx = (RadComboBox)PanelR.FindControl("LinH" + r);
            if (eng.SelectedValue.ToString().Trim() == "HPC" | eng.SelectedValue.ToString().Trim() == "HPF")
            {
                l.Visible = false;
                l.Text = "";
                lx.Visible = true;
            }
            else
            {
                l.Visible = true;
                lx.Visible = false;
                lx.SelectedValue = "";
            }
        }
        protected void AggiornaElencoDisegni(string fam)
        {
            try
            {
                string sql = "SELECT DISTINCT Disegno FROM ListinoPDF WHERE (Famiglia = '" + fam + "') ORDER BY Disegno";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.Disegno.DataSourceID = null;
                this.Disegno.DataSource = dt;
                this.Disegno.DataTextField = "Disegno";
                this.Disegno.DataValueField = "Disegno";
                this.Disegno.DataBind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void AggiornaIncisioni(string fam, string subfam, int i)
        {
            try
            {
                string sql = "SELECT DISTINCT RTrim(Codice_Incisione) as Codice_Incisione, Descrizione_Incisione_EN FROM Incisioni_Struttura WHERE ((Codice_Famiglia = '" + fam + "') AND (Codice_Sottofamiglia = '" + subfam + "') AND offPdf=1)";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                // For i = 1 To 10
                RadComboBox inc = (RadComboBox)this.PanelR.FindControl("Inc" + i);
                inc.DataSourceID = null;
                inc.DataSource = dt;
                inc.DataTextField = "Descrizione_Incisione_EN";
                inc.DataValueField = "Codice_Incisione";
                inc.DataBind();
            }
            // Next
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void AggiornaDisegno(string dis, string fam)
        {
            try
            {
                string sql = "SELECT * FROM ListinoPDF WHERE Famiglia='" + fam + "' AND Disegno='" + dis + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    this.Sottofamiglia.Text = (string)dt.Rows[0]["Settore"];
                    this.Struttura.Text = (string)dt.Rows[0]["Struttura"];
                    this.Diametro.Text = (string)dt.Rows[0]["Diametro"];
                    this.Tavola.Text = (string)dt.Rows[0]["Tavola"];
                    this.Lunghezza.Text = (string)dt.Rows[0]["Lunghezza"];
                    this.Diametro.Text = "";
                    if (Information.IsNumeric(dt.Rows[0]["DiametroInterno"]))
                    {
                        if (Convert.ToDouble(dt.Rows[0]["DiametroInterno"]) > 0)
                            this.DiamInterno.Text = (string)dt.Rows[0]["DiametroInterno"];
                    }
                    if (!Information.IsDBNull(dt.Rows[0]["Costruttore"]))
                        this.Costruttore.Text = (string)dt.Rows[0]["Costruttore"];
                    if (this.Sottofamiglia.Text == "RE")
                        this.PesoW.Text = (string)dt.Rows[0]["TavolaIncisa"];
                    else
                        this.TavolaIncisa.Text = (string)dt.Rows[0]["TavolaIncisa"];
                    CaricaCostruzione((string)dt.Rows[0]["Settore"], dis);
                }
                CompilaArticolo("No");
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void CompilaArticolo(string verConstr = "OK")
        {
            string art = "";
            art = this.Famiglia.SelectedValue + this.Sottofamiglia.Text + this.Struttura.Text + this.Fornitura.SelectedValue;
            if (this.Costruzione.SelectedValue != "")
                art = art + this.Costruzione.SelectedValue;
            else if (verConstr == "OK")
            {
                ClientScript.RegisterStartupScript(GetType(), "errore", "<script LANGUAGE='JavaScript' >alert('COMPULSORY FIELDS: CONSTRUCTION');</script>");
                return;
            }
            art = art + Disegno.SelectedValue;
            if (Strings.Len(art) >= 13)
                this.CodArticolo.Text = art;
            else
                this.CodArticolo.Text = "";
        }
        protected void CaricaCostruzione(string sott, string dis)
        {
            try
            {
                for (var i = Costruzione.Items.Count - 1; i >= 0; i += -1)
                    Costruzione.Items[i].Remove();
                RadComboBoxItem item = new RadComboBoxItem();
                item.Value = "";
                item.Text = "----";
                Costruzione.Items.Add(item);
                string sql = "Select Distinct Costruzione FROM ListinoPDF WHERE Settore='" + sott + "' AND Disegno='" + dis + "' AND Famiglia='" + this.Famiglia.SelectedValue + "' Order By Costruzione";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.Costruzione.DataSource = dt;
                this.Costruzione.DataTextField = "Costruzione";
                this.Costruzione.DataValueField = "Costruzione";
                this.Costruzione.DataBind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }




        private void ElencoOfferte_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
            {
                FunzioniCRM p = new FunzioniCRM();
                string nome = p.GetNomeCompleto(User.Identity.Name);
                string sql = "SELECT * FROM [VisiteCliente]  WHERE Manager='" + nome + "' ORDER BY [Data_Visita] DESC";
                sql = "SELECT [Numero_Offerta], [Numero_Revisione], [Data_Offeerta], [Data_Revisione], [Codice_Cliente], [RagSoc],Nazione, [Validita], [Stato], [Codice_Agente], [Prezzo_Vendita],Prezzo_Totale, [Note], [Ut_Mod], [Valuta], [Manager],DescrizioneStatoEn,Codice_Parlante As Articolo,Rag_Sociale_Dest as Destinazione, Note_Arrivo, Data_Arrivo_Presunta,MotivoNonAccettata,Trasporto_Risposta FROM [vw_OfferteT] WHERE Mod_Calcolo = 'PDF' AND Manager=@manager order by right(numero_offerta,2) desc, convert(int,left(numero_offerta,len(numero_offerta)-4)) desc, numero_revisione desc ";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("Manager", DbType.String, nome));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.ElencoOfferte.DataSourceID = null;
                this.ElencoOfferte.DataSource = dt;
                this.ElencoOfferte.MasterTableView.GetColumn("EliminaOfferta").Visible = false;
            }
        }
        private void ElencoOfferte_UpdateCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                GridEditableItem editedItem = e.Item as GridEditableItem;
                Telerik.Web.UI.GridDataItem item = e.Item.OwnerTableView.Items[0];

                if ((e.Item.OwnerTableView.Name == "RigheOfferte"))
                {
                    // aggiorna lostato della singola riga
                    string numoff = item["Numero_Offerta"].Text;
                    string numrev = item["Numero_Revisione"].Text;
                    string numriga = System.Convert.ToString(item["Numero_Riga"].Text);
                    string note = item["Note_Arrivo"].Text;
                    DropDownList statoOfferta = (DropDownList)editedItem.FindControl("ddlStato");

                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("Stato", DbType.String, statoOfferta.SelectedValue));

                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("Numero_Offerta", DbType.String, numoff));
                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("Numero_Revisione", DbType.Int16, numrev));
                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("Numero_Riga", DbType.Int16, numriga));
                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("MotivoNonAccettata", DbType.String, ""));
                    this.SqlElencoRighe.UpdateParameters.Add(new Parameter("Note_Arrivo", DbType.String, note));
                }
                else
                {
                    string numoff = editedItem.FindControl("Numero_OffertaTextBox").ToString();
                    string numrev = editedItem.FindControl("Numero_RevisioneTextBox").ToString();
                    // aggiorna lo stato dell'offerta
                    string motivo = editedItem.FindControl("MotivoNonAccettataTextBox").ToString();
                    //string motivo = (TextBox)editedItem.FindControl("MotivoNonAccettataTextBox").Text;
                    DropDownList statoOfferta = (DropDownList)editedItem.FindControl("ddlStato");
                    this.SqlElencoOfferte.UpdateParameters.Add(new Parameter("Stato", DbType.String, statoOfferta.SelectedValue));

                    string fam = item["Articolo"].Text.Left(1);
                    string sqlS = "SELECT Stato FROM OfferteT WHERE Numero_Offerta='" + numoff + "' AND Numero_Revisione=" + System.Convert.ToString(numrev);
                    SqlCommand mycmd = new SqlCommand(sqlS, ConnSDB);
                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(mycmd);
                    da.Fill(dt);
                    string Stato = (string)dt.Rows[0]["Stato"];
                    string nuovoStato = statoOfferta.SelectedValue;
                    if (Information.IsNumeric(Stato))
                    {
                        if (System.Convert.ToInt32(Stato) == 9)
                        {
                            if (nuovoStato == "3")
                            {
                                if (motivo == "")
                                {
                                    ClientScript.RegisterStartupScript(GetType(), "errore", "<script LANGUAGE='JavaScript' >alert('Specificare una motivazione per offerta Non Accettata');</script>");
                                    e.Canceled = true;
                                }
                                this.SqlElencoRighe.UpdateParameters.Add(new Parameter("MotivoNonAccettata", DbType.String, motivo));
                            }
                            else
                            {
                                ClientScript.RegisterStartupScript(GetType(), "errore", "<script LANGUAGE='JavaScript' >alert('Offerta scaduta: non modificabile');</script>");
                                e.Canceled = true;
                            }
                        }
                        else if (Convert.ToInt32(Stato) == 1 | Convert.ToInt32(Stato) == 7)
                        {
                            if (Convert.ToInt16(nuovoStato) == 2)
                            {
                                string msg = ImpegnaSleeve(numoff, numrev);
                                ClientScript.RegisterStartupScript(GetType(), "errore", "<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>");
                            }
                        }
                    }
                    else if (Convert.ToInt16(statoOfferta.SelectedValue) == 3)
                    {
                        if (motivo == "")
                        {
                            ClientScript.RegisterStartupScript(GetType(), "errore", "<script LANGUAGE='JavaScript' >alert('Specificare una motivazione per offerta Non Accettata');</script>");
                            e.Canceled = true;
                        }
                        this.SqlElencoRighe.UpdateParameters.Add(new Parameter("MotivoNonAccettata", DbType.String, motivo));
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private void ElencoOfferte_ItemDeleted(object sender, GridDeletedEventArgs e)
        {
            try
            {
                GridEditableItem editedItem = e.Item as GridEditableItem;

                string sql = "DELETE FROM Offerte_righe Where numero_offerta=@numoff and numero_revisione=@numrev";
                SqlCommand mycmd = new SqlCommand(sql, ConnSDB);

                // numero offerta
                SqlParameter sqlpar = new SqlParameter();
                sqlpar.ParameterName = "@numoff";
                sqlpar.DbType = DbType.String;
                sqlpar.Value = ElencoOfferte.SelectedItems[0].Cells[4].FindControl("Numero_OffertaLabel").ToString();
                //sqlpar.Value = (Label)ElencoOfferte.SelectedItems[0].Cells[4].FindControl("Numero_OffertaLabel").Text;
                mycmd.Parameters.Add(sqlpar);
                // numero revisione
                SqlParameter sqlpar1 = new SqlParameter();
                sqlpar1.ParameterName = "@numrev";
                sqlpar1.DbType = DbType.String;
                sqlpar1.Value = ElencoOfferte.SelectedItems[0].Cells[4].FindControl("Numero_RevisioneLabel").ToString();
                //sqlpar1.Value = (Label)ElencoOfferte.SelectedItems[0].Cells[4].FindControl("Numero_RevisioneLabel").Text;
                mycmd.Parameters.Add(sqlpar1);
                ConnSDB.Open();
                mycmd.ExecuteNonQuery();
                ConnSDB.Close();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected string ImpegnaSleeve(string numoff, string numrev, string numriga = "")
        {
            string msg = "";
            try
            {
                // verifica se si tratta di sleeve e calcola il numero di totale di sleeve da impegnare
                string sql = "SELECT Codice_Sottofamiglia,Disegno,Sum(Quantita) as qta,Stato FROM Offerte_Righe WHERE Numero_Offerta='" + numoff + "' AND Numero_Revisione=" + System.Convert.ToString(numrev) + " AND Codice_Fornitura='A'";
                if (Information.IsNumeric(numriga))
                    sql = sql + " AND Numero_Riga=" + System.Convert.ToString(numriga);
                sql = sql + " GROUP BY Codice_Sottofamiglia,Disegno,Stato";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["Codice_Sottofamiglia"].ToString().Trim() == "SL")
                    {
                        int qtaImp = (int)dt.Rows[0]["qta"];
                        if (qtaImp <= 12)
                        {

                            // cerca il disegno nel magazzino disegni costruiti 001 ed estrae la quantità disponibile (quantita - impegnato)
                            if (!Convert.IsDBNull(dt.Rows[0]["Disegno"]))
                            {
                                string disegno = (string)dt.Rows[0]["Disegno"];
                                sql = "Select Quantita,Qta_Impegnata,Cod_Magazzino FROM MG_DISEGNI WHERE Disegno='" + disegno + "' AND (Cod_Magazzino='001' OR Cod_Magazzino='002') AND Costruzione='_'";
                                cmd = new SqlCommand(sql, ConnSDB);
                                da = new SqlDataAdapter(cmd);
                                dt = new DataTable();
                                da.Fill(dt);
                                if (dt.Rows.Count > 0)
                                {
                                    int sleeveMaga = 0;
                                    int sleeveMaga1 = 0;
                                    int sleeveMaga2 = 0;
                                    for (var i = 0; i <= dt.Rows.Count - 1; i++)
                                    {
                                        sleeveMaga = sleeveMaga + (int)dt.Rows[i]["Quantita"] - (int)dt.Rows[i]["Qta_Impegnata"];
                                        if ((string)dt.Rows[i]["Cod_Magazzino"] == "001")
                                            sleeveMaga1 = (int)dt.Rows[i]["Quantita"] - (int)dt.Rows[i]["Qta_Impegnata"];
                                        else
                                            sleeveMaga2 = (int)dt.Rows[i]["Quantita"] - (int)dt.Rows[i]["Qta_Impegnata"];
                                    }
                                    string destinazione = numoff + " " + numrev;
                                    if (sleeveMaga >= qtaImp)
                                    {
                                        // se la quantita disponibile è >= al n° totale di sleeve da impegnare allora aggiunge tale numero alla colonna Impegnati della tabella MG_DIsegni
                                        if (sleeveMaga1 > qtaImp)
                                        {
                                            // impegna tutte le sleeve dal magazzino 001
                                            sql = "UPDATE MG_Disegni SET Qta_Impegnata=Qta_Impegnata+" + qtaImp + "WHERE Costruzione='_' AND Disegno='" + disegno + "' AND Cod_Magazzino='001'";
                                            cmd = new SqlCommand(sql, ConnSDB);
                                            try
                                            {
                                                ConnSDB.Open();
                                                cmd.ExecuteNonQuery();
                                                ConnSDB.Close();
                                                RegistraImpegnoSleeve(qtaImp, disegno, "001", "IMPEGNO", destinazione);
                                                AggiornaImpegnoOffertaSleeve(numoff, numrev, numriga);
                                                msg = "Quantità Impegnata correttamente per 30 giorni.";
                                            }
                                            catch (Exception ex)
                                            {
                                                string erroreImpegno001 = ex.Message;
                                                return msg = "Errore impegno magazzino 001";
                                            }
                                        }
                                        else
                                        {
                                            // impegna la quantità sleeveMaga1 dal magazzino 001
                                            sql = "UPDATE MG_Disegni SET Qta_Impegnata=Qta_Impegnata+" + sleeveMaga1 + "WHERE Costruzione='_' AND Disegno='" + disegno + "' AND Cod_Magazzino='001'";
                                            cmd = new SqlCommand(sql, ConnSDB);
                                            if (sleeveMaga1 > 0)
                                            {
                                                try
                                                {
                                                    ConnSDB.Open();
                                                    cmd.ExecuteNonQuery();
                                                    ConnSDB.Close();
                                                    RegistraImpegnoSleeve(sleeveMaga1, disegno, "001", "IMPEGNO", destinazione);
                                                }
                                                catch (Exception ex)
                                                {
                                                    string erroreImpegno001 = ex.Message;
                                                    return msg = "Errore impegno magazzino 001";
                                                }
                                            }
                                            // impegna la quantità qtaImp-sleeveMaga1 dal magazzino 002
                                            if (qtaImp - sleeveMaga1 >= 0)
                                            {
                                                sql = "UPDATE MG_Disegni SET Qta_Impegnata=Qta_Impegnata+" + (qtaImp - sleeveMaga1) + "WHERE Costruzione='_' AND Disegno='" + disegno + "' AND Cod_Magazzino='002'";
                                                cmd = new SqlCommand(sql, ConnSDB);
                                                try
                                                {
                                                    ConnSDB.Open();
                                                    cmd.ExecuteNonQuery();
                                                    ConnSDB.Close();
                                                    RegistraImpegnoSleeve((qtaImp - sleeveMaga1), disegno, "002", "IMPEGNO", destinazione);
                                                }
                                                catch (Exception ex)
                                                {
                                                    string erroreImpegno002 = ex.Message;
                                                    return msg = "Errore impegno magazzino 002";
                                                }
                                                AggiornaImpegnoOffertaSleeve(numoff, numrev, numriga);
                                                msg = "Quantità Impegnata correttamente per 30 giorni.";
                                            }
                                        }
                                    }
                                    else
                                        msg = "Quantità a magazzino non sufficente a coprire l'impegno.";
                                }
                                else
                                    msg = "Quantità a magazzino non sufficente a coprire l'impegno.";
                            }
                        }
                        else
                            msg = "Quantità massima impegnabile pari a 12!";
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return msg;
        }
        protected void RegistraImpegnoSleeve(int qtaImp, string disegno, string magazzino, string operazione, string Destinazione)
        {
            try
            {
                string sql = "INSERT INTO MG_DisegniR (Cod_Magazzino,Operazione,Disegno,Costruzione,Destinazione,Quantita,Data_Mod,Ut_Mod) ";
                sql = sql + " VALUES('" + magazzino + "','" + operazione + "','" + disegno + "','_','" + Destinazione + "'," + qtaImp + ", GetDate(),'" + User.Identity.Name + "')";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                try
                {
                    ConnSDB.Open();
                    cmd.ExecuteNonQuery();
                    ConnSDB.Close();
                }
                catch (Exception ex)
                {
                    string erroreINs = ex.Message;
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void AggiornaImpegnoOffertaSleeve(string numoff, string numrev, string numriga = "")
        {
            try
            {
                string sql = "SELECT * FROM Offerte_Righe WHERE Numero_Offerta='" + numoff + "' AND Numero_Revisione=" + System.Convert.ToString(numrev);
                if (Information.IsNumeric(numriga))
                    sql = sql + " AND Numero_Riga=" + System.Convert.ToString(numriga);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    sql = "UPDATE Offerte_Righe SET Qta_impegnataMag=" + System.Convert.ToString(dt.Rows[i]["Quantita"]) + ",Data_ImpegnoQtaMag=GetDate()";
                    sql = sql + " WHERE Numero_Offerta='" + numoff + "' AND Numero_Revisione=" + System.Convert.ToString(numrev) + " AND Numero_Riga=" + System.Convert.ToString(dt.Rows[i]["Numero_Riga"]);
                    cmd = new SqlCommand(sql, ConnSDB);
                    try
                    {
                        ConnSDB.Open();
                        cmd.ExecuteNonQuery();
                        ConnSDB.Close();
                    }
                    catch (Exception ex)
                    {
                        string erroreINs = ex.Message;
                        ConnSDB.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }

        protected void Invia_ServerClick(object sender, EventArgs e)
        {
            try
            {
                this.PanelButton.Visible = false;
                this.PanelR.Visible = false;
                // crea elenco contatti per il cliente e destinazione selezionata
                CaricaContatti(System.Convert.ToInt32(this.IdClient.Text), this.IdSede.Text);
                // stampa pdf e la allega
                string msg = CreaPDFAllegato(this.Disegno.SelectedValue, this.Famiglia.SelectedValue, this.Sottofamiglia.Text, this.Costruzione.SelectedValue, this.Fornitura.SelectedValue);
                if (msg == "")
                {
                    this.Allegato.Text = this.Num_Offe.Text.Replace("/","-") + ".pdf";
                    this.myAllegato.NavigateUrl = "~/Doc/OffertePDF" + "/" + this.Num_Offe.Text.Replace("/", "-") + ".pdf";
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                this.PanelButton.Visible = true;
                this.PanelR.Visible = true;
            }
        }
        protected void CaricaContatti(int idcli, string idsede = "")
        {
            try
            {
                // verifica se la sede è collegata ad un altro ID
                string sql1 = "SELECT CollegatoAID FROM OFF_DestinazioniClienti WHERE Idcliente = " + Convert.ToInt32(this.IdClient.Text) + " AND Id=" + Convert.ToInt32(this.IdSede.Text);
                SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                Int32 IdColl = 0;
                if (dt1.Rows.Count > 0)
                {
                    if (Information.IsNumeric(dt1.Rows[0]["CollegatoAId"]))
                        IdColl = Convert.ToInt32(dt1.Rows[0]["CollegatoAId"]);
                }

                string sql = "SELECT * FROM vw_OFF_ContattiSedi WHERE Idcliente=" + idcli;
                if (Information.IsNumeric(idsede))
                    sql = sql + " And (IdSede=" + idsede;
                if (IdColl > 0)
                    sql += " OR IdSede=" + IdColl;

                sql += ") ORDER BY [Nominativo]";

                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string x = "";
                EliminaElenco();
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    // responsabile interno Cliente
                    x = "";
                    if (!Information.IsDBNull(dt.Rows[i]["Localita"]))
                        x = dt.Rows[i]["Localita"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Indirizzo"]))
                        x = x + " " + dt.Rows[i]["Indirizzo"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Nominativo"]))
                        x = x + dt.Rows[i]["Nominativo"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Email"]))
                        x = x + dt.Rows[i]["Email"];
                    this.chl.Items.Add(x);
                    this.chkContatti.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void EliminaElenco()
        {
            this.chl.Items.Clear();
            this.chkContatti.Items.Clear();
        }
        private string CreaPDFAllegato(string dis, string fam, string sett, string costr, string forn)
        {
            string msg = "";
            if (!Information.IsNumeric(this.IdClient.Text))
                return msg;
            try
            {
                bool personalGPL = GetPersonalGPL(Convert.ToInt16(this.IdClient.Text));
                string status = "";
                string sql1 = "SELECT * FROM ListinoPDF WHERE Disegno='" + dis + "' AND Famiglia='" + fam + "'";
                SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                string lg = this.Lingua.SelectedValue;
                double maggior = 0;

                da1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    sett = dt1.Rows[0]["Settore"].ToString().Trim();

                    if (fam == "D" & sett == "LA")
                    {
                        sql1 += " AND TipoRipristinoIT='" + TipoRipristino.SelectedValue + "'";
                        cmd1 = new SqlCommand(sql1, ConnSDB);
                        da1 = new SqlDataAdapter(cmd1);
                        dt1 = new DataTable();
                        da1.Fill(dt1);
                        if (dt1.Rows.Count > 0)
                            status = "OK";
                    }
                    else
                        status = "OK";
                }
                if (this.Disegno.SelectedValue == "NODWG")
                    status = "OK";

                if (status == "OK")
                {
                    string sett1 = sett;
                    if (sett == "EA")
                        sett1 = "SL";
                    else if (sett1 == "LA")
                        sett1 = "NOR";

                    string pathin = Server.MapPath(@"..\Doc") + @"\Offerta_" + fam + "_" + sett1 + "_" + lg + ".pdf";
                    if (Disegno.SelectedValue == "NODWG")
                        pathin = Server.MapPath(@"..\Doc") + @"\Offerta_" + fam + "_" + sett1 + "_NODWG_" + lg + ".pdf";
                    string pathout = Server.MapPath(@"..\Doc\OffertePDF") + @"\" + this.Num_Offe.Text.Replace("/", "-") + ".pdf";
                    iTextSharp.text.Font Carattere = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font CarattereBold = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.BOLD);
                    iTextSharp.text.Font Carattere8 = iTextSharp.text.FontFactory.GetFont("Montserrat", 8, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere10Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.BOLD);
                    iTextSharp.text.Font Carattere7 = iTextSharp.text.FontFactory.GetFont("Montserrat", 7, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere2 = iTextSharp.text.FontFactory.GetFont("Montserrat", 11, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font CarattereBoldRed = iTextSharp.text.FontFactory.GetFont("Montserrat", 16, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
                    iTextSharp.text.Font CarattereRed12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite14Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 14, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite16Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 16, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite12Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite9 = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite8 = iTextSharp.text.FontFactory.GetFont("Montserrat", 8, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite8Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 8, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite9Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    PdfReader reader = new PdfReader(pathin);
                    using ((reader))
                    {
                        string testo = "";
                        FileStream myStream = new FileStream(pathout, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);

                        PdfStamper stamper = new PdfStamper(reader, myStream);
                        using ((stamper))
                        {
                            reader.SelectPages("1");
                            var pageSize = reader.GetPageSize(1);
                            // recupera eventuale maggiorazione da GPL già inviato a questo cliente per questo disegno

                            string sqlM = "SELECT * FROM OFF_GLPInviati WHERE Disegno='" + dis + "' AND IdCliente=" + System.Convert.ToString(this.IdClient.Text);
                            SqlCommand cmdM = new SqlCommand(sqlM, ConnSDB);
                            SqlDataAdapter daM = new SqlDataAdapter(cmdM);
                            DataTable dtM = new DataTable();
                            daM.Fill(dtM);
                            if (dtM.Rows.Count > 0)
                            {
                                if (Information.IsNumeric(dtM.Rows[0]["Maggiorazione"]))
                                    maggior = (double)dtM.Rows[0]["Maggiorazione"];
                            }

                            double prezzo = 0;
                            PdfContentByte pbover = stamper.GetOverContent(1);
                            if (sett == "RE" | sett == "NA")
                            {
                                if (sett == "NA")
                                    sett = "RE";
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(dis, CarattereWhite16Bold), 41, 550, 0);
                                testo = this.Num_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 710, 722, 0);
                                testo = this.Cliente.Text.ToString().Trim();
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 680, 699, 0);
                                testo = this.Data_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 790, 722, 0);
                            }
                            else if (sett == "CO" | sett == "TI")
                            {
                                if (sett == "TI")
                                    sett = "CO";
                                testo = dis;
                                if (this.Disegno.SelectedValue == "NODWG")
                                {
                                    testo = this.Num_Offe.Text;
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 730, 722, 0);
                                    testo = this.Cliente.Text.Trim();
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 692, 697, 0);
                                    testo = this.Data_Offe.Text;
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 800, 722, 0);
                                }
                                else
                                {
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite16Bold), 66, 550, 0);
                                    testo = this.Num_Offe.Text;
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 720, 721, 0);
                                    testo = this.Cliente.Text.Trim();
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 685, 699, 0);
                                    testo = this.Data_Offe.Text;
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 790, 722, 0);
                                }
                            }
                            else if (sett == "SL")
                            {
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(dis, CarattereWhite16Bold), 66, 550, 0);
                                testo = this.Num_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 720, 721, 0);
                                testo = this.Cliente.Text.Trim();
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 685, 699, 0);
                                testo = this.Data_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 790, 722, 0);
                            }
                            else if (sett == "LA")
                            {
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(dis, CarattereWhite16Bold), 80, 438, 0);
                                testo = this.Num_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 685, 714, 0);
                                testo = this.Cliente.Text.Trim();
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 655, 687, 0);
                                testo = this.Data_Offe.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, CarattereWhite10), 833, 714, 0);
                            }

                            if (sett != "RE" & (sett == "CO" & Disegno.SelectedValue == "NODWG") & sett != "SL")
                            {
                                Chunk fr = new Chunk(testo, Carattere);
                                MyKey fx = new MyKey();
                                string rndLink = "11" + sett + fx.NewKey() + lg;
                                string LinkFile = "Supply specs_" + sett + "_" + lg + ".pdf";

                                testo = "DIAMETER RE-BUILDING";
                                if (lg == "IT")
                                    testo = "RIPRISTINO DIAMETRO";
                                fr = new Chunk(testo, Carattere8);
                                rndLink = "12" + sett + fx.NewKey() + lg;
                                LinkFile = "DIAMETER REBUILDING_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 862, 507, 0);

                                testo = "ADDITIONAL EXPENSES";
                                if (lg == "IT")
                                    testo = "SPESE AGGIUNTIVE";
                                fr = new Chunk(testo, Carattere8);
                                rndLink = "13" + sett + fx.NewKey() + lg;
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);

                                LinkFile = "OTHER ADDITIONAL EXPENSES_" + sett + "_" + lg + ".pdf";
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 862, 479, 0);

                                testo = "CERTIFICATION";
                                if (lg == "IT")
                                    testo = "CERTIFICAZIONE";
                                fr = new Chunk(testo, Carattere8);
                                rndLink = "14" + sett + fx.NewKey() + lg;
                                LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 862, 450, 0);

                                testo = "SALES CONDITIONS";
                                if (lg == "IT")
                                    testo = "CONDIZIONI COMMERCIALI";
                                fr = new Chunk(testo, Carattere8);
                                rndLink = "19" + sett + fx.NewKey() + lg;
                                LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 862, 422, 0);
                            }

                            testo = "";
                            if (Information.IsNumeric(this.Diametro.Text))
                            {
                                testo = this.Diametro.Text;
                                if (System.Convert.ToDouble(testo) - System.Convert.ToDouble(testo) == 0)
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n0");
                                else
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n3");
                            }
                            testo = testo;
                            if (sett == "RE")
                            {
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 207, 521, 0);
                                testo = costr;

                                string sql = "SELECT [Codice],[Descrizione],[DescrizioneEN],[Famiglia],[SottoFamiglia] FROM [SDB_SIM].[dbo].[Tecnologia_Incisione] WHERE Codice='" + Strings.Trim(costr) + "'";
                                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                                SqlDataAdapter da = new SqlDataAdapter(cmd);
                                DataTable dt = new DataTable();
                                da.Fill(dt);
                                if (dt.Rows.Count > 0)
                                {
                                    if (lg == "IT")
                                    {
                                        testo = (string)dt.Rows[0]["Descrizione"];
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo.ToUpper(), Carattere10Bold), 452, 472, 0);
                                    }
                                    else
                                    {
                                        testo = (string)dt.Rows[0]["DescrizioneEN"];
                                        if (testo == "Steel tube and stainless steel journals")
                                        {
                                            testo = "Steel tube and stainless";
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere10Bold), 352, 478, 0);
                                            testo = "steel journals";
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere10Bold), 352, 466, 0);
                                        }
                                        else
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo.ToUpper(), Carattere10Bold), 452, 472, 0);
                                    }
                                }
                            }
                            else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 519, 0);
                            else if (sett == "SL")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 519, 0);
                            else if (sett == "LA")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 270, 472, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 160, 508, 0);


                            testo = "";
                            if (sett == "SL")
                            {
                                if (Information.IsNumeric(this.DiamInterno.Text))
                                {
                                    testo = this.DiamInterno.Text;
                                    if (System.Convert.ToDouble(testo) - System.Convert.ToDouble(testo) == 0)
                                        testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n0");
                                    else
                                        testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n3");
                                }
                            }
                            else if (Information.IsNumeric(this.Tavola.Text))
                            {
                                testo = this.Tavola.Text;
                                if (System.Convert.ToDouble(testo) - System.Convert.ToDouble(testo) == 0)
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n0");
                                else
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n3");
                            }
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 207, 495, 0);
                            else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 495, 0);
                            else if (sett == "SL")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 494, 0);
                            else if (sett == "LA")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 270, 451, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 160, 476, 0);
                            testo = "";
                            if (Information.IsNumeric(this.Lunghezza.Text))
                            {
                                testo = this.Lunghezza.Text;
                                if (System.Convert.ToDouble(testo) - System.Convert.ToDouble(testo) == 0)
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n0");
                                else
                                    testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n3");
                            }
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 207, 470, 0);
                            else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 444, 0);
                            else if (sett == "SL")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 444, 0);
                            else if (sett == "LA")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 270, 414, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 160, 459, 0);
                            testo = "";
                            if (Information.IsNumeric(this.TavolaIncisa.Text))
                            {
                                if (System.Convert.ToInt32(this.TavolaIncisa.Text) > 0)
                                {
                                    testo = this.TavolaIncisa.Text;
                                    if (System.Convert.ToDouble(testo) - System.Convert.ToDouble(testo) == 0)
                                        testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n0");
                                    else
                                        testo = Strings.Format(Convert.ToDouble(testo).ToString(), "n3");
                                }
                            }
                            if (sett == "RE")
                            {
                                testo = PesoW.Text;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 207, 444, 0);
                            }
                            else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 470, 0);
                            else if (sett == "SL")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 255, 469, 0);
                            else if (sett == "LA")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 270, 433, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere10), 160, 445, 0);

                            testo = this.Fornitura.SelectedItem.Text;
                            if (lg == "IT")
                            {
                                if (testo == "Refurbishment")
                                    testo = "Conto Lavoro";
                                else
                                    testo = "Fornitura Completa";
                            }

                            string testo1, testo2, testo3;
                            if (sett == "RE")
                            {
                                if (testo == "Refurbishment" | testo == "Conto Lavoro")
                                {
                                    testo1 = "Admittance inspection, old ceramic coating removal, 250° thermal treatment, pre-grinding, anti-corrosion coating,";
                                    testo2 = "ceramic coating, roller face grinding, lapping, laser engraving as per established specs,";
                                    testo3 = "engraving running-in, dimensional inspection certificate.";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Controllo in entrata, rimozione strato ceramico, trattamento termico di bonifica a 250°, pre-rettifica,";
                                        testo2 = "riporto anticorrosivo, riporto ceramico, rettifica tavola, lucidatura  pre-incisione, incisione laser";
                                        testo3 = "secondo specifiche richieste, pre-rodaggio incisione, certificato collaudo dimensionale.";
                                    }
                                }
                                else
                                {
                                    testo1 = "Manufacture according to the OEM’s drawing,  stress relief thermal treatment,  pre-grinding, anti-corrosion";
                                    testo2 = "and ceramic coating, grinding, lapping, laser engraving as required, engraving running-in, journals finishing,";
                                    testo3 = "dimensional inspection certificate, wooden box.";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Costruzione a disegno, trattamento termico di distensione, pre-rettifica, riporto anticorrosivo, riporto ceramico";
                                        testo2 = "rettifica tavola, lucidatura pre-incisione, incisione laser secondo richieste, pre-rodaggio incisione,";
                                        testo3 = "finitura mozzi, certificato collaudo dimensionale standard e cassa in legno.";
                                    }
                                }
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere8), 492, 509, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere8), 492, 499, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere8), 492, 489, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite12Bold), 547, 557, 0);
                            }
                            else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                            {
                                if (testo == "Refurbishment" | testo == "Conto Lavoro")
                                {
                                    testo1 = "Admittance inspection, old ceramic coating removal, 250° thermal treatment, pre-grinding, anti-corrosion coating, ceramic coating, roller";
                                    testo2 = "face grinding, lapping, laser engraving as per established specs, engraving running-in, dimensional inspection certificate.";
                                    testo3 = "";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Controllo in entrata, rimozione strato ceramico, trattamento termico di bonifica a 250°, pre-rettifica, riporto anticorrosivo e ceramico, rettifica";
                                        testo2 = " tavola, lucidatura  pre-incisione, incisione laser secondo specifiche richieste, pre-rodaggio incisione, certificato collaudo dimensionale.";
                                        testo3 = "";
                                    }
                                }
                                else
                                {
                                    testo1 = "Manufacture according to the OEM’s drawing,  stress relief thermal treatment,  pre-grinding, anti-corrosion and ceramic coating, grinding,";
                                    testo2 = "lapping, laser engraving as required, engraving running-in, journals finishing, dimensional inspection certificate, wooden box.";
                                    testo3 = "";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Costruzione a disegno, trattamento termico di distensione, pre-rettifica, riporto anticorrosivo e ceramico, rettifica tavola, lucidatura pre-incisione,";
                                        testo2 = "incisione laser secondo richieste, pre-rodaggio incisione, finitura mozzi, certificato collaudo dimensionale standard e cassa in legno.";
                                        testo3 = "";
                                    }
                                }
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere10), 322, 503, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere10), 322, 491, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere10), 322, 491, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite12Bold), 377, 557, 0);
                            }
                            else if (sett == "SL")
                            {
                                if (testo == "Refurbishment" | testo == "Conto Lavoro")
                                {
                                    testo1 = "Admittance inspection, old ceramic coating removal, 250° thermal treatment, pre-grinding, anti-corrosion coating,";
                                    testo2 = "ceramic coating, roller face grinding, lapping, laser engraving as per established specs,";
                                    testo3 = "engraving running-in, dimensional inspection certificate.";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Controllo in entrata, rimozione strato ceramico, trattamento termico di bonifica a 250°, pre-rettifica,";
                                        testo2 = "riporto anticorrosivo, riporto ceramico, rettifica tavola, lucidatura  pre-incisione, incisione laser";
                                        testo3 = "secondo specifiche richieste, pre-rodaggio incisione, certificato collaudo dimensionale.";
                                    }
                                }
                                else
                                {
                                    testo1 = "Manufacture according to the OEM’s drawing,  stress relief thermal treatment,  pre-grinding, anti-corrosion";
                                    testo2 = "and ceramic coating, grinding, lapping, laser engraving as required, engraving running-in, journals finishing,";
                                    testo3 = "dimensional inspection certificate, wooden box.";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Costruzione a disegno, trattamento termico di distensione, pre-rettifica, riporto anticorrosivo, riporto ceramico";
                                        testo2 = "rettifica tavola, lucidatura pre-incisione, incisione laser secondo richieste, pre-rodaggio incisione,";
                                        testo3 = "finitura mozzi, certificato collaudo dimensionale standard e cassa in legno.";
                                    }
                                }
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere8), 322, 507, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere8), 322, 498, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere8), 322, 489, 0);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite12Bold), 377, 557, 0);
                            }
                            else if (sett == "LA")
                            {
                                testo = this.TipoRipristino.SelectedItem.Text;
                                if (lg == "IT")
                                    testo = this.TipoRipristino.SelectedValue;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere8), 473, 470, 0);
                            }

                            sql1 = "SELECT * FROM Offerte_Righe WHERE Numero_Offerta='" + this.Num_Offe.Text + "' AND Numero_Revisione=1";
                            cmd1 = new SqlCommand(sql1, ConnSDB);
                            da1 = new SqlDataAdapter(cmd1);
                            DataTable dt1x = new DataTable();
                            da1.Fill(dt1x);
                            if (dt1x.Rows.Count > 0)
                            {
                                if (System.Convert.ToDouble(dt1x.Rows[0]["Sconto"]) > 0)
                                    maggior = System.Convert.ToDouble(dt1x.Rows[0]["Sconto"]);
                            }

                            if (this.Disegno.SelectedValue == "NODWG")
                            {
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere10Bold), 260, 493, 0);
                                if (testo == "Refurbishment" | testo == "Conto Lavoro")
                                {
                                    testo1 = "Admittance inspection, old ceramic coating removal, 250° thermal treatment, pre-grinding,";
                                    testo2 = "anti-corrosion coating, ceramic coating, roller face grinding, lapping, laser engraving ";
                                    testo3 = "as per established specs, engraving running-in, dimensional inspection certificate.";

                                    if (lg == "IT")
                                    {
                                        testo1 = "Controllo in entrata, rimozione strato ceramico, trattamento termico di bonifica a 250°, pre-rettifica,";
                                        testo2 = "riporto anticorrosivo, riporto ceramico, rettifica tavola, lucidatura  pre-incisione, incisione laser";
                                        testo3 = "secondo specifiche richieste, pre-rodaggio incisione, certificato collaudo dimensionale.";
                                    }
                                }
                                else
                                {
                                    testo1 = "Manufacture according to the OEM’s drawing, stress relief thermal treatment, pre-grinding, ";
                                    testo2 = "anti-corrosion and ceramic coating, roller face grinding, lapping, laser engraving as requested,";
                                    testo3 = "engraving running-in, journals finishing, dimensional inspection certificate, wooden box.";


                                    if (lg == "IT")
                                    {
                                        testo1 = "Costruzione a disegno, trattamento termico di distensione, pre-rettifica, riporto anticorrosivo,";
                                        testo2 = "riporto ceramico, rettifica tavola, lucidatura pre-incisione, incisione laser secondo richieste,";
                                        testo3 = "pre-rodaggio incisione, finitura mozzi, certificato collaudo dimensionale standard e cassa in legno.";
                                    }
                                }

                                if (Strings.Len(testo1 + testo2 + testo3) > 110)
                                {
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere10), 321, 505, 0);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere10), 321, 493, 0);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere10), 321, 481, 0);
                                }
                                testo = this.NoteCliente.Text;
                                if (Strings.Len(testo) > 85)
                                {
                                    testo1 = Strings.Left(testo, 85);
                                    testo2 = Strings.Trim(Strings.Right(testo, Strings.Len(testo) - 85));
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere), 321, 455, 0);
                                    if (Strings.Len(testo2) > 85)
                                    {
                                        testo3 = Strings.Trim(Strings.Left(testo2, 85));
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 321, 440, 0);
                                        testo3 = Strings.Trim(Strings.Left(Strings.Right(testo2, Strings.Len(testo2) - 85), 85));
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 321, 425, 0);
                                    }
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere), 321, 440, 0);
                                }
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere10), 321, 455, 0);
                            }
                            else
                            {
                                testo = this.NoteCliente.Text;
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere10), 492, 465, 0);
                                else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere10), 340, 445, 0);
                                else if (sett == "LA")
                                {
                                    if (Strings.Len(testo) > 120)
                                    {
                                        testo1 = Strings.Left(testo, 120);
                                        testo2 = Strings.Right(testo, Strings.Len(testo) - 120);
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere), 390, 442, 0);
                                        if (Strings.Len(testo2) > 120)
                                        {
                                            testo3 = Strings.Right(testo2, Strings.Len(testo2) - 120);
                                            testo2 = Strings.Left(testo2, 120);

                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere), 390, 435, 0);
                                            if (Strings.Len(testo3) > 120)
                                            {
                                                testo3 = Strings.Left(testo3, 120);
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 390, 428, 0);
                                            }
                                            else
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 390, 428, 0);
                                        }
                                        else
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere), 390, 428, 0);
                                    }
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 390, 442, 0);
                                }
                                else if (Strings.Len(testo) > 85)
                                {
                                    testo1 = Strings.Left(testo, 85);
                                    testo2 = Strings.Right(testo, Strings.Len(testo) - 85);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo1, Carattere), 445, 460, 0);
                                    if (Strings.Len(testo2) > 85)
                                    {
                                        testo3 = Strings.Right(testo2, Strings.Len(testo2) - 85);
                                        testo2 = Strings.Left(testo2, 85);

                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere), 445, 448, 0);
                                        if (Strings.Len(testo3) > 85)
                                        {
                                            testo3 = Strings.Left(testo3, 85);
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 475, 455, 0);
                                        }
                                        else
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo3, Carattere), 475, 455, 0);
                                    }
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo2, Carattere), 475, 460, 0);
                                }
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 475, 455, 0);


                                if (sett == "RE")
                                {
                                    if (forn == "A")
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 635, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 693, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 541, 0);

                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 803, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 858, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 913, 541, 0);
                                    }
                                    else
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 635, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 693, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 541, 0);

                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 803, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 858, 541, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 913, 541, 0);
                                    }
                                }
                                else if (sett == "SL")
                                {
                                    if (forn == "A")
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 471, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 526, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 581, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 640, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 695, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 750, 540, 0);
                                    }
                                    else
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 471, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 526, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 581, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 640, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 695, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 750, 540, 0);
                                    }
                                }
                                else if (sett == "LA")
                                {
                                    // If forn = "A" Then
                                    // prezzo = dt1.Rows[0]["PrezzoFC_NE_80_160") * (1 + maggior / 100)
                                    // testo = Format(CInt(prezzo), "C0")
                                    // ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, New Phrase(testo, Carattere), 698, 468, 0)
                                    // prezzo = dt1.Rows[0]["PrezzoFC_NE_160_260") * (1 + maggior / 100)
                                    // testo = Format(CInt(prezzo), "C0")
                                    // ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, New Phrase(testo, Carattere), 803, 468, 0)
                                    // prezzo = dt1.Rows[0]["PrezzoFC_NE_260_360") * (1 + maggior / 100)
                                    // testo = Format(CInt(prezzo), "C0")
                                    // ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, New Phrase(testo, Carattere), 898, 468, 0)
                                    // Else
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 698, 468, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 803, 468, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 898, 468, 0);
                                    // End If
                                    // descrizione delle fasce di incisione

                                    testo = "";
                                    if (!Information.IsDBNull(dt1.Rows[0]["DescFascia1"]))
                                        testo = (string)dt1.Rows[0]["DescFascia1"];
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 698, 498, 0);
                                    testo = "";
                                    if (!Information.IsDBNull(dt1.Rows[0]["DescFascia2"]))
                                        testo = (string)dt1.Rows[0]["DescFascia2"];
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 803, 498, 0);
                                    testo = "";
                                    if (!Information.IsDBNull(dt1.Rows[0]["DescFascia3"]))
                                        testo = (string)dt1.Rows[0]["DescFascia3"];
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 898, 498, 0);
                                }
                                else if (forn == "A")
                                {
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_80_160"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 468, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_160_260"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 523, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_NE_260_360"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 580, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_80_160"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 640, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_160_260"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 695, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoFC_DC_260_360"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 750, 540, 0);
                                }
                                else
                                {
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 465, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 520, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 577, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_80_160"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 640, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_160_260"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 695, 540, 0);
                                    prezzo = (double)dt1.Rows[0]["PrezzoCL_DC_260_360"] * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 750, 540, 0);
                                }
                                if (sett == "CO")
                                {
                                    if (forn == "A")
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_HPC_012"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 810, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoFC_HPC_34"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 865, 540, 0);
                                        testo = "ON DEMAND";
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7), 920, 540, 0);
                                    }
                                    else
                                    {
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_HPC_012"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 810, 540, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_HPC_34"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 865, 540, 0);
                                        testo = "ON DEMAND";
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7), 920, 540, 0);
                                    }
                                }
                            }
                            // stampa righe offerta

                            int j = dt1x.Rows.Count - 1;
                            double totOff = 0;
                            double totVen = 0;
                            double totSco = 0;


                            if (sett == "RE")
                            {
                                Chunk fr = new Chunk(testo, Carattere);
                                MyKey fx = new MyKey();
                                string rndLink, LinkFile;
                                testo = "CERTIFICATION";
                                if (lg == "IT")
                                    testo = "CERTIFICAZIONE";
                                fr = new Chunk(testo, CarattereWhite14Bold);
                                rndLink = "19" + sett + fx.NewKey() + lg;
                                LinkFile = "CERTIFICAZIONI_CO_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 250, 412, 0);

                                testo = "SALES CONDITIONS";
                                if (lg == "IT")
                                    testo = "CONDIZIONI COMMERCIALI";
                                fr = new Chunk(testo, CarattereWhite14Bold);
                                rndLink = "19" + sett + fx.NewKey() + lg;
                                LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 710, 412, 0);
                            }

                            if ((sett == "CO" & Disegno.SelectedValue != "NODWG"))
                            {
                                Chunk fr = new Chunk(testo, Carattere);
                                MyKey fx = new MyKey();
                                string rndLink, LinkFile;
                                fr = new Chunk("Ø REBUILDING", CarattereWhite12Bold);
                                rndLink = "12" + sett + fx.NewKey() + lg;
                                LinkFile = "DIAMETER REBUILDING_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 140, 412, 0);

                                testo = "ADD. EXPENSES";
                                if (lg == "IT")
                                    testo = "SPESE AGGIUNTIVE";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "13" + sett + fx.NewKey() + lg;
                                LinkFile = "OTHER ADDITIONAL EXPENSES_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 370, 412, 0);

                                testo = "CERTIFICATION";
                                if (lg == "IT")
                                    testo = "CERTIFICAZIONE";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "14" + sett + fx.NewKey() + lg;
                                LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 602, 412, 0);

                                testo = "SALES CONDITIONS";
                                if (lg == "IT")
                                    testo = "CONDIZIONI COMMERCIALI";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "15" + sett + fx.NewKey() + lg;
                                LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 832, 412, 0);
                            }
                            else if (sett == "SL")
                            {
                                Chunk fr = new Chunk(testo, Carattere);
                                MyKey fx = new MyKey();
                                string rndLink, LinkFile;
                                testo = "ADDITIONAL EXPENSES";
                                if (lg == "IT")
                                    testo = "SPESE AGGIUNTIVE";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "12" + sett + fx.NewKey() + lg;
                                LinkFile = "OTHER ADDITIONAL EXPENSES_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 140, 412, 0);

                                testo = "HOW IT IS MADE";
                                if (lg == "IT")
                                    testo = "COME É FATTO";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "13" + sett + fx.NewKey() + lg;
                                LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 370, 412, 0);

                                testo = "CERTIFICATION";
                                if (lg == "IT")
                                    testo = "CERTIFICAZIONE";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "14" + sett + fx.NewKey() + lg;
                                LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 602, 412, 0);

                                testo = "SALES CONDITIONS";
                                if (lg == "IT")
                                    testo = "CONDIZIONI COMMERCIALI";
                                fr = new Chunk(testo, CarattereWhite12Bold);
                                rndLink = "15" + sett + fx.NewKey() + lg;
                                LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 832, 412, 0);
                            }

                            int incremento = 115;
                            int incrementoy = 19;
                            for (var i = 0; i <= 10; i++)
                            {
                                if (i <= j)
                                {
                                    // qta
                                    testo = (string)dt1x.Rows[i]["Quantita"];
                                    if (sett == "RE")
                                    {
                                        incremento = 117;
                                        incrementoy = 19;
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 83, 358 - incrementoy * i, 0);
                                    }
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 85, 357 - incrementoy * i, 0);

                                    // incisione
                                    if (!Information.IsDBNull(dt1x.Rows[i]["Codice_Incisione"]))
                                        testo = dt1x.Rows[i]["Codice_Incisione"].ToString().Trim();
                                    else
                                        testo = "";
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 83 + incremento, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 85 + incremento, 357 - incrementoy * i, 0);
                                    // linee
                                    if (!Information.IsDBNull(dt1x.Rows[i]["Num_Linee"]))
                                    {
                                        if (Strings.Trim(testo) == "HPF")
                                            testo = dt1x.Rows[i]["Codice_lineatura"].ToString().Trim();
                                        else
                                            testo = (string)dt1x.Rows[i]["Num_Linee"];
                                    }
                                    else
                                        testo = "";
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 82 + incremento * 2, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 85 + incremento * 2, 357 - incrementoy * i, 0);
                                    // angolo
                                    if (!Information.IsDBNull(dt1x.Rows[i]["Angolo"]))
                                        testo = (string)dt1x.Rows[i]["Angolo"];
                                    else
                                        testo = "";
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 81 + incremento * 3, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 85 + incremento * 3, 357 - incrementoy * i, 0);
                                    // volume
                                    if (!Information.IsDBNull(dt1x.Rows[i]["Volume"]))
                                        testo = (string)dt1x.Rows[i]["Volume"];
                                    else
                                        testo = "";
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 82 + incremento * 4, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 85 + incremento * 4, 357 - incrementoy * i, 0);
                                    // prezzo unitario
                                    string ptot = "";
                                    if (Information.IsNumeric(dt1x.Rows[i]["Prezzo_Totale"]))
                                    {
                                        ptot = String.Format(Convert.ToDouble(dt1x.Rows[i]["Prezzo_Totale"]).ToString(), "n0") + " €";

                                        if (this.Valuta.Text != "Euro")
                                            ptot = String.Format(Convert.ToDouble(dt1x.Rows[i]["Prezzo_Totale"]).ToString(), "n0") + " $";
                                        if (Information.IsNumeric(dt1x.Rows[i]["Sconto"]))
                                        {
                                            // stampa lo sconto solo se maggiore di zero

                                            if (System.Convert.ToDouble(dt1x.Rows[i]["Sconto"]) > 0 & Information.IsNumeric(dt1x.Rows[i]["Prezzo_Vendita"]))
                                            {
                                                ptot = String.Format(Convert.ToDouble(dt1x.Rows[i]["Prezzo_Vendita"]).ToString(), "n0") + " €";
                                                if (this.Valuta.Text != "Euro")
                                                    ptot = String.Format(Convert.ToDouble(dt1x.Rows[i]["Prezzo_Vendita"]).ToString(), "n0") + " $";
                                            }
                                        }
                                        totVen = totVen + Convert.ToDouble(ptot) * Convert.ToDouble((string)dt1x.Rows[i]["Quantita"]);
                                    }

                                    string scon = "";
                                    string pven = "";
                                    double pven_x = Convert.ToDouble(dt1x.Rows[i]["Prezzo_Vendita"]);
                                    double ptot_x = Convert.ToDouble(dt1x.Rows[i]["Prezzo_Totale"]);
                                    double qta_x = Convert.ToDouble(String.Format(dt1x.Rows[i]["Quantita"].ToString(), "n0"));
                                    double x = pven_x * qta_x;
                                    double y = ptot_x * qta_x;
                                    
                                    if (this.TipoScontoStampa.SelectedValue == "Row")
                                    {
                                        // stampa sconto per ogni riga

                                        if (Information.IsNumeric(dt1x.Rows[i]["Sconto"]))
                                        {
                                            // stampa lo sconto solo se maggiore di zero

                                            if (System.Convert.ToDouble(dt1x.Rows[i]["Sconto"]) < 0)
                                            {
                                                scon = String.Format(Convert.ToDouble(dt1x.Rows[i]["Sconto"]).ToString(), "n0");
                                                scon = scon + "%";
                                            }
                                        }

                                    if (Information.IsNumeric(dt1x.Rows[i]["Prezzo_Vendita"]))
                                        {
                                            pven = String.Format(x.ToString(), "n0");
                                            totOff = totOff + System.Convert.ToDouble(pven);
                                            if (this.Valuta.Text != "Euro")
                                                pven = String.Format(x.ToString()) + " $";
                                            else
                                                pven = String.Format(x.ToString()) + " €";
                                        }
                                    }
                                    else
                                    {
                                        if (Information.IsNumeric(dt1x.Rows[i]["Prezzo_Totale"]))
                                        {
                                            pven = y.ToString();
                                            totOff = totOff + System.Convert.ToDouble(pven);
                                        }
                                        if (Information.IsNumeric(dt1x.Rows[i]["Prezzo_Vendita"]))
                                        {
                                            pven = String.Format(x.ToString());
                                            totSco = totSco + System.Convert.ToDouble(pven);
                                        }

                                        if (this.Valuta.Text != "Euro")
                                            pven = String.Format(y.ToString()) + " $";
                                        else
                                            pven = String.Format(y.ToString()) + " €";
                                    }

                                    // Totale
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(ptot, Carattere), 95 + incremento * 5, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(ptot, Carattere), 95 + incremento * 5, 358 - incrementoy * i, 0);

                                    if (this.TipoScontoStampa.SelectedValue == "Row")
                                    {
                                        // Stampa sconto per ogni riga
                                        if (Information.IsNumeric(dt1x.Rows[i]["Sconto"]))
                                        {
                                            if (sett == "RE")
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(scon, Carattere), 100 + incremento * 6, 358 - incrementoy * i, 0);
                                            else
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(scon, Carattere), 102 + incremento * 6, 357 - incrementoy * i, 0);

                                            // Stampa della sritta DISCOUNT
                                            testo = "";
                                            if (lg == "EN")
                                                testo = "DISCOUNT";
                                            else
                                                testo = "SCONTO";
                                            if (sett == "RE")
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 80 + incremento * 6, 380, 0);
                                            else
                                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite9Bold), 88 + incremento * 6, 380, 0);
                                        }
                                    }
                                    if (sett == "RE")
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(pven, Carattere), 95 + incremento * 7, 358 - incrementoy * i, 0);
                                    else
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(pven, Carattere), 110 + incremento * 7, 357 - incrementoy * i, 0);
                                }
                            }

                            if (this.TipoScontoStampa.SelectedValue == "Row")
                            {
                                // Totale Offerta
                                testo = Strings.Format(totOff, "n0");
                                if (this.Valuta.Text != "Euro")
                                    testo = testo + " $";
                                else
                                    testo = testo + " €";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 95 + incremento * 7, 152, 0);
                                else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 152, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 110 + incremento * 7, 152, 0);
                                testo = "TOTALE OFFERTA";
                                if (lg == "EN")
                                    testo = "GRAND TOTAL";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(18 + incremento * 6.5), 152, 0);
                                else if (sett == "CO" & Disegno.SelectedValue != "NODWG")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereWhite8Bold), incremento * 7, 152, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(36 + incremento * 6.5), 152, 0);
                            }
                            else
                            {
                                testo = Strings.Format(totOff, "n0");
                                if (this.Valuta.Text != "Euro")
                                    testo = testo + " $";
                                else
                                    testo = testo + " €";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 152, 0);
                                else if (sett == "SL")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 110 + incremento * 7, 152, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 152, 0);
                                testo = "TOTALE OFFERTA";
                                if (lg == "EN")
                                    testo = "GRAND TOTAL";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(18 + incremento * 6.5), 152, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(36 + incremento * 6.5), 152, 0);
                                testo = Strings.Format(totOff - totSco, "n0"); // Format(totVen - totOff, "n1")
                                if (this.Valuta.Text != "Euro")
                                    testo = testo + " $";
                                else
                                    testo = testo + " €";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 126, 0);
                                else if (sett == "SL")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 110 + incremento * 7, 126, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 126, 0);
                                testo = "SCONTO CONCESSO";
                                if (lg == "EN")
                                    testo = "TOTAL DISCOUNT";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(18 + incremento * 6.5), 126, 0);
                                else if (sett == "SL")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereWhite8Bold), (float)(35 + incremento * 6.5), 126, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(36 + incremento * 6.5), 126, 0);
                                // totale offerta
                                testo = Strings.Format(totSco, "n0");
                                if (this.Valuta.Text != "Euro")
                                    testo = testo + " $";
                                else
                                    testo = testo + " €";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 97, 0);
                                else if (sett == "SL")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 110 + incremento * 7, 97, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereBold), 100 + incremento * 7, 97, 0);
                                testo = "TOTALE SCONTATO";
                                if (lg == "EN")
                                    testo = "TOTAL AFTER DISCOUNT";
                                if (sett == "RE")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(18 + incremento * 6.5), 97, 0);
                                else if (sett == "SL")
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereWhite8Bold), (float)(35 + incremento * 6.5), 97, 0);
                                else
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8Bold), (float)(36 + incremento * 6.5), 97, 0);
                            }

                            // stampa condizioni di vendita
                            testo = "";
                            if (this.Porto.SelectedValue != "")
                                testo = this.Porto.SelectedItem.Text;
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 132, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 132, 0);
                            testo = "";
                            if (this.MagazzinoUscita.SelectedValue != "")
                                testo = this.MagazzinoUscita.SelectedItem.Text;
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 113, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 113, 0);
                            testo = "";
                            if (Information.IsNumeric(this.IdSede.Text))
                            {
                                string sqlD = "SELECT * FROM OFF_DestinazioniClienti WHERE Id=" + System.Convert.ToString(this.IdSede.Text);
                                SqlCommand cmdD = new SqlCommand(sqlD, ConnSDB);
                                SqlDataAdapter daD = new SqlDataAdapter(cmdD);
                                DataTable dtD = new DataTable();
                                daD.Fill(dtD);
                                if (dtD.Rows.Count > 0)
                                    testo = dtD.Rows[0]["RagSoc"] + " - " + dtD.Rows[0]["Indirizzo"] + " - " + dtD.Rows[0]["Localita"] + " - " + dtD.Rows[0]["Nazione"];
                            }
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 94, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 94, 0);
                            testo = "";
                            if (this.TipoPagamento.SelectedValue != "")
                                testo = this.TipoPagamento.SelectedItem.Text;
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 75, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 56, 0);
                            testo = this.ConsegnaLibera.Text;
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 56, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 75, 0);
                            testo = "";
                            if (Information.IsNumeric(this.CostoTrasporto.Text))
                            {
                                testo = String.Format(Convert.ToDouble(this.CostoTrasporto.Text).ToString(), "n0") + " €";
                                if (this.Valuta.Text != "Euro")
                                    testo = String.Format(Convert.ToDouble(this.CostoTrasporto.Text).ToString(), "n0") + " $";
                            }
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 50, 0);
                            else
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(testo, Carattere), 160, 35, 0);

                            string myallegato = dis + "_" + lg + ".pdf";
                        }
                        stamper.Close();
                        myStream.Close();
                    }
                    reader.Close();
                    reader.Dispose();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                msg = "Errore";
            }
            return msg;
        }
        protected void ScriviTempKey(string rndLink, string Disegno, string lingua, string LinkFile, bool persGPL)
        {
            try
            {
                string sql = "INSERT INTO MKT_TempFileLink (Disegno,LinkFile,LinkFileTemp,Lingua,DataCrea) ";
                sql = sql + " VALUES(@Disegno,@LinkFile,@LinkFileTemp,@Lingua,GetDate())";
                if (persGPL == true)
                {
                    sql = "INSERT INTO MKT_TempFileLink (Disegno,LinkFile,LinkFileTemp,Lingua,DataCrea,DataScad) ";
                    sql = sql + " VALUES(@Disegno,@LinkFile,@LinkFileTemp,@Lingua,GetDate(),@DataScad)";
                }
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFileTemp", DbType.String, rndLink));
                cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("Disegno", DbType.String, Disegno, 10));
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFile", DbType.String, LinkFile, 50));
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFileTemp", DbType.String, rndLink, 50));
                cmd.Parameters.Add(z.CreaSqlParameter("Lingua", DbType.String, lingua, 2));
                cmd.Parameters.Add(z.CreaSqlParameter("DataScad", DbType.DateTime, "31/12/2025"));
                try
                {
                    ConnSDB.Open();
                    cmd.ExecuteNonQuery();
                    ConnSDB.Close();
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                    ConnSDB.Close();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected bool GetPersonalGPL(int id)
        {
            bool persgpl = false;
            try
            {
                string sql = "SELECT PersonalGPL FROM OFF_ClientiSDB WHERE Id=" + id;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    persgpl = System.Convert.ToBoolean(dt.Rows[0]["PersonalGPL"]);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return persgpl;
        }



    }
}