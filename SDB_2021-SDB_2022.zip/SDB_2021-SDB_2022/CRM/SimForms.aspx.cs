﻿using SDB_2021.Code;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Telerik.Web.UI;

namespace SDB_2021.CRM
{
    public partial class SimForms : System.Web.UI.Page
    {
        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        protected void Page_Load(object sender, System.EventArgs e)
        {

        }
        protected void Lingua_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string sql = "SELECT * FROM [OFF_FormsDoc] WHERE Lingua= '" + Lingua.Text + "' ORDER BY [Lingua]";
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Forms.DataSourceID = null;
                Forms.DataSource = dt;
                Forms.DataValueField = "docname";
                Forms.DataTextField = "docname";
                Forms.DataBind();
            }
        }
        protected void Forms_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            LinkForm.Attributes["src"] = "Formsdoc/" + e.Text;
            if (e.Text != "")
            {
                LinkForm.Visible = true;
            }
        }   

    }
}