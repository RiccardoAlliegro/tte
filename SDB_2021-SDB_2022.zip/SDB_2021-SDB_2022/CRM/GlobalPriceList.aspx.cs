﻿using SDB_2021.Code;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.VisualBasic;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using Telerik.Web.UI;

namespace SDB_2021.CRM
{
    public partial class GlobalPriceList : System.Web.UI.Page
    {
        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                RadEditor1.Modules.Clear();
                string dis = "";
                if ((Request.QueryString["cl"]) != null)
                {
                    if (Information.IsNumeric(Request.QueryString["cl"]))
                    {
                        int idcli = Convert.ToInt32(Request.QueryString["cl"]);
                        this.idcliente.Text = idcli.ToString();
                        FunzioniCRM z = new FunzioniCRM();
                        this.Cliente.Text = z.GetClienteById(idcli);
                        if ((Request.QueryString["sd"]) != null)
                        {
                            if (Information.IsNumeric(Request.QueryString["sd"]))
                            {
                                int idsede = Convert.ToInt32(Request.QueryString["sd"]);
                                CaricaContatti(idcli, idsede.ToString());
                                this.SendEmail.Enabled = true;
                                if ((Request.QueryString["dis"]) != null)
                                    dis = Request.QueryString["dis"].Trim();
                            }
                        }
                        else
                        {
                            CaricaContatti(idcli);
                            this.SendEmail.Enabled = true;
                        }
                    }
                }
                CaricaListini(0, dis);
            }
            LimitaClienti();
        }

        protected void LimitaClienti()
        {
            if (User.IsInRole("Agenti") | User.IsInRole("Commerciale"))
            {
                FunzioniCRM p = new FunzioniCRM();
                string nome = p.GetNomeCompleto(User.Identity.Name);
                this.SqlClienti.SelectCommand = "Select Id, RagSoc FROM OFF_ClientiSDB WHERE (Manager='" + nome + "' OR BackOffice='" + nome + "') OR RagSoc='SIMEC'";
            }
            string sql = SqlClienti.SelectCommand + " ORDER BY RagSoc";
            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Cliente.DataSourceID = null;
                Cliente.DataSource = dt;
                Cliente.DataTextField = "RagSoc";
                Cliente.DataValueField = "Id";
                Cliente.DataBind();
            }
        }
        protected void CaricaListini(int noBind = 0, string dis = "")
        {
            if (User.IsInRole("Agenti"))
            {
                try
                {
                    string sql = "";
                    dis = Strings.Replace(dis, "-E-", "&");
                    if (Information.IsNumeric(this.idcliente.Text))
                    {
                        sql = "SELECT DISTINCT [Id], [Famiglia], [Settore], [Struttura], [Disegno], [Diametro],Diametrointerno, [Tavola], [TavolaIncisa],";
                        sql += "[Lunghezza], [Costruttore], [validita] FROM [vw_ListiniPDFCliente] where (IdCliente=" + Convert.ToString(this.idcliente.Text) + " AND Settore='SL') ";
                        sql += " OR (IdCliente=" + Convert.ToString(this.idcliente.Text) + " AND Settore ='EA' ) OR (IdCliente=" + Convert.ToString(this.idcliente.Text) + " AND Settore='RE') OR (IdCliente=" + Convert.ToString(this.idcliente.Text) + " AND Settore='CO')";
                    }
                    if (dis != "")
                    {
                        sql = "SELECT DISTINCT [Id], [Famiglia], [Settore], [Struttura], [Disegno], [Diametro],Diametrointerno, [Tavola], [TavolaIncisa],";
                        sql += "[Lunghezza], [Costruttore], [validita] FROM [vw_ListiniPDFCliente] where Disegno='" + dis + "'";
                    }
                    if (sql != "")
                    {
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    this.GvGPL.DataSourceID = null;
                    this.GvGPL.DataSource = dt;
                    if (noBind == 0)
                        this.GvGPL.DataBind();
                    }

                    this.GvGPL.Visible = true;
                }
                catch (Exception ex)
                {
                    this.GvGPL.Visible = false;
                }
            }
        }

        protected void CaricaContatti(int idcli, string idsede = "")
        {
            try
            {
                string sql = "SELECT * FROM vw_OFF_ContattiSedi WHERE Idcliente=" + idcli;
                if (Information.IsNumeric(idsede))
                    sql = sql + " And IdSede=" + idsede;
                sql = sql + " ORDER BY idsede";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string x = "";
                EliminaElenco();
                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    // responsabile interno Cliente
                    x = "";
                    if (!Information.IsDBNull(dt.Rows[i]["Localita"]))
                        x = dt.Rows[i]["Localita"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Indirizzo"]))
                        x = x + " " + dt.Rows[i]["Indirizzo"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Nominativo"]))
                        x = x + dt.Rows[i]["Nominativo"] + " - ";
                    if (!Information.IsDBNull(dt.Rows[i]["Email"]))
                        x = x + dt.Rows[i]["Email"];
                    this.ChlTO.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void EliminaElenco()
        {
            this.ChlTO.Items.Clear();
        }
        protected void SendEmail_Click(object sender, EventArgs e)
        {
            string msg = "";
            if (Information.IsNumeric(this.idcliente.Text))
            {
                if (!Information.IsNothing(this.GvGPL.SelectedValue))
                {
                    this.PanelEmail.Visible = true;

                    CreaPDFAllegato(this.GvGPL.SelectedValue.ToString());
                }
                else if (this.VirtualBrochure.SelectedValue == "VirtualBrochure")
                {
                    if (this.Settore.SelectedValue != "")
                    {
                        AllegaVB("S", this.Settore.SelectedValue, this.Lingua.SelectedValue);
                        this.PanelEmail.Visible = true;
                    }
                    else
                        msg = "Select Branch.";
                }
                else if (this.VirtualBrochure.SelectedValue == "PickUpForm")
                {
                    AllegaPF(this.Lingua.SelectedValue);
                    this.PanelEmail.Visible = true;
                    string sql = "Select nazione from OFF_CLIENTISDB where id =" + this.idcliente.Text;
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (Convert.ToInt16(dt.Rows[0]["Nazione"]) == 86)
                    {
                        Oggetto.Text = "RICHIESTA COMPILAZIONE MODULO PICK-UP";

                        RadEditor1.Content = "<div style='font-family:Calibri;'>Buongiorno, <br/> In allegato il nostro modulo di pick-up.<br/> La preghiamo di voler procedere alla compilazione di tutti i campi e di volerlo inoltrare all’indirizzo che trova sul modulo stesso, per permetterci di provvedere al ritiro della merce presso il Vostro magazzino. <br/> Cordiali saluti,  <br/><br/>  Simec Group</div>";
                    }
                    else
                    {
                        Oggetto.Text = "REQUEST FOR FILLING PICK-UP FORM";
                        RadEditor1.Content = @"<div style='font-family:Calibri;'>Dear Sir/Madam, <br/> Please find our pick-up form attached.<br/> We kindly ask you to fill in all fields and to send it back to the address you will find in the form, 
                                          so that we can collect the goods from your warehouse. <br/> Kind regards,<br/><br/>  Simec Group </div>";
                    }
                }
                else
                    msg = "Select Simec DWG or Virtual Brochure.";
            }
            else
                msg = "Select Customer.";
            if (msg != "")
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
        }
        protected void AllegaPF(string lg)
        {
            this.Allegato.Visible = true;
            this.Allegato.Text = "SimecGroup_PickupForm.pdf";
            this.myAllegato.NavigateUrl = "~/doc/" + "SimecGroup_PickupForm.pdf";
        }
        protected void AllegaVB(string fam, string sett, string lg)
        {
            try
            {
                // allega la virtual brochure per il settore applicativo e la lingua selezionata
                string pathin = "";
                if (sett == "RE")
                    pathin = Server.MapPath(@"..\Doc") + @"\Virtual_Brochure_" + fam + "_" + sett + "_" + lg + "_NEW.pdf";
                else
                    pathin = Server.MapPath(@"..\Doc") + @"\Virtual_Brochure_" + fam + "_" + sett + "_" + lg + ".pdf";
                string pathout = Server.MapPath(@"..\Doc\ListiniPDF") + @"\Virtual_Brochure_" + fam + "_" + sett + "_" + lg + ".pdf";
                iTextSharp.text.Font Carattere = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.NORMAL);
                iTextSharp.text.Font Carattere7 = iTextSharp.text.FontFactory.GetFont("Montserrat", 7, iTextSharp.text.Font.NORMAL);
                iTextSharp.text.Font Carattere2 = iTextSharp.text.FontFactory.GetFont("Montserrat", 11, iTextSharp.text.Font.NORMAL);
                iTextSharp.text.Font CarattereBoldRed = iTextSharp.text.FontFactory.GetFont("Montserrat", 16, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
                iTextSharp.text.Font CarattereRed12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
                iTextSharp.text.Font CarattereWhite10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                iTextSharp.text.Font CarattereWhite11 = iTextSharp.text.FontFactory.GetFont("Montserrat", 14, iTextSharp.text.Font.BOLDITALIC, iTextSharp.text.BaseColor.WHITE);
                iTextSharp.text.Font CarattereWhite12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 14, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                iTextSharp.text.Font CarattereWhite17 = iTextSharp.text.FontFactory.GetFont("Montserrat", 17, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                iTextSharp.text.Font CarattereWhiteBold17 = iTextSharp.text.FontFactory.GetFont("Montserrat", 17, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                iTextSharp.text.Font CarattereRed10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
                iTextSharp.text.Font CarattereWhite8 = iTextSharp.text.FontFactory.GetFont("Montserrat", 8, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);

                PdfReader reader = new PdfReader(pathin);
                using ((reader))
                {
                    string testo = "";
                    PdfStamper stamper = new PdfStamper(reader, new FileStream(pathout, FileMode.Create));
                    using ((stamper))
                    {
                        reader.SelectPages("1");
                        var pageSize = reader.GetPageSize(1);

                        double prezzo = 0;
                        PdfContentByte pbover = stamper.GetOverContent(1);
                        testo = "COMPANY PORTRAIT";
                        if (lg == "IT")
                            testo = "CHI SIAMO";
                        else if (lg == "ES")
                            testo = "QUIENEN SOMOS";
                        else if (lg == "DE")
                            testo = "WER WIND SIND";
                        if (lg == "IT")
                            testo = "CHI SIAMO";
                        Chunk fr = new Chunk(testo, CarattereWhite11);
                        MyKey fx = new MyKey();
                        string rndLink = "1" + sett + fx.NewKey() + lg;

                        if (sett == "SL")
                        {
                            string LinkFile = "CompanyPortrait_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 150, 130, 0);

                            testo = "SIMEC DIGITAL BACKGROUND";
                            fr = new Chunk(testo, CarattereWhite11);
                            rndLink = "2" + sett + fx.NewKey() + lg;
                            LinkFile = "SDB_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 500, 130, 0);

                            testo = "NEW SLEEVE";
                            if (lg == "IT")
                                testo = "MANICA NUOVA";
                            else if (lg == "ES")
                                testo = "MANGA NUEVA";
                            else if (lg == "DE")
                                testo = "NEUE HULSEN";

                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "3" + sett + fx.NewKey() + lg;
                            LinkFile = "NEW_SUPPLY_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 772, 455, 0);

                            testo = "CERTIFICATION";
                            if (lg == "IT")
                                testo = "CERTIFICAZIONI";
                            else if (lg == "ES")
                                testo = "CERTIFICACIONES";
                            else if (lg == "DE")
                                testo = "ZERTIFIZIERUNGEN";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "4" + sett + fx.NewKey() + lg;
                            LinkFile = "Certificazioni_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 772, 221, 0);

                            testo = "ENGRAVINGS";
                            if (lg == "IT")
                                testo = "INCISIONI";
                            else if (lg == "ES")
                                testo = "GRABADOS";
                            else if (lg == "DE")
                                testo = "ENGRAVIERUNGEN";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "5" + sett + fx.NewKey() + lg;
                            LinkFile = "ENGRAVING_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 772, 340, 0);

                            testo = "COATING";
                            if (lg == "IT")
                                testo = "RIPORTO";
                            else if (lg == "ES")
                                testo = "REVESTIMENTOS";
                            else if (lg == "DE")
                                testo = "BESHICHTUNG";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "6" + sett + fx.NewKey() + lg;
                            LinkFile = "COATING_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 772, 280, 0);

                            testo = "REGENERATION";
                            if (lg == "IT")
                                testo = "RIGENERAZIONE";
                            else if (lg == "ES")
                                testo = "REGENERACION";
                            else if (lg == "DE")
                                testo = "REGENERATION";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "7" + sett + fx.NewKey() + lg;
                            LinkFile = "TEST_E_VALIDAZIONE_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 772, 398, 0);
                        }

                        if (sett == "CO")
                        {
                            testo = "NEW SUPPLY";
                            if (lg == "IT")
                                testo = "RULLO NUOVO";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "2" + sett + fx.NewKey() + lg;
                            string LinkFile = "NEW_SUPPLY_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 773, 453, 0);

                            testo = "REFURBISHMENT";
                            if (lg == "IT")
                                testo = "RIGENERATO";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "3" + sett + fx.NewKey() + lg;
                            LinkFile = "REFURBISHMENT_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 773, 395, 0);

                            testo = "COATING";
                            if (lg == "IT")
                                testo = "RIPORTI";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "4" + sett + fx.NewKey() + lg;
                            LinkFile = "COATING_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 773, 337, 0);


                            testo = "ENGRAVING";
                            if (lg == "IT")
                                testo = "INCISIONE";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "5" + sett + fx.NewKey() + lg;
                            LinkFile = "ENGRAVING_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 773, 278, 0);

                            testo = "CERTIFICATES";
                            if (lg == "IT")
                                testo = "CERTIFICAZIONI";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "6" + sett + fx.NewKey() + lg;
                            LinkFile = "CERTIFICATION_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 773, 218, 0);

                            testo = "COMPANY PORTRAIT";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "7" + sett + fx.NewKey() + lg;
                            LinkFile = "COMPANY_PORTRAIT_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 158, 130, 0);

                            testo = "SIMEC DIGITAL BACKGROUND";
                            fr = new Chunk(testo, CarattereWhite17);
                            rndLink = "8" + sett + fx.NewKey() + lg;
                            LinkFile = "SDB_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 130, 0);
                        }

                        if (sett == "RS")
                        {
                            string LinkFile = "COMPANY_PORTRAIT_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 160, 130, 0);

                            testo = "HOW IT IS MADE";
                            if (lg == "IT")
                                testo = "COSTRUZIONE";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "2" + sett + fx.NewKey() + lg;
                            LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 432, 0);

                            testo = "THERMAL SPRAY COATINGS";
                            if (lg == "IT")
                                testo = "RIPORTI THERMAL SPRAY";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "3" + sett + fx.NewKey() + lg;
                            LinkFile = "THERAML COATING_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 362, 0);

                            testo = "LASER ENGRAVING";
                            if (lg == "IT")
                                testo = "INCISIONI A LASER";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "4" + sett + fx.NewKey() + lg;
                            LinkFile = "LASER ENGRAVINGS_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 290, 0);

                            testo = "MECHANICAL ENGRAVING";
                            if (lg == "IT")
                                testo = "INCISIONI MECCANICHE";
                            fr = new Chunk(testo, CarattereWhite12);
                            rndLink = "5" + sett + fx.NewKey() + lg;
                            LinkFile = "MECHANICAL ENGRAVINGS_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 218, 0);
                        }

                        if (sett == "RE")
                        {
                            testo = "NEW SUPPLY";
                            if (lg == "IT")
                                testo = "COSTRUZIONE";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "2" + sett + fx.NewKey() + lg;
                            var LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 450, 0);

                            testo = "COATING";
                            if (lg == "IT")
                                testo = "RIPORTO";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "3" + sett + fx.NewKey() + lg;
                            LinkFile = "REFURBISHMENT_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 392, 0);

                            testo = "ENGRAVINGS";
                            if (lg == "IT")
                                testo = "INCISIONI";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "4" + sett + fx.NewKey() + lg;
                            LinkFile = "ENGRAVINGS_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 333, 0);

                            testo = "CERTIFICATIONS";
                            if (lg == "IT")
                                testo = "CERTIFICAZIONI";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "5" + sett + fx.NewKey() + lg;
                            LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 777, 274, 0);

                            testo = "COMPANY PORTRAIT";
                            fr = new Chunk(testo, CarattereWhite11);
                            rndLink = "6" + sett + fx.NewKey() + lg;
                            LinkFile = "CompanyPortrait_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 170, 130, 0);

                            testo = "SIMEC DIGITAL BACKGROUND";
                            fr = new Chunk(testo, CarattereWhite11);
                            rndLink = "7" + sett + fx.NewKey() + lg;
                            LinkFile = "SDB_" + sett + "_" + lg + "_NEW.pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 533, 130, 0);
                        }

                        if (sett == "SA")
                        {
                            testo = "ABOUT US";
                            if (lg == "IT")
                                testo = "CHI SIAMO";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            string LinkFile = "CompanyPortrait_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 785, 430, 0);

                            testo = "NEW SUPPLY";
                            if (lg == "IT")
                                testo = "RULLO NUOVO";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "2" + sett + fx.NewKey() + lg;
                            LinkFile = "NuovoRullo_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 785, 365, 0);

                            testo = "REFURBISHMENT";
                            if (lg == "IT")
                                testo = "RIGENERATO";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "3" + sett + fx.NewKey() + lg;
                            LinkFile = "Rigenerato_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 785, 300, 0);

                            testo = "ENGRAVINGS";
                            if (lg == "IT")
                                testo = "INCISIONI";
                            fr = new Chunk(testo, CarattereWhiteBold17);
                            rndLink = "4" + sett + fx.NewKey() + lg;
                            LinkFile = "ENGRAVINGS_" + sett + "_" + lg + ".pdf";
                            ScriviTempKey(rndLink, sett, lg, LinkFile, false);
                            fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 785, 233, 0);
                        }

                        this.Allegato.Visible = true;
                        this.Allegato.Text = "Virtual_Brochure_" + fam + "_" + sett + "_" + lg + ".pdf";
                        this.myAllegato.NavigateUrl = "~/doc/" + "ListiniPDF" + "/Virtual_Brochure_" + fam + "_" + sett + "_" + lg + ".pdf";
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                this.Allegato.Visible = false;
                this.Allegato.Text = "";
                this.myAllegato.NavigateUrl = "";
            }
        }

        protected void Invia_Click(object sender, EventArgs e)
        {
            string msg = "";
            this.Errore.Text = "";
            Supporto z = new Supporto();
            try
            {
                string oggetto = this.Oggetto.Text;
                if (oggetto == "")
                    msg = " - Subject ";
                // Dim testo As String = Me.Testo.Text
                string testo = this.RadEditor1.Content;
                string testo1 = "";
                if (User.Identity.Name.ToUpper() == "AG001")
                {
                    testo1 = testo1 + "<br/><br/>Este es un mensaje automático. Las respuestas a este mensaje no se gestionan ni reenvían. Para cualquier necesidad, contacte con mheredia@lapeyra.com <br/>";
                    testo1 = testo1 + "La información, los datos y los documentos adjuntos contenidos en esta comunicación son de carácter privado y, como tales, son confidenciales y, en cualquier caso, destinados exclusivamente a los destinatarios indicados en el epígrafe. <br>";
                    testo1 = testo1 + "Queda prohibida la distribución, difusión y / o copia del documento transmitido por cualquier persona que no sea el destinatario. Si ha recibido este mensaje por error, por favor destrúyalo y notifíquelo inmediatamente.";
                }
                else if (this.Lingua.SelectedValue == "IT")
                {
                    testo1 = testo1 + "<br/><br/>Questo è un messaggio automatico. Le risposte a questo messaggio non vengono gestite né inoltrate. Per qualsiasi necessità siete pregati di rivolgerVi al Vs. commerciale di riferimento. <br/>";
                    testo1 = testo1 + "Le informazioni, i dati e le notizie contenute nella presente comunicazione e i relativi allegati sono di natura privata e come tali possono essere riservate e sono, comunque, destinate esclusivamente ai destinatari indicati In epigrafe. La diffusione, distribuzione e/o la copiatura del documento trasmesso da parte di qualsiasi soggetto diverso dal destinatario è proibita, sia ai sensi dell'art. 616 c.p., sia ai sensi del D.Lgs. n. 196/2003. Se avete ricevuto questo messaggio per errore, vi preghiamo di distruggerlo e di darcene immediata comunicazione <br/>";
                }
                else
                {
                    testo1 = testo1 + "<br/><br/>This is an automatic mail. The answers to this message are neither stored, nor treated. If any problem, please contact Simec Sales Manager in charge with your company. <br/>";
                    testo1 = testo1 + "This message And any attachments (the message) are intended solely for the addressees and are confidential. If you receive this message in error, please delete it and immediately notify the sender. Any use not in accordance with its purpose, any dissemination, copying or disclosure, either whole or partial is prohibited without prior formal approval. The internet cannot guarantee the integrity of the message. The companies of Simec Group do not accept any liability for data corruption, delay, interception or any modification in relation with this message.";
                }
                if (testo == "")
                    msg = " - Message ";

                string alleg = this.Allegato.Text;
                if (alleg == "")
                    msg = " - Message ";

                if (msg != "")
                {
                    msg = "COMPULSORY FIELDS: " + msg;
                    this.Errore.Text = msg;
                }
                else
                {
                    // invia email ai contatti selezionati
                    string x = "";
                    string y = "";
                    string dest = "";
                    string refCli = "";
                    for (var i = 0; i <= this.ChlTO.Items.Count - 1; i++)
                    {
                        if (this.ChlTO.Items[i].Selected == true)
                        {
                            x = this.ChlTO.Items[i].Text;
                            y = this.ChlTO.Items[i].Text;
                            x = Strings.Right(x, Strings.Len(x) - x.LastIndexOf("- ") - 1);
                            y = Strings.Left(y, y.LastIndexOf("- ") - 1);
                            y = Strings.Right(y, Strings.Len(y) - y.LastIndexOf("- ") - 1);
                            dest = dest + "," + Strings.Trim(y);
                            refCli = refCli + "," + Strings.Trim(x);
                        }
                    }
                    dest = Strings.Right(dest, Strings.Len(dest) - 1);
                    refCli = Strings.Right(refCli, Strings.Len(refCli) - 1);
                    alleg = MapPath(@"..\doc\" + @"ListiniPDF\" + this.Allegato.Text);
                    if (this.Allegato.Text == "SimecGroup_PickupForm.pdf")
                        alleg = MapPath(@"..\doc\" + this.Allegato.Text);
                    string rifCopiaSimec = "";
                    string esitoinvio = z.inviaMail(refCli, "", testo + testo1, oggetto, "", "HTML", alleg, "", rifCopiaSimec);
                    if (esitoinvio == "ok")
                    {
                        // scrive dati invio nella tabella OFF_GLPInviati
                        string sql = "INSERT INTO OFF_GLPInviati (IdCliente,Cliente,InviatoA,EmailTo,TestoMail,Disegno,Maggiorazione,Sconto,Lingua,Data_invio,Ut_Invio)";
                        sql = sql + " VALUES(@IdCliente,@Cliente,@InviatoA,@EmailTo,@TestoMail,@Disegno,@Maggiorazione,0,@Lingua,GetDate(),'" + User.Identity.Name + "')";
                        SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                        Generic par = new Generic();
                        cmd.Parameters.Add(par.CreaSqlParameter("IdCliente", DbType.Int32, idcliente.Text));
                        cmd.Parameters.Add(par.CreaSqlParameter("Cliente", DbType.String, Cliente.Text));
                        cmd.Parameters.Add(par.CreaSqlParameter("InviatoA", DbType.String, dest));
                        cmd.Parameters.Add(par.CreaSqlParameter("EmailTo", DbType.String, refCli));
                        cmd.Parameters.Add(par.CreaSqlParameter("TestoMail", DbType.String, testo, 8000));
                        string dis = Strings.Left(alleg, Strings.Len(alleg) - 4);
                        dis = Strings.Right(dis, Strings.Len(dis) - dis.LastIndexOf(@"\") - 1);
                        cmd.Parameters.Add(par.CreaSqlParameter("Disegno", DbType.String, dis, 50));

                        cmd.Parameters.Add(par.CreaSqlParameter("Maggiorazione", DbType.Double, this.Maggiorazione.Text));
                        cmd.Parameters.Add(par.CreaSqlParameter("Lingua", DbType.String, Lingua.SelectedValue));
                        try
                        {
                            ConnSDB.Open();
                            cmd.ExecuteNonQuery();
                            ConnSDB.Close();
                        }
                        catch (Exception ex)
                        {
                            msg = "Error register data " + ex.Message;
                            ConnSDB.Close();
                        }
                        msg = "Email messagge successful!";
                        ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                    }
                    else
                    {
                        msg = "Error!";
                        ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void Annulla_Click(object sender, EventArgs e)
            {
                this.PanelEmail.Visible = false;
            }
        protected string CreaPDFAllegato(string id)
        {
            string msg = "";
            try
            {
                // Dim sql1 As String = "Select * FROM ListinoPDF WHERE Id='" & id & "'"
                string sql1 = "Select * FROM ListinoPDF WHERE Disegno='" + id + "'";
                SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                string lg = this.Lingua.SelectedValue;
                double maggior = 0;
                if (Information.IsNumeric(this.Maggiorazione.Text))
                {
                    maggior = Convert.ToDouble(this.Maggiorazione.Text);
                    if (maggior < 0)
                        maggior = 0;
                }
                da1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    string dis = dt1.Rows[0]["Disegno"].ToString().Trim();
                    string fam = dt1.Rows[0]["Famiglia"].ToString().Trim();
                    string sett = dt1.Rows[0]["Settore"].ToString().Trim();
                    string ModelloPdf = "";
                    if (!Information.IsDBNull(dt1.Rows[0]["ModelloPdf"].ToString().Trim()))
                {
                        ModelloPdf = dt1.Rows[0]["ModelloPdf"].ToString().Trim();
                        sql1 = "Select * FROM ListinoPDF WHERE Disegno='" + dis + "'";
                        cmd1 = new SqlCommand(sql1, ConnSDB);
                        da1 = new SqlDataAdapter(cmd1);
                        dt1 = new DataTable();
                        da1.Fill(dt1);
                    }
                    string pathin = Server.MapPath(@"..\Doc") + @"\" + fam + "_" + sett + "_" + lg + ".pdf";
                    if (ModelloPdf != "")
                        pathin = Server.MapPath(@"..\Doc") + @"\" + ModelloPdf + "_" + lg + ".pdf";
                    string pathout = Server.MapPath(@"..\Doc\ListiniPDF") + @"\" + Strings.Replace(dis, "&", "e") + "_" + lg + ".pdf";


                    // If dis Like "NOR*" Then
                    // 'per i listino Normeccanica, già compilati e non legati al listino, crea una copia del file modello
                    // pathin = Server.MapPath("..\Doc") & "\" & Replace(dis, "&", "e") & "_" & lg & ".pdf"
                    // pathout = Server.MapPath("..\Doc\ListiniPDF") & "\" & Replace(dis, "&", "e") & "_" & lg & ".pdf"
                    // Me.Allegato.Text = dis & "_" & lg & ".pdf"
                    // Me.myAllegato.NavigateUrl = "~/doc/" & "ListiniPDF" & "/" & Replace(dis, "&", "e") & "_" & lg & ".pdf"
                    // File.Copy(pathin, pathout, True)
                    // Return msg
                    // End If

                    iTextSharp.text.Font Carattere = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font CarattereWhite9 = iTextSharp.text.FontFactory.GetFont("Montserrat", 9, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font Carattere7 = iTextSharp.text.FontFactory.GetFont("Montserrat", 7, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere7Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", (float)8.5, iTextSharp.text.Font.BOLD);
                    iTextSharp.text.Font Carattere2 = iTextSharp.text.FontFactory.GetFont("Montserrat", 11, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.NORMAL);
                    iTextSharp.text.Font Carattere12Bold = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.BOLD);
                    iTextSharp.text.Font CarattereBoldRed = iTextSharp.text.FontFactory.GetFont("Montserrat", 16, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.RED);
                    iTextSharp.text.Font CarattereRed12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite8 = iTextSharp.text.FontFactory.GetFont("Montserrat", 8, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite6 = iTextSharp.text.FontFactory.GetFont("Montserrat", 7, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite18 = iTextSharp.text.FontFactory.GetFont("Montserrat", 18, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhite12 = iTextSharp.text.FontFactory.GetFont("Montserrat", 12, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhiteBold18 = iTextSharp.text.FontFactory.GetFont("Montserrat", 18, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhiteBold20 = iTextSharp.text.FontFactory.GetFont("Montserrat", 20, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    iTextSharp.text.Font CarattereWhiteBold16 = iTextSharp.text.FontFactory.GetFont("Montserrat", 16, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.WHITE);
                    int NUmgiallo = Information.RGB(0, 177, 248);
                    BaseColor giallo = new BaseColor(NUmgiallo);
                    iTextSharp.text.Font CarattereGialloBold18 = iTextSharp.text.FontFactory.GetFont("Montserrat", 18, iTextSharp.text.Font.BOLD, giallo);
                    iTextSharp.text.Font CarattereGialloBold10 = iTextSharp.text.FontFactory.GetFont("Montserrat", 10, iTextSharp.text.Font.BOLD, giallo);

                    PdfReader reader = new PdfReader(pathin);
                    using ((reader))
                    {
                        // create PdfStamper object to write to get the pages from reader 
                        string testo = "";
                        PdfStamper stamper = new PdfStamper(reader, new FileStream(pathout, FileMode.Create));
                        // stamper.SetEncryption(PdfWriter.STRENGTH40BITS, "my-owner-password", "my-user-password", PdfWriter.AllowPrinting)
                        // stamper.SetEncryption(PdfWriter.STRENGTH40BITS, "my-owner-password", "my-user-password", PdfWriter.AllowCopy)
                        using ((stamper))
                        {
                            // select two pages from the original document
                            reader.SelectPages("1");
                            // gettins the page size in order to substract from the iTextSharp coordinates
                            var pageSize = reader.GetPageSize(1);
                            // PdfContentByte from stamper to add content to the pages over the original content

                            double prezzo = 0;
                            PdfContentByte pbover = stamper.GetOverContent(1);
                            testo = DateTime.Today.Year.ToString();

                            if (sett == "CO")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite18), 483, (float)415.5, 0);
                            if (sett == "SL")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite18), 483, (float)412.5, 0);
                            if (sett == "RE")
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite18), 503, 429, 0);
                            if (sett == "RE")
                            {
                                testo = dis + "_" + DateTime.Today.Year;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereRed12), 633, 432, 0);
                                testo = dis;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereBoldRed), 77, 178, 0);
                            }
                            if (sett == "SL")
                            {
                                testo = dis + "_" + DateTime.Today.Year;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereRed12), 675, 415, 0);
                                testo = dis;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereBoldRed), 67, 195, 0);
                            }
                            if (sett == "CO")
                            {
                                testo = dis + "_" + DateTime.Today.Year;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereRed12), 675, 417, 0);
                                testo = dis;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereBoldRed), 67, 195, 0);
                            }

                            bool personalGPL = GetPersonalGPL(Convert.ToInt16(this.idcliente.Text));

                            if (personalGPL == true)
                            {
                                string immagine = Server.MapPath(@"..\Doc\Loghi") + @"\";
                                iTextSharp.text.Image Logo = iTextSharp.text.Image.GetInstance(immagine + "/" + this.idcliente.Text + ".png");
                                Logo.ScalePercent(15, 15);
                                if (sett == "RE")
                                    Logo.SetAbsolutePosition(680, 420);
                                else
                                    Logo.SetAbsolutePosition(740, 410);

                                pbover.AddImage(Logo);
                            }

                            if (ModelloPdf != "")
                            {
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhiteBold20), 732, 468, 0);
                                testo = dis + "_" + testo;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhiteBold16), 868, 468, 0);
                                testo = dis;
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, CarattereGialloBold18), 115, 210, 0);
                                testo = "";
                                if (!Information.IsDBNull(dt1.Rows[0]["DescFascia1"]))
                                    testo = (string)dt1.Rows[0]["DescFascia1"];
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12), 685, 273, 0);
                                testo = "";
                                if (!Information.IsDBNull(dt1.Rows[0]["DescFascia2"]))
                                    testo = (string)dt1.Rows[0]["DescFascia2"];
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12), 792, 273, 0);
                                testo = "";
                                if (!Information.IsDBNull(dt1.Rows[0]["DescFascia3"]))
                                    testo = (string)dt1.Rows[0]["DescFascia3"];
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12), 885, 273, 0);
                                testo = (string)dt1.Rows[0]["Diametro"];
                                if (Information.IsNumeric(testo))
                                {
                                    if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                        testo = Strings.Format(testo, "n0");
                                    else
                                        testo = Strings.Format(testo, "n3");
                                }
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere12), 265, 239, 0);
                                testo = (string)dt1.Rows[0]["Tavola"];
                                if (Information.IsNumeric(testo))
                                {
                                    if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                        testo = Strings.Format(testo, "n0");
                                    else
                                        testo = Strings.Format(testo, "n3");
                                }

                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere12), 265, 213, 0);
                                testo = (string)dt1.Rows[0]["Lunghezza"];
                                if (Information.IsNumeric(testo))
                                {
                                    if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                        testo = Strings.Format(testo, "n0");
                                    else
                                        testo = Strings.Format(testo, "n3");
                                }
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere12), 265, 185, 0);

                                for (var i = 0; i <= dt1.Rows.Count - 1; i++)
                                {
                                    if (i == 0)
                                    {
                                        testo = "COMPLETE SUPPLY";
                                        if (lg == "IT")
                                            testo = "FORNITURA COMPLETA";
                                        int vert = 243;
                                        /* Cannot convert MultiLineIfBlockSyntax, System.NotSupportedException: LikeExpression not supported!
                                            at ICSharpCode.CodeConverter.CSharp.SyntaxKindExtensions.ConvertToken(SyntaxKind t, TokenContext context)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.NodesVisitor.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingNodesVisitor.DefaultVisit(SyntaxNode node)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.VisitMultiLineIfBlock(MultiLineIfBlockSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.MultiLineIfBlockSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.ConvertWithTrivia(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.DefaultVisit(SyntaxNode node)

                                        Input: 
                                        If ModelloPdf Like "*4" Then
                                            vert = 247
                                        End If
                                        */

                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7Bold), 470, vert, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 690, vert, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 788, vert, 0);
                                        prezzo = (double)dt1.Rows[0]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 890, vert, 0);
                                    }
                                    if (i == 1)
                                    {
                                        testo = "";
                                        if (!Information.IsDBNull(dt1.Rows[1]["TipoRipristinoEN"]))
                                            testo = dt1.Rows[1]["TipoRipristinoEN"].ToString().Trim();
                                        if (lg == "IT")
                                        {
                                        if (!Information.IsDBNull(dt1.Rows[1]["TipoRipristinoIT"]))
                                            testo = dt1.Rows[1]["TipoRipristinoIT"].ToString().Trim();
                                        }
                                        int vert = 213;
                                        /* Cannot convert MultiLineIfBlockSyntax, System.NotSupportedException: LikeExpression not supported!
                                            at ICSharpCode.CodeConverter.CSharp.SyntaxKindExtensions.ConvertToken(SyntaxKind t, TokenContext context)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.NodesVisitor.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingNodesVisitor.DefaultVisit(SyntaxNode node)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.VisitMultiLineIfBlock(MultiLineIfBlockSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.MultiLineIfBlockSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.ConvertWithTrivia(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.DefaultVisit(SyntaxNode node)

                                        Input: 
                                            If ModelloPdf Like "*4" Then
                                                vert = 223
                                            End If

                                            */
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7Bold), 470, vert, 0);
                                        prezzo = (double)dt1.Rows[1]["PrezzoCL_NE_80_160"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 690, vert, 0);
                                        prezzo = (double)dt1.Rows[1]["PrezzoCL_NE_160_260"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 788, vert, 0);
                                        prezzo = (double)dt1.Rows[1]["PrezzoCL_NE_260_360"] * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 890, vert, 0);
                                    }
                                    if (i == 2)
                                    {
                                        testo = "";
                                    if (!Information.IsDBNull(dt1.Rows[2]["TipoRipristinoEN"]))
                                        testo = dt1.Rows[2]["TipoRipristinoEN"].ToString().Trim();
                                        if (lg == "IT")
                                        {
                                        if (!Information.IsDBNull(dt1.Rows[2]["TipoRipristinoIT"]))
                                            testo = dt1.Rows[2]["TipoRipristinoIT"].ToString().Trim();
                                        }
                                        int vert = 183;
                                        ;/* Cannot convert MultiLineIfBlockSyntax, System.NotSupportedException: LikeExpression not supported!
                                            at ICSharpCode.CodeConverter.CSharp.SyntaxKindExtensions.ConvertToken(SyntaxKind t, TokenContext context)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.NodesVisitor.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingNodesVisitor.DefaultVisit(SyntaxNode node)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.VisitBinaryExpression(BinaryExpressionSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.BinaryExpressionSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at ICSharpCode.CodeConverter.CSharp.VisualBasicConverter.MethodBodyVisitor.VisitMultiLineIfBlock(MultiLineIfBlockSyntax node)
                                            at Microsoft.CodeAnalysis.VisualBasic.Syntax.MultiLineIfBlockSyntax.Accept[TResult](VisualBasicSyntaxVisitor`1 visitor)
                                            at Microsoft.CodeAnalysis.VisualBasic.VisualBasicSyntaxVisitor`1.Visit(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.ConvertWithTrivia(SyntaxNode node)
                                            at ICSharpCode.CodeConverter.CSharp.CommentConvertingMethodBodyVisitor.DefaultVisit(SyntaxNode node)

                                        Input: 
                                            If ModelloPdf Like "*4" Then
                                                vert = 198
                                            End If

                                            */
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7Bold), 470, vert, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[2]["PrezzoCL_NE_80_160"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 690, vert, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[2]["PrezzoCL_NE_160_260"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 788, vert, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[2]["PrezzoCL_NE_260_360"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 890, vert, 0);
                                    }
                                    if (i == 3)
                                    {
                                        testo = "";
                                        if (!Information.IsDBNull(dt1.Rows[3]["TipoRipristinoEN"]))
                                            testo = dt1.Rows[3]["TipoRipristinoEN"].ToString().Trim();
                                    if (lg == "IT")
                                        {
                                            if (!Information.IsDBNull(dt1.Rows[3]["TipoRipristinoIT"]))
                                                testo = dt1.Rows[3]["TipoRipristinoIT"].ToString().Trim();
                                    }

                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7Bold), 470, 173, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[3]["PrezzoCL_NE_80_160"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 690, 173, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[3]["PrezzoCL_NE_160_260"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 788, 173, 0);
                                        prezzo = Convert.ToDouble(dt1.Rows[3]["PrezzoCL_NE_260_360"]) * (1 + maggior / 100);
                                        testo = Strings.Format((int)prezzo, "C0");
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere12Bold), 890, 173, 0);
                                    }
                                }
                                // link
                                testo = "REFURBISHMENT";
                                if (lg == "IT")
                                    testo = "LAVORAZIONI";
                                Chunk fr = new Chunk(testo, CarattereGialloBold10);
                                MyKey fx = new MyKey();
                                string rndLink = "1" + ModelloPdf + fx.NewKey() + lg;
                                string LinkFile = Strings.Left(ModelloPdf, 3) + "_REFURBISHMENT SPECS_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 87, 50, 0);
                                testo = "SPECS";
                                if (lg == "IT")
                                    testo = "INCLUSE";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                // fx = New MyKey
                                // rndLink = "1" & ModelloPdf & fx.NewKey() & lg
                                // LinkFile = Left(ModelloPdf, 3) & "_REFURBISHMENT SPECS_" & lg & ".pdf"
                                // ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL)
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 87, 35, 0);
                                testo = "ADDITIONAL";
                                if (lg == "IT")
                                    testo = "LAVORAZIONI";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                fx = new MyKey();
                                rndLink = "1" + ModelloPdf + fx.NewKey() + lg;
                                LinkFile = Strings.Left(ModelloPdf, 3) + "_ADDITIONAL_ EXPENSES_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 215, 50, 0);
                                testo = "EXPENSES";
                                if (lg == "IT")
                                    testo = "AGGIUNTIVE";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                // fx = New MyKey
                                // rndLink = "1" & ModelloPdf & fx.NewKey() & lg
                                // LinkFile = Left(ModelloPdf, 3) & "_ADDITIONAL_ EXPENSES_" & lg & ".pdf"
                                // ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL)
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 215, 35, 0);
                                testo = "SALES";
                                if (lg == "IT")
                                    testo = "CONDIZIONI";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                fx = new MyKey();
                                rndLink = "1" + ModelloPdf + fx.NewKey() + lg;
                                LinkFile = Strings.Left(ModelloPdf, 3) + "_SALES_ CONDITIONS_" + lg + ".pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 343, 50, 0);
                                testo = "CONDITIONS";
                                if (lg == "IT")
                                    testo = "DI VENDITA";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                // fx = New MyKey
                                // rndLink = "1" & ModelloPdf & fx.NewKey() & lg
                                // LinkFile = Left(ModelloPdf, 3) & "_SALES_ CONDITIONS_" & lg & ".pdf"
                                // ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL)
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 343, 35, 0);
                                testo = "PICKUP";
                                if (lg == "IT")
                                    testo = "MODULO";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                fx = new MyKey();
                                rndLink = "1" + ModelloPdf + fx.NewKey() + lg;
                                LinkFile = "PickupForm.pdf";
                                ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 475, 50, 0);
                                testo = "FORM";
                                if (lg == "IT")
                                    testo = "PICKUP";
                                fr = new Chunk(testo, CarattereGialloBold10);
                                // fx = New MyKey
                                // rndLink = "1" & ModelloPdf & fx.NewKey() & lg
                                // LinkFile = "PickupForm.pdf"
                                // ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL)
                                fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 475, 35, 0);
                            }
                            else
                            {
                                switch (sett)
                                {
                                    case "SL":
                                        {
                                            testo = (string)dt1.Rows[0]["Diametro"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, 237, 0);
                                            testo = (string)dt1.Rows[0]["DiametroInterno"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, (float)217.5, 0);
                                            testo = (string)dt1.Rows[0]["Lunghezza"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, 199, 0);
                                            testo = "";
                                            if (Information.IsNumeric(dt1.Rows[0]["TavolaIncisa"]))
                                            {
                                                testo = (string)dt1.Rows[0]["TavolaIncisa"];
                                                if (Information.IsNumeric(testo))
                                                {
                                                    if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                        testo = Strings.Format(testo, "n0");
                                                    else
                                                        testo = Strings.Format(testo, "n3");
                                                }
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, (float)178.5, 0);
                                            break;
                                        }

                                    case "CO":
                                        {
                                            testo = (string)dt1.Rows[0]["Diametro"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, 241, 0);
                                            testo = (string)dt1.Rows[0]["Tavola"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }

                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, (float)220.5, 0);
                                            testo = (string)dt1.Rows[0]["TavolaIncisa"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, 200, 0);
                                            testo = (string)dt1.Rows[0]["Lunghezza"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 265, (float)179.5, 0);
                                            break;
                                        }

                                    case "RE":
                                        {
                                            testo = GetDescCostruzione((string)dt1.Rows[0]["Costruzione"], lg); // Steel tube and stainless steel journals" 

                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite9), 280, 270, 0);

                                            testo = (string)dt1.Rows[0]["Diametro"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 280, 216, 0);

                                            testo = (string)dt1.Rows[0]["Tavola"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 280, (float)199.5, 0);
                                            testo = (string)dt1.Rows[0]["Lunghezza"];
                                            if (Information.IsNumeric(testo))
                                            {
                                                if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                    testo = Strings.Format(testo, "n0");
                                                else
                                                    testo = Strings.Format(testo, "n3");
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 280, 183, 0);
                                            testo = ""; // per le etichette rappresenta il peso
                                            if (Information.IsNumeric(dt1.Rows[0]["TavolaIncisa"]))
                                            {
                                                testo = (string)dt1.Rows[0]["TavolaIncisa"];
                                                if (Information.IsNumeric(testo))
                                                {
                                                    if (Convert.ToDouble(testo) - Convert.ToDouble(testo) == 0)
                                                        testo = Strings.Format(testo, "n0");
                                                    else
                                                        testo = Strings.Format(testo, "n1");
                                                }
                                            }
                                            ColumnText.ShowTextAligned(pbover, Element.ALIGN_RIGHT, new Phrase(testo, Carattere), 280, (float)164.5, 0);
                                            break;
                                        }
                                }

                                if (sett == "RE")
                                {
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 460, 218, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 518, 218, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 575, 218, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 460, 171, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 518, 171, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 575, 171, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 635, 218, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 693, 218, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 218, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 635, 171, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 693, 171, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 171, 0);
                                }
                                else
                                {
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 398, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 448, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_NE_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 498, 230, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 398, 189, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 448, 189, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_NE_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 498, 189, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 548, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 598, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_DC_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 648, 230, 0);

                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_80_160"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 548, 189, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_160_260"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 598, 189, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_DC_260_360"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 648, 189, 0);
                                }
                                if (sett == "CO")
                                {
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_HPC_012"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 698, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoFC_HPC_34"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 230, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_HPC_012"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 698, 189, 0);
                                    prezzo = Convert.ToDouble(dt1.Rows[0]["PrezzoCL_HPC_34"]) * (1 + maggior / 100);
                                    testo = Strings.Format((int)prezzo, "C0");
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere), 748, 189, 0);

                                    testo = "ON DEMAND";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7), 798, 230, 0);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, Carattere7), 798, 189, 0);
                                }
                                // aggiunge testo pulsanti rossi con link in base al settore

                                if (sett == "SL")
                                {
                                    testo = "Supply specs";
                                    if (lg == "IT")
                                        testo = "Specifiche di acquisto";
                                    Chunk fr = new Chunk(testo, CarattereWhite10);
                                    MyKey fx = new MyKey();
                                    string rndLink = "1" + sett + fx.NewKey() + lg;
                                    string LinkFile = "Supply specs_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 110, 0);

                                    if (sett == "SL")
                                    {
                                        testo = "Other additional Expenses";
                                        if (lg == "IT")
                                            testo = "Lavorazioni Aggiuntive";
                                        fr = new Chunk(testo, CarattereWhite10);
                                        rndLink = "2" + sett + fx.NewKey() + lg;
                                        LinkFile = "OTHER ADDITIONAL EXPENSES_" + sett + "_" + lg + ".pdf";
                                        ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                        fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    }
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 82, 0);

                                    testo = "Certification";
                                    if (lg == "IT")
                                        testo = "Certificazione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "3" + sett + fx.NewKey() + lg;
                                    LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 53, 0);

                                    // colonna 2
                                    testo = "Engraving";
                                    if (lg == "IT")
                                        testo = "Incisione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "4" + sett + fx.NewKey() + lg;
                                    LinkFile = "ENGRAVING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 110, 0);

                                    testo = "Sleeve Refurbishment";
                                    if (lg == "IT")
                                        testo = "Rigenerazione Sleeve";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "5" + sett + fx.NewKey() + lg;
                                    LinkFile = "Refurbishment_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 82, 0);

                                    testo = "Coating";
                                    if (lg == "IT")
                                        testo = "Riporto";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "6" + sett + fx.NewKey() + lg;
                                    LinkFile = "Coating Department_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 53, 0);

                                    // colonna 3
                                    testo = "Sales Conditions";
                                    if (lg == "IT")
                                        testo = "Condizioni di Vendita";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "7" + sett + fx.NewKey() + lg;
                                    LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 110, 0);

                                    testo = "How it is made";
                                    if (lg == "IT")
                                        testo = "Costruzione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "8" + sett + fx.NewKey() + lg;
                                    LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 82, 0);

                                    testo = "SDB";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "9" + sett + fx.NewKey() + lg;
                                    LinkFile = "Sdb_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 53, 0);

                                    testo = "Download pickup-form";
                                    if (lg == "IT")
                                        testo = "Scarica il modulo di presa merce";
                                    fr = new Chunk(testo, CarattereWhite6);
                                    rndLink = "10" + sett + fx.NewKey() + lg;
                                    LinkFile = "pickup.pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(fr), 653, 42, 0);


                                    // scrive maggiorazioni per incisioni diverse
                                    testo = "NE 60°";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 798, 372, 0);
                                    testo = "+15%";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 798, 358, 0);
                                    testo = "NE 60°";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 798, 330, 0);
                                    testo = "+15%";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 798, 316, 0);
                                    testo = "on demand";
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 797, 278, 0);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 797, 234, 0);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(testo, CarattereWhite8), 797, 189, 0);
                                }
                                if (sett == "RE")
                                {
                                    testo = "Supply specs";
                                    if (lg == "IT")
                                        testo = "Specifiche di acquisto";
                                    Chunk fr = new Chunk(testo, CarattereWhite10);
                                    MyKey fx = new MyKey();
                                    string rndLink = "1" + sett + fx.NewKey() + lg;
                                    string LinkFile = "Supply specs_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 107, 0);

                                    testo = "Sales Conditions";
                                    if (lg == "IT")
                                        testo = "Condizioni di Vendita";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "7" + sett + fx.NewKey() + lg;
                                    LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 79, 0);

                                    testo = "Certification";
                                    if (lg == "IT")
                                        testo = "Certificazione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "3" + sett + fx.NewKey() + lg;
                                    LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 50, 0);

                                    // colonna 2
                                    testo = "NE - engraving";
                                    if (lg == "IT")
                                        testo = "Incisione-NE";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "4" + sett + fx.NewKey() + lg;
                                    LinkFile = "NE_ENGRAVING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 107, 0);

                                    testo = "DC - engraving";
                                    if (lg == "IT")
                                        testo = "Incisione-DC";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "5" + sett + fx.NewKey() + lg;
                                    LinkFile = "DC_ENGRAVING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 79, 0);

                                    testo = "Coating";
                                    if (lg == "IT")
                                        testo = "Riporto";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "6" + sett + fx.NewKey() + lg;
                                    LinkFile = "Coating Department_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 50, 0);

                                    // colonna 3
                                    testo = "SDB";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "9" + sett + fx.NewKey() + lg;
                                    LinkFile = "Sdb_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 107, 0);

                                    testo = "How it is made";
                                    if (lg == "IT")
                                        testo = "Costruzione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "8" + sett + fx.NewKey() + lg;
                                    LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 79, 0);
                                }
                                if (sett == "CO")
                                {
                                    testo = "Supply specs";
                                    if (lg == "IT")
                                        testo = "Specifiche di acquisto";
                                    Chunk fr = new Chunk(testo, CarattereWhite10);
                                    MyKey fx = new MyKey();
                                    string rndLink = "11" + sett + fx.NewKey() + lg;
                                    string LinkFile = "Supply specs_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 113, 0);

                                    testo = "Diameter Re-building";
                                    if (lg == "IT")
                                        testo = "Ripristino Diametro";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "12" + sett + fx.NewKey() + lg;
                                    LinkFile = "DIAMETER REBUILDING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 85, 0);

                                    testo = "Other additional Expenses";
                                    if (lg == "IT")
                                        testo = "Lavorazioni Aggiuntive";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "13" + sett + fx.NewKey() + lg;
                                    LinkFile = "OTHER ADDITIONAL EXPENSES_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 56, 0);

                                    testo = "Certification";
                                    if (lg == "IT")
                                        testo = "Certificazione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "14" + sett + fx.NewKey() + lg;
                                    LinkFile = "CERTIFICAZIONI_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 110, 29, 0);

                                    // colonna 2
                                    testo = "NE - engraving";
                                    if (lg == "IT")
                                        testo = "Incisione-NE";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "15" + sett + fx.NewKey() + lg;
                                    LinkFile = "NE_ENGRAVING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 113, 0);

                                    testo = "DC - engraving";
                                    if (lg == "IT")
                                        testo = "Incisione-DC";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "16" + sett + fx.NewKey() + lg;
                                    LinkFile = "DC_ENGRAVING_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 85, 0);

                                    if (sett != "SL")
                                    {
                                        testo = "HPC - engraving";
                                        if (lg == "IT")
                                            testo = "Incisione-HPC";
                                        fr = new Chunk(testo, CarattereWhite10);
                                        rndLink = "17" + sett + fx.NewKey() + lg;
                                        LinkFile = "HPC_ENGRAVING_" + sett + "_" + lg + ".pdf";
                                        ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                        fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                        ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 56, 0);
                                    }

                                    testo = "Coating";
                                    if (lg == "IT")
                                        testo = "Riporto";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "18" + sett + fx.NewKey() + lg;
                                    LinkFile = "Coating Department_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 320, 29, 0);

                                    // colonna 3
                                    testo = "Sales Conditions";
                                    if (lg == "IT")
                                        testo = "Condizioni di Vendita";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "19" + sett + fx.NewKey() + lg;
                                    LinkFile = "SALES CONDITIONS_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 113, 0);

                                    testo = "How it is made";
                                    if (lg == "IT")
                                        testo = "Costruzione";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "20" + sett + fx.NewKey() + lg;
                                    LinkFile = "HOW IT IS MADE_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 85, 0);

                                    testo = "SDB";
                                    fr = new Chunk(testo, CarattereWhite10);
                                    rndLink = "21" + sett + fx.NewKey() + lg;
                                    LinkFile = "Sdb_" + sett + "_" + lg + ".pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_CENTER, new Phrase(fr), 520, 56, 0);

                                    testo = "Download pickup-form";
                                    if (lg == "IT")
                                        testo = "Scarica il modulo di presa merce";
                                    fr = new Chunk(testo, CarattereWhite6);
                                    rndLink = "10" + sett + fx.NewKey() + lg;
                                    LinkFile = "pickup.pdf";
                                    ScriviTempKey(rndLink, dis, lg, LinkFile, personalGPL);
                                    fr.SetAnchor("http://webt.simecgroup.com/SDB/MktDoc/Simdoc.aspx?id=" + rndLink);
                                    ColumnText.ShowTextAligned(pbover, Element.ALIGN_LEFT, new Phrase(fr), 653, 48, 0);
                                }
                            }

                            this.Allegato.Visible = true;
                            this.Allegato.Text = dis + "_" + lg + ".pdf";
                            this.myAllegato.NavigateUrl = "~/doc/" + "ListiniPDF" + "/" + Strings.Replace(dis, "&", "e") + "_" + lg + ".pdf";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                this.Allegato.Visible = false;
                this.Allegato.Text = "";
                this.myAllegato.NavigateUrl = "";
            }
            return msg;
        }
        protected bool GetPersonalGPL(int id)
        {
            bool persgpl = false;
            try
            {
                string sql = "SELECT PersonalGPL FROM OFF_ClientiSDB WHERE Id=" + id;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                    persgpl = Convert.ToBoolean(dt.Rows[0]["PersonalGPL"]);
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return persgpl;
        }
        protected string GetDescCostruzione(string cod, string lg)
        {
            string desc = "";
            try
            {
                string sql = "SELECT Descrizione ";
                if (lg == "EN")
                    sql = "SELECT DescrizioneEN as Descrizione ";
                sql = sql + "FROM Tecnologia_Incisione WHERE Codice='" + cod + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Information.IsDBNull(dt.Rows[0]["Descrizione"]))
                        desc = dt.Rows[0]["Descrizione"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }

            return desc;
        }

        protected void ScriviTempKey(string rndLink, string Disegno, string lingua, string LinkFile, bool persGPL)
        {
            try
            {
                string sql = "INSERT INTO MKT_TempFileLink (Disegno,LinkFile,LinkFileTemp,Lingua,DataCrea) ";
                sql = sql + " VALUES(@Disegno,@LinkFile,@LinkFileTemp,@Lingua,GetDate())";
                if (persGPL == true)
                {
                    sql = "INSERT INTO MKT_TempFileLink (Disegno,LinkFile,LinkFileTemp,Lingua,DataCrea,DataScad) ";
                    sql = sql + " VALUES(@Disegno,@LinkFile,@LinkFileTemp,@Lingua,GetDate(),@DataScad)";
                }
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                Generic z = new Generic();
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFileTemp", DbType.String, rndLink));
                cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(z.CreaSqlParameter("Disegno", DbType.String, Disegno, 10));
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFile", DbType.String, LinkFile, 50));
                cmd.Parameters.Add(z.CreaSqlParameter("LinkFileTemp", DbType.String, rndLink, 50));
                cmd.Parameters.Add(z.CreaSqlParameter("Lingua", DbType.String, lingua, 2));
                cmd.Parameters.Add(z.CreaSqlParameter("DataScad", DbType.DateTime, "31/12/2025"));
                try
                {
                    ConnSDB.Open();
                    cmd.ExecuteNonQuery();
                    ConnSDB.Close();
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                    ConnSDB.Close();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void Cliente_Search(object sender, SearchBoxEventArgs e)
        {
            if (Information.IsNumeric(e.Value))
            {
                this.idcliente.Text = e.Value;
                CaricaContatti(Convert.ToInt16(e.Value));
                FunzioniCRM cr = new FunzioniCRM();
                string msg = cr.BloccaSedi(Convert.ToString(e.Value));
                if (msg == "")
                {
                    CaricaListini();
                    this.SendEmail.Enabled = true;
                    this.GvGPL.Visible = true;
                }
                else
                {
                    this.SendEmail.Enabled = false;
                    this.GvGPL.Visible = false;
                    ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
                }
            }
            else
                this.idcliente.Text = "";
        }


        private void GvGPL_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            CaricaListini(1);
        }

        private void GvGPL_PreRender(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!Information.IsNothing(Request.QueryString["dis"]))
                {
                    GridColumn col = this.GvGPL.MasterTableView.GetColumn("Disegno");
                    col.CurrentFilterFunction = GridKnownFunction.EqualTo;
                    string x = Request.QueryString["dis"];
                    x = Strings.Replace(x, "-E-", "&");
                    col.CurrentFilterValue = x;
                    GvGPL.MasterTableView.FilterExpression = "Disegno='" + x + "'";
                    GvGPL.MasterTableView.Rebind();

                    foreach (GridDataItem item in GvGPL.MasterTableView.Items)
                    {
                        if (item["Disegno"].Text == x)
                            item.Selected = true;
                    }
                }
            }
        }
    }
}