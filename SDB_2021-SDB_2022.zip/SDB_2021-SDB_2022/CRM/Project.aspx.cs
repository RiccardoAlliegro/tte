﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Microsoft.VisualBasic;
using System.Web.UI.HtmlControls;
using SDB_2021.Code;
using System.Linq;
using System.Web.UI;

namespace SDB_2021.CRM
{
    public partial class Project : System.Web.UI.Page
    {
        SqlConnection ConnSDB = new SqlConnection(ConfigurationManager.ConnectionStrings["SDB"].ConnectionString);
        Generic x;

        protected void Page_Load(object sender, System.EventArgs e)
        {
            // filtra lista in base all'attribuzione
            if (!User.IsInRole("Commerciale") & !User.IsInRole("BackOffice") & !User.IsInRole("Amministratore"))
                //Response.Redirect("../Principal.aspx");
            if (!User.IsInRole("Amministratore"))
            {
                GvListe.MasterTableView.GetColumn("ProvenienzaLista").Visible = false;
                GridTemplateColumn col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("Settore");
                col.ReadOnly = true;
                col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("ProvenienzaLista");
                col.ReadOnly = true;
            }
            else
            {
                GridTemplateColumn col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("Settore");
                col.ReadOnly = false;
                col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("ProvenienzaLista");
                col.ReadOnly = false;
                this.PanelManager.Visible = true;
                EstrazioneCompleta.Visible = true;
            }
            if (User.IsInRole("Commerciale"))
            {
                GridTemplateColumn col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("Settore");
                col.ReadOnly = false;
                col = (GridTemplateColumn)GvListe.MasterTableView.GetColumn("OperatoreAttribuito");
                col.ReadOnly = false;
            }
            FunzioniCRM k = new FunzioniCRM();
            string NomeCompleto = k.GetNomeCompleto(User.Identity.Name);
            //CaricaLista(NomeCompleto);
            if (!IsPostBack)
            {
                GvListe.Visible = false;
            }
            else 
                GvListe.Visible = true;
           
        }
        protected void CaricaLista(string ut)
        {
            // filtra lista clienti, operazioni, to do e docuemntazione inviata in base all'operatore attribuito
            try
            {
                if (!User.IsInRole("Amministratore"))
                {
                    this.SqlListe.SelectCommand = @"select Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, 
                        Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, 
                        ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo

                            FROM(
                            SELECT DISTINCT 
                            dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale, 
                            dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, 
                            dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo
                            FROM            dbo.CRM_Liste LEFT OUTER JOIN
                            dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date)= cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc
                            WHERE        (dbo.CRM_Liste.Settore = 'CO') AND (dbo.CRM_Liste.Visibile = 1) and dbo.CRM_Liste.OperatoreAttribuito='" + ut + @"') as p group by Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, 
                            Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, 
                            ProvenienzaLista, Visibile, Idlista, Reserved, tipo";
                    this.SqlOperazioni.SelectCommand = "SELECT * FROM vw_CRM_ListeOperazioni WHERE OperatoreAttribuito='" + ut + "' AND Settore='CO' ORDER BY [DataMod] DESC";
                    this.SqlTodo.SelectCommand = "SELECT * FROM [vw_CRM_listeToDo] WHERE  operatoreAttribuito='" + ut + "' AND (([Chiuso] = 0) ) AND Settore='CO' AND DataNextContatto<=GetDate() ORDER BY [DataNextContatto] DESC";
                    this.SqlDocInviati.SelectCommand = "Select * FROM vw_CRM_ListeDocInviati WHERE Settore='CO'";
                }
                else
                {
                    this.SqlListe.SelectCommand = @"select Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, 
                            Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, 
                            ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo

                        from(
                        SELECT DISTINCT 
                        dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale, 
                        dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, 
                        dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo
                        FROM            dbo.CRM_Liste LEFT OUTER JOIN
                        dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date)= cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc
                        WHERE        (dbo.CRM_Liste.Settore = 'CO')) as p group by Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, 
                        Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, 
                        ProvenienzaLista, Visibile, Idlista, Reserved, tipo";
                    this.SqlOperazioni.SelectCommand = "SELECT * FROM vw_CRM_ListeOperazioni WHERE Settore='CO' ORDER BY [DataMod] DESC";
                    this.SqlTodo.SelectCommand = "SELECT * FROM [vw_CRM_listeToDo] WHERE (([Chiuso] = 0) ) AND Settore='CO' And DataNextContatto<=GetDate() ORDER BY [DataNextContatto] DESC";
                    this.SqlDocInviati.SelectCommand = "Select * FROM vw_CRM_ListeDocInviati WHERE Settore='CO' AND operatoreAttribuito='" + ut + "'";
                }
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
        }
        private void ResetPanelNuovaOperazione()
        {
            EsitoTel.SelectedValue = "";
            DataNextContatto.SelectedDate = null;
            Argomento.Text = "";
            Note.Text = "";
            Reazione.SelectedValue = "";
        }
        protected DataTable FiltraOperazioni(Int32 id = 0)
        {
            DataTable dt = new DataTable();
            try
            {
                string sql = "Select * FROM vw_CRM_ListeOperazioni where settore='CO'";
                if (id != 0)
                    sql += " AND IdRagSoc=" + id;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return dt;
        }
        protected DataTable FiltraDoc(Int32 id = 0)
        {
            DataTable dt = new DataTable();
            try
            {
                string sql = "Select * FROM vw_CRM_ListeDocInviati where settore='CO'";
                if (id != 0)
                    sql += " AND IdRagSoc=" + id;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
            return dt;
        }
        protected void InviaDocumentazione_Click(object sender, EventArgs e)
        {
            if (this.PanelInvioDoc.Visible == false)
                this.PanelInvioDoc.Visible = true;
            else
                this.PanelInvioDoc.Visible = false;
        }
        protected void InviaDoc_Click(object sender, EventArgs e)
        {
            try
            {
                // invia copia del documento nella lingua selezionata al contatto cliente selezionato
                string msg = "";
                FunzioniCRM funzcrm = new FunzioniCRM();

                if (GvInvioDoc.SelectedItems.Count > 0)
                {
                    string[] allegato = new[] { "", "", "", "", "", "", "", "", "", "" };
                    string[] descFile = new[] { "", "", "", "", "", "", "", "", "", "" };
                    string[] lgdoc = new[] { "", "", "", "", "", "", "", "", "", "" };
                    for (var i = 0; i <= GvInvioDoc.SelectedItems.Count - 1; i++)
                    {
                        int myid = System.Convert.ToInt32(GvInvioDoc.SelectedItems[i].Cells[2].Text);

                        lgdoc[i] = ((DropDownList)this.GvInvioDoc.SelectedItems[i].Cells[11].FindControl("LinguaSel")).SelectedValue;
                        if (lgdoc[i] != "" & this.LinguaTestoEmail.SelectedValue != "")
                        {
                            string sql = "Select * FROM CRM_ListeDocumentazione WHERE Id=" + myid;
                            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            if (dt.Rows.Count > 0)
                            {
                                if (System.Convert.ToBoolean(dt.Rows[0][lgdoc[i]]) == true)
                                {
                                    // controlla esistenza allegato
                                    string nomefile = lgdoc[i] + " " + dt.Rows[0]["Documento"] + ".pdf";
                                    descFile[i] = (string)dt.Rows[0]["Descrizione"];
                                    allegato[i] = Server.MapPath("../Doc/DocMarketing/") + nomefile;
                                }
                                else
                                    msg = "Documento non disponibile per la lingua selezionata!";
                            }
                        }
                        else
                            msg = "Specificare la lingua di invio del documento e la lingua di invio email";
                    }

                    if (msg == "")
                    {
                        string EmailContatto = EmailSel.Text;
                        string Nomecontatto = ContattoSel.Text;
                        if (EmailContatto != "")
                        {
                            // invia allegato
                            string oggetto = "SIMEC Follow UP";
                            string Testo = this.TestoMail.Content;
                            Testo += "<br/><br/>";
                            string nomecompl = funzcrm.GetNomeCompleto(User.Identity.Name);
                            Testo += "<b>" + nomecompl + "</b><br/>";
                            string tel = funzcrm.RecuperaTelCommerciale(nomecompl);
                            if (tel != "")
                                Testo += "Direct Phone: " + tel + "<br/><br/>";
                            Testo += "E-mail: " + funzcrm.RecuperaEmailCommerciale(nomecompl) + "<br/><br/>";
                            Testo += "<img src='cid:LogoBlu.png' alt='' /><br/>";

                            Testo += "Olgiate Olona (VA) – Montefino (TE)<br/>";
                            Testo += "Ph. +39 0331 393900<br/>";
                            Testo += "<b>www.simecgroup.com</b>";

                            Supporto z = new Supporto();

                            // EmailContatto = "amainini@liuc.it"

                            msg = z.InviaMailMultiAllegato(EmailContatto, "", Testo, oggetto, allegato, "", "Html", "", "", Server.MapPath("../Styles/") + "LogoBlu.png");
                            if (msg == "ok")
                            {
                                for (var i = 0; i <= allegato.Count() - 1; i++)
                                {
                                    if (allegato[i] != "")
                                    {
                                        // registra linvio dei documenti
                                        string sql = "INSERT INTO CRM_ListeDocInviati (IdRagSoc,Documento,LinguaDoc,NomeContatto,TestoInviato,DataInvio,DataMod,UtMod)";
                                        sql += " VALUES(@IdRagSoc,@Documento,@LinguaDoc,@NomeContatto,@TestoInviato,GetDate(),GetDate(),@UtMod)";
                                        SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                                        cmd.Parameters.Add(x.CreaSqlParameter("IdRagSoc", DbType.Int32, IdSel.Text));
                                        cmd.Parameters.Add(x.CreaSqlParameter("Documento", DbType.String, descFile[i]));
                                        cmd.Parameters.Add(x.CreaSqlParameter("LinguaDoc", DbType.String, lgdoc[i]));
                                        cmd.Parameters.Add(x.CreaSqlParameter("NomeContatto", DbType.String, Nomecontatto));
                                        cmd.Parameters.Add(x.CreaSqlParameter("TestoInviato", DbType.String, Testo, 8000));
                                        cmd.Parameters.Add(x.CreaSqlParameter("UtMod", DbType.String, User.Identity.Name));
                                        try
                                        {
                                            ConnSDB.Open();
                                            cmd.ExecuteNonQuery();
                                            ConnSDB.Close();
                                        }
                                        catch (Exception ex)
                                        {
                                            ConnSDB.Close();
                                        }
                                    }
                                }
                                // inserisce nell'elenco operazioni un operazione di invio dei documenti
                                string sql1 = "INSERT INTO CRM_ListeOperazioni (IdRagSoc,Contatto,Tipo,Argomento,DataMod,UtMod)";
                                sql1 += " VALUES(@IdRagSoc,@Contatto,@Tipo,@Argomento,GetDate(),@UtMod)";
                                SqlCommand cmd1 = new SqlCommand(sql1, ConnSDB);
                                cmd1.Parameters.Add(x.CreaSqlParameter("IdRagSoc", DbType.Int32, IdSel.Text));
                                cmd1.Parameters.Add(x.CreaSqlParameter("Contatto", DbType.String, Nomecontatto));
                                cmd1.Parameters.Add(x.CreaSqlParameter("Tipo", DbType.String, "Email"));
                                cmd1.Parameters.Add(x.CreaSqlParameter("Argomento", DbType.String, "Invio documentazione"));
                                cmd1.Parameters.Add(x.CreaSqlParameter("UtMod", DbType.String, User.Identity.Name));
                                string numop = "";
                                try
                                {
                                    ConnSDB.Open();
                                    numop = (string)cmd1.ExecuteScalar();
                                    ConnSDB.Close();
                                }
                                catch (Exception ex)
                                {
                                    string err = ex.Message;
                                    ConnSDB.Close();
                                }
                                // genera to do
                                ChiudeToDoPrecedenti(IdSel.Text, Nomecontatto);
                                GeneraToDO(Convert.ToInt16(IdSel.Text), Nomecontatto, DateTime.Today, "Invio Documentazione", "", "", numop);
                                msg = "Documentazione inviata correttamente";
                                GvDocInviati.Rebind();
                                GvOperazioni.Rebind();
                            }
                        }
                        else
                            msg = "Selezionare un contatto!";
                    }
                }
                else
                    msg = "Selezionare un documento da inviare!";
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private string getTestoMail(string lsel)
        {
            string testo = "";
            try
            {
                string sql = "SELECT * FROM CRM_ListeDocTestiMail WHERE Lingua='" + lsel + "'";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (!Information.IsDBNull(dt.Rows[0]["Testo"]))
                        testo = dt.Rows[0]["Testo"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
            return testo;
        }
        private void GvContatti_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ContattoSel.Text = "";
            this.EmailSel.Text = "";
            this.ContattoSel1.Text = "";
            this.TelSel.Text = "";
            if (Information.IsNumeric(this.GvContatti.SelectedValue))
            {
                try
                {
                    string consel = this.GvContatti.SelectedItems[0].Cells[4].Text.Trim() + " " + this.GvContatti.SelectedItems[0].Cells[5].Text.Trim();
                    string emsel = this.GvContatti.SelectedItems[0].Cells[8].Text.Trim();
                    string tsel = this.GvContatti.SelectedItems[0].Cells[7].Text.Trim();
                    if (consel != "")
                    {
                        this.ContattoSel.Text = Strings.Trim(consel);
                        this.ContattoSel1.Text = Strings.Trim(consel);
                    }
                    if (emsel != "")
                        this.EmailSel.Text = Strings.Trim(emsel);
                    if (tsel != "")
                        this.TelSel.Text = Strings.Trim(tsel);
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                }
            }
        }
        protected void NuovaOperazione_Click(object sender, EventArgs e)
        {
            //if (this.PanelOperazioni.Visible == false)
            //    this.PanelOperazioni.Visible = true;
            //else
            //    this.PanelOperazioni.Visible = false;

            ClientScript.RegisterStartupScript(this.GetType(), "Popup", "$('#ManageRow').modal('show')", true);
        }
        protected void SalvaOp_Click(object sender, EventArgs e)
        {
            string msg = "";
            if (Information.IsNumeric(IdSel.Text))
            {
                if (ContattoSel1.Text != "")
                {
                    if (EsitoTel.SelectedValue == "Risposto" & Reazione.SelectedValue == "")
                        msg = "Specificare un valore per il campo REAZIONE";
                    else
                        try
                        {
                            string sql = "INSERT INTO CRM_ListeOperazioni (IdRagSoc,Contatto,Tipo,Argomento,Note,Esito,Reazione,DataNextContatto,DataMod,UtMod) ";
                            sql += "VALUES(@IdRagSoc,@Contatto,@Tipo,@Argomento,@Note,@Esito,@Reazione,@DataNextContatto,GetDate(),@UtMod); SELECT SCOPE_IDENTITY();";
                            SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                            cmd.Parameters.Add(x.CreaSqlParameter("IdRagSoc", DbType.Int32, IdSel.Text));
                            cmd.Parameters.Add(x.CreaSqlParameter("Contatto", DbType.String, ContattoSel1.Text));
                            cmd.Parameters.Add(x.CreaSqlParameter("Tipo", DbType.String, Tipo.SelectedValue));
                            cmd.Parameters.Add(x.CreaSqlParameter("Argomento", DbType.String, Argomento.Text, 2000));
                            cmd.Parameters.Add(x.CreaSqlParameter("Note", DbType.String, Note.Text, 2000));
                            cmd.Parameters.Add(x.CreaSqlParameter("Esito", DbType.String, EsitoTel.SelectedValue));
                            cmd.Parameters.Add(x.CreaSqlParameter("Reazione", DbType.String, Reazione.SelectedValue));
                            cmd.Parameters.Add(x.CreaSqlParameter("DataNextContatto", DbType.DateTime, DataNextContatto.SelectedDate));
                            cmd.Parameters.Add(x.CreaSqlParameter("UtMod", DbType.String, User.Identity.Name));
                            try
                            {
                                ConnSDB.Open();
                                string RifOp = (string)cmd.ExecuteScalar();
                                ConnSDB.Close();
                                GvOperazioni.DataBind();
                                // ChiudeToDoPrecedenti(IdSel.Text, ContattoSel1.Text)
                                string dataNXC = "";
                                if (Information.IsDate(DataNextContatto.SelectedDate))
                                    dataNXC = DataNextContatto.SelectedDate.ToString();
                                GeneraToDO(Convert.ToInt16(IdSel.Text), ContattoSel1.Text, DateTime.Today, EsitoTel.SelectedValue, Reazione.SelectedValue, dataNXC, RifOp);
                                // aggiorna data last contatto in CRM_Liste
                                AggiornaDataLastContatto(Convert.ToInt16(IdSel.Text));

                                msg = "Operazione inserita correttamente.";
                            }
                            catch (Exception ex)
                            {
                                string errore = ex.Message;
                                msg = "Errore salvataggio operazione!";
                                ConnSDB.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                        }
                }
                else
                    msg = "Selezionare un contatto nella sezione contatti.";
            }
            else
                msg = "Selezionare un cliente nella sezione LISTE.";
            ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('" + msg + "');</script>"));

            //PanelOperazioni.Visible = false;
            GvOperazioni.Visible = true;
        }
        protected void ChiudeToDoPrecedenti(string IdSel, string Contatto)
        {
            try
            {
                string sql = "UPDATE CRM_ListeToDo SET Chiuso=1,DataChiuso=GetDate() WHERE IdRagSoc=" + IdSel + " AND Contatto=@Contatto AND Chiuso=0";
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                cmd.Parameters.Add(x.CreaSqlParameter("Contatto", DbType.String, Contatto));
                try
                {
                    ConnSDB.Open();
                    cmd.ExecuteNonQuery();
                    ConnSDB.Close();
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                    ConnSDB.Close();
                }
            }

            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private void GvOperazioni_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            if (Information.IsNumeric(GvListe.SelectedValue))
                FiltraOperazioni(System.Convert.ToInt32(GvListe.SelectedValue));
            else
                FiltraOperazioni();
        }
        protected bool VerificaFestivo(DateTime DataNextContatto)
        {
            bool fest = false;
            if (DateAndTime.Weekday(DataNextContatto) == 1 | DateAndTime.Weekday(DataNextContatto) == 7)
                fest = true;
            return fest;
        }
        protected void GeneraToDO(Int32 IdRagSoc, string Contatto, DateTime DataUltimoContatto, string Esito, string Reazione, string DataNextContatto, string RifOp)
        {
            try
            {
                string motivo = "";
                string Azione = "";

                if (Esito != "Persona Sbagliata" & Esito != "Persona Sbagliata")
                {
                    if (Reazione != "Non interessato non richiamare")
                    {
                        bool Festivo = true;
                        if (Esito == "Non Risponde" | Esito == "Richiamare")
                        {
                            motivo = "Esito operazione precedente: " + Esito;
                            Azione = "Richiamare";
                            if (!Information.IsDate(DataNextContatto))
                            {
                                DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 2, DataUltimoContatto).ToString();
                                do
                                {
                                    Festivo = VerificaFestivo(Convert.ToDateTime(DataNextContatto));
                                    if (Festivo == true)
                                        DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 1, Convert.ToDateTime(DataNextContatto)).ToString();
                                }
                                while (!Festivo == false);
                            }
                        }
                        else
                        {
                            if (Esito == "Invio Documentazione")
                            {
                                motivo = Esito;
                                Azione = "Richiamare per: Feedback Documentazione";
                                if (!Information.IsDate(DataNextContatto))
                                {
                                    DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 5, DataUltimoContatto).ToString();
                                    do
                                    {
                                        Festivo = VerificaFestivo(Convert.ToDateTime(DataNextContatto));
                                        if (Festivo == true)
                                            DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 1, Convert.ToDateTime(DataNextContatto)).ToString();
                                    }
                                    while (!Festivo == false);
                                }
                            }
                            else
                            {
                                if (Reazione.Contains("Richiest"))
                                {
                                    motivo = "Richiesta Cliente: " + Reazione;
                                    Azione = "Provvedere alla richiesta del cliente";
                                    if (!Information.IsDate(DataNextContatto))
                                    {
                                        DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 1, DataUltimoContatto).ToString();
                                        do
                                        {
                                            Festivo = VerificaFestivo(Convert.ToDateTime(DataNextContatto));
                                            if (Festivo == true)
                                                DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 1, Convert.ToDateTime(DataNextContatto)).ToString();
                                        }
                                        while (!Festivo == false);
                                    }
                                }
                                else
                                {
                                    int gg = 1;
                                    if (!Information.IsDate(DataNextContatto))
                                    {
                                        if (Reazione == "Interessato ma non necessita a breve")
                                            gg = 45;
                                        if (Reazione == "Interessato, aspetto mail di risposta")
                                            gg = 30;

                                        if (Reazione == "Non interessato al momento altro fornitore")
                                            gg = 90;
                                        DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, gg, DataUltimoContatto).ToString();
                                        do
                                        {
                                            Festivo = VerificaFestivo(Convert.ToDateTime(DataNextContatto));
                                            if (Festivo == true)
                                                DataNextContatto = DateAndTime.DateAdd(DateInterval.Day, 1, Convert.ToDateTime(DataNextContatto)).ToString();
                                        }
                                        while (!Festivo == false);
                                    }
                                    motivo = "Esito operazione precedente: " + Esito;
                                    Azione = "Richiamare";
                                }
                            }
                        }
                    }

                    string sql = "INSERT INTO CRM_ListeToDo (IdRagSoc,Contatto,DataUltimoContatto,Motivo,DataNextContatto,Azione,RifOperazione) ";
                    sql += "VALUES(@IdRagSoc,@Contatto,@DataUltimoContatto,@Motivo,@DataNextContatto,@Azione,@RifOperazione)";
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    cmd.Parameters.Add(x.CreaSqlParameter("IdRagSoc", DbType.Int32, IdSel.Text));
                    cmd.Parameters.Add(x.CreaSqlParameter("Contatto", DbType.String, ContattoSel1.Text));
                    cmd.Parameters.Add(x.CreaSqlParameter("DataUltimoContatto", DbType.DateTime, DataUltimoContatto));
                    cmd.Parameters.Add(x.CreaSqlParameter("Motivo", DbType.String, motivo, 200));
                    cmd.Parameters.Add(x.CreaSqlParameter("DataNextContatto", DbType.DateTime, DataNextContatto));
                    cmd.Parameters.Add(x.CreaSqlParameter("Azione", DbType.String, Azione));
                    cmd.Parameters.Add(x.CreaSqlParameter("RifOperazione", DbType.String, RifOp));
                    try
                    {
                        ConnSDB.Open();
                        cmd.ExecuteNonQuery();
                        ConnSDB.Close();
                        this.GvToDo.DataBind();
                    }
                    catch (Exception ex)
                    {
                        string errore = ex.Message;
                        ConnSDB.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private void AggiornaDataLastContatto(Int32 IdSel)
        {
            try
            {
                string sql = "UPDATE CRM_LISTE SET DataLastContatto=GetDate() WHERE Id=" + IdSel;
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                ConnSDB.Open();
                cmd.ExecuteNonQuery();
                ConnSDB.Close();
                GvListe.Rebind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private void GvListe_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is Telerik.Web.UI.GridDataItem)
            {
                Telerik.Web.UI.GridDataItem item = (Telerik.Web.UI.GridDataItem)e.Item;
                TableCell cell = (TableCell)item["RagioneSociale"];
                var f = DataBinder.Eval(e.Item.DataItem, "DataLastContatto").ToString();
                var t = DataBinder.Eval(e.Item.DataItem, "DataInsSDB").ToString();
                if (!Information.IsDate(f))
                    cell.BackColor = System.Drawing.Color.OrangeRed;
                if (Information.IsDate(t))
                    cell.BackColor = System.Drawing.Color.LightGreen;
            }
        }
        protected void TrasformaInProspect_Click(object sender, EventArgs e)
        {
            if (Information.IsNumeric(GvListe.SelectedValue))
            {
                // trasforma il nominativo cliente in prospect in SDB Company Data
                Int32 idTrasf = (int)GvListe.SelectedValue;
                try
                {
                    // inserisce anagrafica
                    string sql = "SELECT * FROM CRM_Liste WHERE Id=" + idTrasf;
                    SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        sql = "INSERT INTO OFF_ClientiSDB (RagSoc,Indirizzo,Localita,Cap,Provincia,Nazione,Telefono,CodLingua,Manager,Gruppo,DataMod,UtMod,Origine)";
                        sql += " VALUES(@RagSoc,@Indirizzo,@Localita,@Cap,@Provincia,@Nazione,@Telefono,@CodLingua,@Manager,@Gruppo,GetDate(),@UtMod,'From Projects Page');SELECT SCOPE_IDENTITY()";
                        cmd = new SqlCommand(sql, ConnSDB);
                        string cli = (string)dt.Rows[0]["RagioneSociale"];
                        cmd.Parameters.Add(x.CreaSqlParameter("RagSoc", DbType.String, cli, 100));
                        string Indirizzo = "";
                        if (!Information.IsDBNull(dt.Rows[0]["Indirizzo"]))
                            Indirizzo = (string)dt.Rows[0]["Indirizzo"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Indirizzo", DbType.String, Indirizzo, 150));
                        string localita = "";
                        if (!Information.IsDBNull(dt.Rows[0]["Plant"]))
                            localita = (string)dt.Rows[0]["Plant"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Localita", DbType.String, localita, 100));
                        string Cap = "";
                        if (!Information.IsDBNull(dt.Rows[0]["Cap"]))
                            Cap = (string)dt.Rows[0]["Cap"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Cap", DbType.String, Cap, 20));
                        string Prov = "";

                        cmd.Parameters.Add(x.CreaSqlParameter("Provincia", DbType.String, Prov, 25));
                        string Naz = "";
                        if (!Information.IsDBNull(dt.Rows[0]["Nazione"]))
                            Naz = (string)dt.Rows[0]["Nazione"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Nazione", DbType.String, Naz, 50));

                        string TelefonoAziendale = "";
                        if (!Information.IsDBNull(dt.Rows[0]["TelefonoAziendale"]))
                            TelefonoAziendale = (string)dt.Rows[0]["TelefonoAziendale"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Telefono", DbType.String, TelefonoAziendale, 50));
                        string lingua = "";
                        if (!Information.IsDBNull(dt.Rows[0]["lingua"]))
                            lingua = (string)dt.Rows[0]["lingua"];
                        cmd.Parameters.Add(x.CreaSqlParameter("CodLingua", DbType.String, lingua, 3));
                        string manager = "";
                        if (!Information.IsDBNull(dt.Rows[0]["OperatoreAttribuito"]))
                            manager = (string)dt.Rows[0]["OperatoreAttribuito"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Manager", DbType.String, manager, 50));
                        string gruppo = "";
                        if (!Information.IsDBNull(dt.Rows[0]["Gruppo"]))
                            gruppo = (string)dt.Rows[0]["Gruppo"];
                        cmd.Parameters.Add(x.CreaSqlParameter("Gruppo", DbType.String, gruppo, 100));
                        cmd.Parameters.Add(x.CreaSqlParameter("UtMod", DbType.String, User.Identity.Name));

                        ConnSDB.Open();
                        Int32 idcli = (int)cmd.ExecuteScalar();
                        ConnSDB.Close();
                        if (idcli > 0)
                        {
                            // plant
                            sql = "INSERT INTO OFF_DestinazioniClienti (IdCliente,RagSoc,Sede,Nazione,Tipo,UtCrea,DataCrea) ";
                            sql += " VALUES(@IdCliente,@RagSoc,1,@Nazione,@Tipo,@UtCrea,GetDate());SELECT SCOPE_IDENTITY()";
                            cmd = new SqlCommand(sql, ConnSDB);
                            cmd.Parameters.Add(x.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                            cmd.Parameters.Add(x.CreaSqlParameter("RagSoc", DbType.String, cli));
                            cmd.Parameters.Add(x.CreaSqlParameter("Nazione", DbType.String, Naz));
                            cmd.Parameters.Add(x.CreaSqlParameter("Tipo", DbType.String, "PLANT Main Address"));
                            cmd.Parameters.Add(x.CreaSqlParameter("UtCrea", DbType.String, User.Identity.Name));
                            ConnSDB.Open();
                            Int32 idsede = (int)cmd.ExecuteScalar();
                            ConnSDB.Close();
                            // contatti del plant
                            if (idsede > 0)
                            {
                                sql = "SELECT * FROM CRM_ListeContatti WHERE IdRagSoc=" + idTrasf;
                                cmd = new SqlCommand(sql, ConnSDB);
                                da = new SqlDataAdapter(cmd);
                                dt = new DataTable();
                                da.Fill(dt);
                                for (var i = 0; i <= dt.Rows.Count - 1; i++)
                                {
                                    sql = "INSERT INTO OFF_ContattiClienti (IdCliente,IdSede,Nominativo,Telefono,Email,Note)";
                                    sql += " VALUES(@IdCliente,@IdSede,@Nominativo,@Telefono,@Email,@Note)";
                                    cmd = new SqlCommand(sql, ConnSDB);
                                    cmd.Parameters.Add(x.CreaSqlParameter("IdCliente", DbType.Int32, idcli));
                                    cmd.Parameters.Add(x.CreaSqlParameter("IdSede", DbType.Int32, idsede));
                                    string nome = "";
                                    if (!Information.IsDBNull(dt.Rows[i]["NomeContatto"]))
                                        nome = dt.Rows[i]["NomeContatto"].ToString().Trim() + " ";
                                    if (!Information.IsDBNull(dt.Rows[i]["CognomeContatto"]))
                                        nome += dt.Rows[i]["CognomeContatto"].ToString().Trim();
                                    cmd.Parameters.Add(x.CreaSqlParameter("Nominativo", DbType.String, Strings.Trim(nome)));
                                    string Tel = "";
                                    if (!Information.IsDBNull(dt.Rows[i]["Cellulare"]))
                                        Tel = dt.Rows[i]["Cellulare"].ToString().Trim();
                                    cmd.Parameters.Add(x.CreaSqlParameter("Telefono", DbType.String, Tel));
                                    string Email = "";
                                    if (!Information.IsDBNull(dt.Rows[i]["Email"]))
                                        Email = dt.Rows[i]["Email"].ToString().Trim();
                                    cmd.Parameters.Add(x.CreaSqlParameter("Email", DbType.String, Email));
                                    string Ruolo = "";
                                    if (!Information.IsDBNull(dt.Rows[i]["Ruolo"]))
                                        Ruolo = dt.Rows[i]["Ruolo"].ToString().Trim();
                                    cmd.Parameters.Add(x.CreaSqlParameter("Note", DbType.String, Ruolo));
                                    try
                                    {
                                        ConnSDB.Open();
                                        cmd.ExecuteNonQuery();
                                        ConnSDB.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        ConnSDB.Close();
                                    }
                                }
                            }
                            // nasconde nominativo nella lista
                            sql = "UPDATE CRM_Liste set Visibile=0, InseritoSDB=1,DataInsSDB=GetDate() WHERE Id=" + idTrasf;
                            cmd = new SqlCommand(sql, ConnSDB);
                            ConnSDB.Open();
                            cmd.ExecuteNonQuery();
                            ConnSDB.Close();
                            GvListe.Rebind();
                            ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('Nominativo trasformato correttamente in Prospect');</script>"));
                        }
                    }
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                }
            }
            else
                ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('Selezionare un nominativo');</script>"));
        }
        protected void LinguaTestoEmail_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string testo = getTestoMail(this.LinguaTestoEmail.SelectedValue);
                this.TestoMail.Content = testo;
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        private void GvListe_UpdateCommand(object sender, GridCommandEventArgs e)
        {
            if (User.IsInRole("Amministratore"))
            {
                try
                {
                    SqlListe.UpdateCommand = "UPDATE [CRM_Liste] SET [RagioneSociale] = @RagioneSociale, [Gruppo] = @Gruppo, [Nazione] = @Nazione, [Plant] = @Plant, [Indirizzo] = @Indirizzo, [Cap] = @Cap, [TelefonoAziendale] = @TelefonoAziendale, [Lingua] = @Lingua, [Social] = @Social, [Note] = @Note,Settore=@Settore,ProvenienzaLista=@ProvenienzaLista WHERE [Id] = @Id";

                    GridEditableItem editedItem = e.Item as GridEditableItem;
                    TextBox set = (TextBox)editedItem.FindControl("SettoreTextBox");
                    string sett = set.Text;
                    TextBox pro = (TextBox)editedItem.FindControl("ProvenienzaListaTextBox");
                    string prov = pro.Text;
                    SqlListe.UpdateParameters.Add("Settore", sett);

                    SqlListe.UpdateParameters.Add("ProvenienzaLista", sett);
                }
                catch (Exception ex)
                {
                    string errore = ex.Message;
                }
            }
        }
        protected void ModManager_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.Manager.SelectedValue != "")
                {
                    for (var i = 0; i <= GvListe.Items.Count - 1; i++)
                    {
                        CheckBox chk = (CheckBox)GvListe.Items[i].FindControl("SelezionadChk1");
                        string myid = GvListe.Items[i].Cells[2].Text;
                        if (chk.Checked == true)
                            UpdateManager(this.Manager.SelectedValue, myid);
                    }
                }
                else
                    ClientScript.RegisterStartupScript(base.GetType(), "errore", ("<script LANGUAGE='JavaScript' >alert('Selezionare un manager');</script>"));
                GvListe.DataBind();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
            }
        }
        protected void UpdateManager(string ute, string myid)
        {
            try
            {
                string sql = "UPDATE CRM_Liste SET OperatoreAttribuito='" + ute + "' WHERE Id=" + Convert.ToInt32(myid);
                SqlCommand cmd = new SqlCommand(sql, ConnSDB);
                ConnSDB.Open();
                cmd.ExecuteNonQuery();
                ConnSDB.Close();
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                ConnSDB.Close();
            }
        }
        private void EstrazioneCompleta_Click(object sender, EventArgs e)
        {
            try
            {
                Gv_Estrazione.Visible = true;
            }
            catch (Exception ex)
            {
                string errore = ex.Message;
                ConnSDB.Close();
            }
        }
        private void Gv_Estrazione_InfrastructureExporting(object sender, GridInfrastructureExportingEventArgs e)
        {
            var rows = e.ExportStructure.Tables[0].Rows;
            var rowCount = rows.Count;
            for (var rowIndex = 1; rowIndex <= rowCount; rowIndex++)
            {
                for (var i = 1; i <= rows[rowIndex].Cells.Count; i++)
                {
                    rows[rowIndex].Cells[i, rowIndex].Format = "@";

                    rows[rowIndex].Cells[i, rowIndex].Value = rows[rowIndex].Cells[i, rowIndex].Text;
                }
            }
        }
        private void GvListe_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            FunzioniCRM k = new FunzioniCRM();
            string NomeCompleto = k.GetNomeCompleto(User.Identity.Name);
            CaricaLista(NomeCompleto);
        }
        protected void Projects_ServerClick(object sender, EventArgs e)
        {
            var views = (HtmlAnchor)sender;
            var settore = views.Attributes["customdata"];
        }
        protected void SceltaProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sett="";
            switch (SceltaProject.SelectedItem.Value)
            {
                case "Corrugated":
                    sett = "'CO'";
                    break;
                case "Labels":
                    sett = "'RE', 'NA'";
                    break;
                case "Flexible":
                    sett = "'IF', 'SL'";
                    break;
                case "Coating / Laminations":
                    sett = "'RS', 'LA'";
                    break;
                case "Reserved":
                    sett = "Reserved";
                    break;
                default:
                    sett = "";
                    break;
            }

            if (sett == "")
            {
                GvListe.Visible = false;
                return;
            }

            FunzioniCRM k = new FunzioniCRM();
            string NomeCompleto = k.GetNomeCompleto(User.Identity.Name);
            string ut = NomeCompleto;
            ut = "Ana Nedelcu";
            if (sett != "Reserved")
            {
                if (!User.IsInRole("Amministratore")) {
                    SqlListe.SelectCommand = "SELECT Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo FROM(SELECT DISTINCT dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale,dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo FROM dbo.CRM_Liste LEFT OUTER JOIN dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date) = cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc WHERE (dbo.CRM_Liste.Settore IN (" + sett + ")) AND (dbo.CRM_Liste.Visibile = 1) and dbo.CRM_Liste.OperatoreAttribuito = '" + ut + "') as p group by Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, tipo";
                    SqlOperazioni.SelectCommand = "SELECT * FROM vw_CRM_ListeOperazioni WHERE OperatoreAttribuito='" + ut + "' AND Settore IN(" + sett + ") ORDER BY [DataMod] DESC";
                    SqlTodo.SelectCommand = "SELECT * FROM [vw_CRM_listeToDo] WHERE  operatoreAttribuito='" + ut + "' AND (([Chiuso] = 0) ) AND Settore IN (" + sett + ") AND DataNextContatto<=GetDate() ORDER BY [DataNextContatto] DESC";
                    //SqlDocInviati.SelectCommand = "SELECT * FROM vw_CRM_ListeDocInviati WHERE Settore IN (" + sett + ")";
                }
                else
                {
                    SqlListe.SelectCommand = "select Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo FROM( SELECT DISTINCT dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale, dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo FROM dbo.CRM_Liste LEFT OUTER JOIN dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date) = cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc WHERE (dbo.CRM_Liste.Settore IN (" + sett + "))) as p group by Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, tipo";
                    SqlOperazioni.SelectCommand = "SELECT * FROM vw_CRM_ListeOperazioni WHERE Settore IN (" + sett + ") ORDER BY [DataMod] DESC";
                    SqlTodo.SelectCommand = "SELECT * FROM [vw_CRM_listeToDo] WHERE (([Chiuso] = 0) ) AND Settore IN (" + sett + ") And DataNextContatto<=GetDate() ORDER BY [DataNextContatto] DESC";
                    //SqlDocInviati.SelectCommand = "Select * FROM vw_CRM_ListeDocInviati WHERE Settore='CO' AND operatoreAttribuito='" + ut + "'";
                }
            }
            else
            {
                if (!User.IsInRole("Amministratore"))
                {
                    SqlListe.SelectCommand = "SELECT Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo, IdoneoS, IdoneoF FROM( SELECT DISTINCT dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale, dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo, CRM_Liste.IdoneoS, CRM_Liste.IdoneoF FROM dbo.CRM_Liste LEFT OUTER JOIN dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date) = cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc WHERE dbo.CRM_Liste.Reserved = 1 AND(dbo.CRM_Liste.Visibile = 1) and dbo.CRM_Liste.OperatoreAttribuito = '" + ut + "') as p GROUP BY Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, tipo, IdoneoS, IdoneoF";
                }
                else
                {
                    SqlListe.SelectCommand = "SELECT Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, MAX(DataMod) as DataMod, Tipo, IdoneoS, IdoneoF FROM( SELECT DISTINCT dbo.CRM_Liste.Id, dbo.CRM_Liste.RagioneSociale, dbo.CRM_Liste.Gruppo, dbo.CRM_Liste.Nazione, dbo.CRM_Liste.Plant, dbo.CRM_Liste.Cap, dbo.CRM_Liste.Indirizzo, dbo.CRM_Liste.TelefonoAziendale, dbo.CRM_Liste.Lingua, dbo.CRM_Liste.Social, dbo.CRM_Liste.Note, dbo.CRM_Liste.DataLastContatto, dbo.CRM_Liste.InseritoSDB, dbo.CRM_Liste.DataInsSDB, dbo.CRM_Liste.OperatoreAttribuito, dbo.CRM_Liste.Settore, dbo.CRM_Liste.ProvenienzaLista, dbo.CRM_Liste.Visibile, dbo.CRM_Liste.Idlista, dbo.CRM_Liste.Reserved, dbo.vw_CRM_ListeOperazioni.DataMod as DataMod, dbo.vw_CRM_ListeOperazioni.Tipo, CRM_Liste.IdoneoS, CRM_Liste.IdoneoF FROM dbo.CRM_Liste LEFT OUTER JOIN dbo.vw_CRM_ListeOperazioni ON cast(dbo.CRM_Liste.DataLastContatto as date) = cast(dbo.vw_CRM_ListeOperazioni.DataMod as date) AND dbo.CRM_Liste.Id = dbo.vw_CRM_ListeOperazioni.IdRagSoc WHERE dbo.CRM_Liste.Reserved = 1) as p GROUP BY Id, RagioneSociale, Gruppo, Nazione, Plant, Cap, Indirizzo, TelefonoAziendale, Lingua, Social, Note, DataLastContatto, InseritoSDB, DataInsSDB, OperatoreAttribuito, Settore, ProvenienzaLista, Visibile, Idlista, Reserved, tipo, IdoneoS, IdoneoF";
                }
            }
            if (sett != "")
            {
                GvListe.Visible = true;
            }
        }

        protected void GvListe_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Information.IsNumeric(GvListe.SelectedValue))
            {
                this.IdSel.Text = (string)GvListe.SelectedValue.ToString();
                this.RagSocSel.Text = GvListe.SelectedItems[0].Cells[3].Text;
                // filtra elenco operazioni
                this.GvOperazioni.DataSourceID = null;
                this.GvOperazioni.DataSource = FiltraOperazioni(Convert.ToInt16(GvListe.SelectedValue));
                this.GvOperazioni.DataBind();
                this.GvDocInviati.DataSourceID = null;
                this.GvDocInviati.DataSource = FiltraDoc(Convert.ToInt16(GvListe.SelectedValue));
                this.GvDocInviati.DataBind();
                this.ContattoSel.Text = "";
                this.ContattoSel1.Text = "";
                this.EmailSel.Text = "";
                this.TelSel.Text = "";
                this.TestoMail.Content = "";
            }
            else
            {
                this.IdSel.Text = "";
                this.RagSocSel.Text = "";
                this.ContattoSel.Text = "";
                this.ContattoSel1.Text = "";
                this.EmailSel.Text = "";
                this.TelSel.Text = "";
            }
            ResetPanelNuovaOperazione();
            try
            {
                string sql = SqlListe.SelectCommand;
                string sqlstart = "WHERE";
                if (sql.Contains(sqlstart))
                {
                    int start = sql.IndexOf(sqlstart, 0) + sqlstart.Length;
                    string sqlIN = sql.Left(start);
                    string sqlOUT = sql.Right(sql.Length - start);
                    string sqlID = " dbo.CRM_Liste.Id = " + GvListe.SelectedValue.ToString() + " AND";
                    string sql2 = sqlIN + sqlID + sqlOUT;
                    SqlCommand cmd = new SqlCommand(sql2, ConnSDB);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        GvModal.DataSourceID = null;
                        GvModal.DataSource = dt;
                        GvModal.DataBind();
                        GvModal.MasterTableView.GetColumn("Visibile").Visible = false;
                        GvModal.MasterTableView.GetColumn("DataInsSDB").Visible = false;
                        GvModal.Visible = true;
                        GvModal.Skin = "Black";
                    }
                }
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "openModal();", true);
            }
            catch (Exception ex)
            {
                string err = ex.Message;
            }
        }

        protected void CloseRow_Click(object sender, EventArgs e)
        {
            GvListe.Visible = true;
        }
    }
}